package server;

import java.io.*;
import java.net.*;
import com.google.gson.*;
import java.util.Arrays;
import java.util.List;

import share.ServerMessage;
import share.ClientMessage;
import share.LoginRequest;
import share.LoginResponse;
import share.RegisterRequest;
import share.RegisterResponse;
import share.ChatRequest;
import share.CreateGroupRequest;
import share.ErrorResponse;
import share.Schedule;
import share.UserData;
import share.User;
import share.LocalDateTimeAdapter;

public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private Server server;
    private BufferedReader reader;
    private PrintWriter writer;
    private String username;
    private Gson gson;
    private boolean isAuthenticated;

    public ClientHandler(Socket socket, Server server) {
        this.clientSocket = socket;
        this.server = server;
        this.gson = new GsonBuilder()
            .registerTypeAdapter(java.time.LocalDateTime.class, new LocalDateTimeAdapter())
            .create();
        this.isAuthenticated = false;
        try {
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            System.err.println("[ClientHandler-" + (socket.getRemoteSocketAddress()) + "] 初期化エラー: " + e.getMessage());
        }
    }

    @Override
    public void run() {
        String clientInfo = clientSocket.getRemoteSocketAddress().toString();
        System.out.println("[ClientHandler-" + clientInfo + "] 接続処理開始。");
        try {
            String inputLine;
            while ((inputLine = reader.readLine()) != null) {
                System.out.println("[ClientHandler-" + clientInfo + "] " + (username != null ? username : "GUEST") + "から受信: " + inputLine.substring(0, Math.min(inputLine.length(), 150)) + (inputLine.length() > 150 ? "..." : ""));
                handleMessage(inputLine);
            }
        } catch (SocketException e) {
            if (isConnected()) {
                 System.out.println("[ClientHandler-" + clientInfo + "] " + (username != null ? username : "GUEST") + "との接続が切れました: " + e.getMessage());
            } else {
                 System.out.println("[ClientHandler-" + clientInfo + "] クライアントとの接続が予期せず切れました: " + e.getMessage());
            }
        } catch (IOException e) {
            if (isConnected()) {
                System.err.println("[ClientHandler-" + clientInfo + "] " + (username != null ? username : "GUEST") + "との通信エラー: " + e.getMessage());
            }
        } finally {
            cleanup(clientInfo);
        }
    }

    private void handleMessage(String message) {
        try {
            ServerMessage serverMessage = gson.fromJson(message, ServerMessage.class);
            if (serverMessage == null || serverMessage.getType() == null) {
                sendErrorMessage("無効なメッセージ形式です。");
                return;
            }
            String messageType = serverMessage.getType();
            // ★★★ needsAuth に UPDATE_SCHEDULE, DELETE_SCHEDULE を追加 ★★★
            boolean needsAuth = Arrays.asList("SEND_CHAT", "ADD_SCHEDULE", "UPDATE_SCHEDULE", "DELETE_SCHEDULE", "CREATE_GROUP", "GET_USER_DATA", "LEAVE_GROUP").contains(messageType);
            if (needsAuth && !isAuthenticated) {
                sendErrorMessage("認証が必要です。まずログインしてください。");
                return;
            }

            switch (messageType) {
                case "LOGIN":
                    handleLogin(serverMessage);
                    break;
                case "REGISTER":
                    handleRegister(serverMessage);
                    break;
                case "SEND_CHAT":
                    handleSendChat(serverMessage);
                    break;
                case "ADD_SCHEDULE":
                    handleAddSchedule(serverMessage);
                    break;
                // ★★★ ここから追加 ★★★
                case "UPDATE_SCHEDULE":
                    handleUpdateSchedule(serverMessage);
                    break;
                case "DELETE_SCHEDULE":
                    handleDeleteSchedule(serverMessage);
                    break;
                // ★★★ 追加ここまで ★★★
                case "CREATE_GROUP":
                    handleCreateGroup(serverMessage);
                    break;
                case "GET_ALL_USERS":
                    handleGetAllUsers();
                    break;
                case "GET_USER_DATA":
                    handleGetUserData();
                    break;
                default:
                    sendErrorMessage("不明なメッセージタイプです: " + messageType);
            }
        } catch (JsonSyntaxException e) {
            sendErrorMessage("無効なJSON形式のメッセージです: " + e.getMessage());
        } catch (Exception e) {
            sendErrorMessage("サーバー内部エラーが発生しました: " + e.getMessage());
            System.err.println("[ClientHandler] ハンドルメッセージ中の予期せぬエラー (" + username + "): " + e.toString());
            e.printStackTrace();
        }
    }

    private void handleLogin(ServerMessage message) {
        LoginRequest req = gson.fromJson(message.getData(), LoginRequest.class);
        if (req == null || req.getUsername() == null || req.getPassword() == null) {
            sendErrorMessage("ログイン情報が不完全です。");
            return;
        }
        User authenticatedUser = server.authenticateUser(req.getUsername(), req.getPassword());
        if (authenticatedUser != null) {
            this.username = authenticatedUser.getUsername();
            this.isAuthenticated = true;
            server.addClient(this.username, this);
            sendMessage("LOGIN_SUCCESS", new LoginResponse(true, "ログインに成功しました。"));
            handleGetUserData();
        } else {
            sendMessage("LOGIN_FAILED", new LoginResponse(false, "ユーザー名またはパスワードが間違っています。"));
        }
    }

    private void handleRegister(ServerMessage message) {
        RegisterRequest req = gson.fromJson(message.getData(), RegisterRequest.class);
        if (req == null || req.getUsername() == null || req.getPassword() == null) {
            sendErrorMessage("登録情報が不完全です。");
            return;
        }
        if (server.registerUser(req.getUsername(), req.getPassword())) {
            sendMessage("REGISTER_SUCCESS", new RegisterResponse(true, "ユーザー登録に成功しました。"));
        } else {
            sendMessage("REGISTER_FAILED", new RegisterResponse(false, "そのユーザー名は既に使用されているか、登録に失敗しました。"));
        }
    }

    private void handleSendChat(ServerMessage message) {
        ChatRequest req = gson.fromJson(message.getData(), ChatRequest.class);
        if (req == null || req.getGroupId() == null || req.getMessage() == null) {
            sendErrorMessage("チャット情報が不完全です。");
            return;
        }
        server.addChatMessage(this.username, req.getGroupId(), req.getMessage());
    }

    private void handleAddSchedule(ServerMessage message) {
        Schedule schedule = gson.fromJson(message.getData(), Schedule.class);
        if (schedule == null) {
            sendErrorMessage("スケジュール情報が不完全です。");
            return;
        }
        server.addSchedule(this.username, schedule);
    }
    
    // ★★★ ここから追加 ★★★
    private void handleUpdateSchedule(ServerMessage message) {
        try {
            Schedule scheduleToUpdate = gson.fromJson(message.getData(), Schedule.class);
            if (scheduleToUpdate == null || scheduleToUpdate.getId() == null) {
                sendErrorMessage("スケジュール更新情報が不完全です。");
                return;
            }
            server.updateSchedule(this.username, scheduleToUpdate);
        } catch (Exception e) {
            sendErrorMessage("スケジュール更新エラー: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handleDeleteSchedule(ServerMessage message) {
        try {
            if (message.getData() == null || !message.getData().isJsonObject()) {
                 sendErrorMessage("削除するスケジュールIDの形式が不正です。");
                 return;
            }
            JsonObject dataObj = message.getData().getAsJsonObject();
            if (!dataObj.has("id")) {
                sendErrorMessage("削除するスケジュールIDが含まれていません。");
                return;
            }
            String scheduleIdToDelete = dataObj.get("id").getAsString();
            server.deleteSchedule(this.username, scheduleIdToDelete);
        } catch (Exception e) {
            sendErrorMessage("スケジュール削除エラー: " + e.getMessage());
            e.printStackTrace();
        }
    }
    // ★★★ 追加ここまで ★★★

    private void handleCreateGroup(ServerMessage message) {
        CreateGroupRequest req = gson.fromJson(message.getData(), CreateGroupRequest.class);
        if (req == null || req.getGroupName() == null) {
            sendErrorMessage("グループ作成情報が不完全です。");
            return;
        }
        server.createGroup(req.getGroupName(), this.username, req.getMembers());
    }

    private void handleGetAllUsers() {
        List<User> allUsers = server.getAllUsersForClient();
        // 新しいメッセージタイプ "ALL_USERS_LIST" で応答
        sendMessage("ALL_USERS_LIST", allUsers); 
    }

    private void handleGetUserData() {
        if (!isAuthenticated || this.username == null) {
            sendErrorMessage("ユーザーデータを取得するには認証が必要です。");
            return;
        }
        UserData userData = server.getUserData(this.username);
        if (userData != null) {
            sendMessage("USER_DATA", userData);
        } else {
            sendErrorMessage("ユーザーデータの取得に失敗しました。");
        }
    }

    public void sendMessage(String type, Object data) {
        if (writer == null || clientSocket.isClosed()) {
            System.err.println("[ClientHandler] " + (username != null ? username : "GUEST") + " へのメッセージ送信失敗: クライアント接続がありません。");
            return;
        }
        try {
            ClientMessage clientMessage = new ClientMessage(type, gson.toJsonTree(data));
            String jsonMessage = gson.toJson(clientMessage);
            System.out.println("[ClientHandler] " + (username != null ? username : "GUEST") + " へ送信: Type=" + type);
            writer.println(jsonMessage);
        } catch (Exception e) {
            System.err.println("[ClientHandler] メッセージ送信エラー (" + (username != null ? username : "GUEST") + "宛, Type=" + type + "): " + e.getMessage());
        }
    }

    public void sendErrorMessage(String errorMessage) {
        System.err.println("[ClientHandler] エラーメッセージ送信 (" + (username != null ? username : "GUEST") + "宛): " + errorMessage);
        sendMessage("ERROR", new ErrorResponse(errorMessage));
    }

    private void cleanup(String clientInfo) {
        try {
            if (username != null) {
                server.removeClient(username);
            }
            if (reader != null) reader.close();
            if (writer != null) writer.close();
            if (clientSocket != null && !clientSocket.isClosed()) clientSocket.close();
            System.out.println("[ClientHandler-" + clientInfo + "] クリーンアップ完了。");
        } catch (IOException e) {
            System.err.println("[ClientHandler-" + clientInfo + "] クリーンアップエラー: " + e.getMessage());
        }
        isAuthenticated = false;
    }
    
    private boolean isConnected() {
        return clientSocket != null && !clientSocket.isClosed() && clientSocket.isConnected();
    }

    public String getUsername() {
        return username;
    }
}