package server;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicBoolean;

import share.User;
import share.Group;
import share.Schedule;
import share.ChatMessage;
import share.UserData;
import share.LocalDateTimeAdapter;
import share.ErrorResponse;

public class Server {
    private static final int PORT = 8080;
    private static final String DATA_DIR = "data/";
    private static final String USERS_FILE = DATA_DIR + "users.json";
    private static final String GROUPS_FILE = DATA_DIR + "groups.json";
    private static final String SCHEDULES_FILE = DATA_DIR + "schedules.json";
    private static final String CHATS_FILE = DATA_DIR + "chats.json";
    private final AtomicBoolean isStopping = new AtomicBoolean(false);

    private ServerSocket serverSocket;
    private Map<String, ClientHandler> connectedClients;
    private Map<String, User> users;
    private Map<String, Group> groups;
    private List<Schedule> schedules;
    private List<ChatMessage> chatMessages;
    private Gson gson;
    private ExecutorService threadPool;

    public Server() {
        connectedClients = new ConcurrentHashMap<>();
        users = new ConcurrentHashMap<>();
        groups = new ConcurrentHashMap<>();
        schedules = Collections.synchronizedList(new ArrayList<>());
        chatMessages = Collections.synchronizedList(new ArrayList<>());
        gson = new GsonBuilder()
            .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter())
            .setPrettyPrinting()
            .create();
        threadPool = Executors.newCachedThreadPool();
        new File(DATA_DIR).mkdirs();
        loadData();
    }

    public void start() {
        try {
            serverSocket = new ServerSocket(PORT);
            System.out.println("サーバーがポート " + PORT + " で起動しました。クライアントの接続を待機中...");
            while (!isStopping.get()) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    if (isStopping.get()) {
                        clientSocket.close();
                        break;
                    }
                    System.out.println("新しいクライアントが接続しました: " + clientSocket.getRemoteSocketAddress());
                    ClientHandler clientHandler = new ClientHandler(clientSocket, this);
                    threadPool.execute(clientHandler);
                } catch (IOException e) {
                    if (isStopping.get() || serverSocket.isClosed()) {
                        System.out.println("サーバーソケットが閉じられたため、新規接続の受付を停止します。");
                        break;
                    }
                    System.err.println("クライアント接続受付エラー: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            if (!isStopping.get()) {
                System.err.println("サーバー起動エラー (ポート " + PORT + "): " + e.getMessage());
            }
        } finally {
            stop();
        }
    }

    public void stop() {
        if (!isStopping.compareAndSet(false, true)) {
            System.out.println("（stop() は既に実行中のため、スキップします）");
            return;
        }
        System.out.println("サーバーを停止処理中...");
        try {
            for (ClientHandler handler : connectedClients.values()) {
                handler.sendMessage("SERVER_SHUTDOWN", "サーバーがシャットダウンします。");
            }
            connectedClients.clear();
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
            threadPool.shutdown();
            if (!threadPool.awaitTermination(5, TimeUnit.SECONDS)) {
                threadPool.shutdownNow();
            }
        } catch (IOException | InterruptedException e) {
            System.err.println("サーバー停止中のエラー: " + e.getMessage());
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
        } finally {
             saveData();
             System.out.println("サーバーが停止しました。");
        }
    }

    private void loadData() {
        System.out.println("データをファイルから読み込んでいます...");
        users = loadFromFile(USERS_FILE, new TypeToken<ConcurrentHashMap<String, User>>(){}.getType(), new ConcurrentHashMap<>());
        groups = loadFromFile(GROUPS_FILE, new TypeToken<ConcurrentHashMap<String, Group>>(){}.getType(), new ConcurrentHashMap<>());
        schedules = Collections.synchronizedList(loadFromFile(SCHEDULES_FILE, new TypeToken<ArrayList<Schedule>>(){}.getType(), new ArrayList<>()));
        chatMessages = Collections.synchronizedList(loadFromFile(CHATS_FILE, new TypeToken<ArrayList<ChatMessage>>(){}.getType(), new ArrayList<>()));
        System.out.println("データの読み込み完了。 User:" + users.size() + " Group:" + groups.size() + " Schedule:" + schedules.size() + " Chat:" + chatMessages.size());
    }
    
    private <T> T loadFromFile(String filePath, Type type, T defaultValue) {
        File file = new File(filePath);
        if (file.exists() && file.length() > 2) { // 空の配列[]やオブジェクト{}でないことを確認
            try (FileReader reader = new FileReader(file)) {
                T data = gson.fromJson(reader, type);
                return data != null ? data : defaultValue;
            } catch (IOException | JsonSyntaxException e) {
                System.err.println("ファイル読み込みエラー (" + filePath + "): " + e.getMessage());
            }
        }
        return defaultValue;
    }

    public synchronized void saveData() {
        System.out.println("データをファイルに保存しています...");
        saveToFile(USERS_FILE, users);
        saveToFile(GROUPS_FILE, groups);
        saveToFile(SCHEDULES_FILE, schedules);
        saveToFile(CHATS_FILE, chatMessages);
        System.out.println("データの保存完了。");
    }

    private synchronized void saveToFile(String filePath, Object data) {
        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(data, writer);
        } catch (IOException | JsonIOException e) {
            System.err.println("ファイル保存エラー (" + filePath + "): " + e.getMessage());
            e.printStackTrace();
        }
    }

    public synchronized User authenticateUser(String username, String password) {
        User user = users.get(username.toLowerCase());
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    public synchronized boolean registerUser(String username, String password) {
        String lowerCaseUsername = username.toLowerCase();
        if (users.containsKey(lowerCaseUsername)) {
            return false;
        }
        User newUser = new User(username, password);
        users.put(lowerCaseUsername, newUser);
        saveData();
        return true;
    }

    public synchronized void addClient(String username, ClientHandler clientHandler) {
        connectedClients.put(username.toLowerCase(), clientHandler);
        System.out.println("ユーザー '" + username + "' がシステムに接続しました。現在 " + connectedClients.size() + " 人がオンラインです。");
    }

    public synchronized void removeClient(String username) {
        if (username != null) {
            ClientHandler removed = connectedClients.remove(username.toLowerCase());
            if (removed != null) {
                System.out.println("ユーザー '" + username + "' がシステムから切断しました。現在 " + connectedClients.size() + " 人がオンラインです。");
            }
        }
    }

    public synchronized List<User> getAllUsersForClient() {
        // パスワード情報を含まない、クライアント送信用のUserリストを返す
        return users.values().stream()
                .map(user -> new User(user.getUsername(), null)) // パスワードはnullにする
                .sorted(Comparator.comparing(User::getUsername)) // 名前順でソートして返すと親切
                .collect(Collectors.toList());
    }

    public synchronized UserData getUserData(String username) {
        String lowerCaseUsername = username.toLowerCase();
        User user = users.get(lowerCaseUsername);
        if (user == null) {
            return null;
        }

        final List<Group> userGroups = groups.values().stream()
            .filter(g -> g.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(lowerCaseUsername)))
            .collect(Collectors.toList());
        Set<String> userGroupIds = userGroups.stream().map(Group::getId).collect(Collectors.toSet());
        Set<String> allFellowMembers = new HashSet<>();
        for (Group group : userGroups) {
            if (group.getMembers() != null) {
                group.getMembers().stream().map(String::toLowerCase).forEach(allFellowMembers::add);
            }
        }
        allFellowMembers.add(lowerCaseUsername);

        List<Schedule> userSchedules = schedules.stream()
            .filter(s -> {
                if (s == null || s.getCreatedBy() == null) return false;
                String scheduleOwner = s.getCreatedBy().toLowerCase();
                String scheduleGroupId = s.getGroupId();
                if (scheduleOwner.equals(lowerCaseUsername)) return true;
                if (scheduleGroupId != null && userGroupIds.contains(scheduleGroupId)) return true;
                if ((scheduleGroupId == null || scheduleGroupId.isEmpty()) && allFellowMembers.contains(scheduleOwner)) return true;
                return false;
            })
            .distinct()
            .collect(Collectors.toList());

        List<ChatMessage> userChats = chatMessages.stream()
            .filter(c -> c.getGroupId() != null && userGroupIds.contains(c.getGroupId()))
            .sorted(Comparator.comparing(ChatMessage::getTimestamp))
            .collect(Collectors.toList());
            
        return new UserData(user, userGroups, userSchedules, userChats);
    }

    public synchronized void addChatMessage(String senderUsername, String groupId, String message) {
        Group targetGroup = groups.get(groupId);
        if (targetGroup == null) {
            ClientHandler senderHandler = connectedClients.get(senderUsername.toLowerCase());
            if (senderHandler != null) senderHandler.sendMessage("ERROR", new ErrorResponse("指定されたグループID '" + groupId + "' は存在しません。"));
            return;
        }
        if (!targetGroup.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(senderUsername))) {
            ClientHandler senderHandler = connectedClients.get(senderUsername.toLowerCase());
            if (senderHandler != null) senderHandler.sendMessage("ERROR", new ErrorResponse("あなたはこのグループ '" + targetGroup.getName() + "' のメンバーではありません。"));
            return;
        }

        ChatMessage chatMessage = new ChatMessage(UUID.randomUUID().toString(), senderUsername, groupId, message, LocalDateTime.now());
        chatMessages.add(chatMessage);
        saveData();
        broadcastToUsers(targetGroup.getMembers(), "CHAT_MESSAGE", chatMessage);
    }

    public synchronized void addSchedule(String createdByUsername, Schedule clientScheduleData) {
        Schedule newSchedule = new Schedule();
        newSchedule.setId(UUID.randomUUID().toString());
        newSchedule.setTitle(clientScheduleData.getTitle());
        newSchedule.setDescription(clientScheduleData.getDescription());
        newSchedule.setStartTime(clientScheduleData.getStartTime());
        newSchedule.setEndTime(clientScheduleData.getEndTime());
        newSchedule.setAllDay(clientScheduleData.isAllDay());
        newSchedule.setPrivate(clientScheduleData.isPrivate());
        newSchedule.setCreatedBy(createdByUsername);

        List<String> participants = new ArrayList<>();
        String groupId = clientScheduleData.getGroupId();
        if (groupId != null && !groupId.trim().isEmpty()) {
            Group group = groups.get(groupId);
            if (group != null && group.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(createdByUsername))) {
                newSchedule.setGroupId(groupId);
                participants.addAll(group.getMembers());
                newSchedule.setPrivate(false);
            } else {
                participants.add(createdByUsername);
            }
        } else {
            participants.add(createdByUsername);
        }
        newSchedule.setParticipants(participants.stream().distinct().collect(Collectors.toList()));
        schedules.add(newSchedule);
        saveData();
        notifyUserDataUpdateToRelevantUsers(newSchedule);
    }
    
    // ★★★ ここから追加 ★★★
    public synchronized boolean updateSchedule(String updaterUsername, Schedule scheduleData) {
        if (scheduleData == null || scheduleData.getId() == null) {
            System.err.println("[Server.updateSchedule] 更新失敗: スケジュールデータまたはIDがnullです。");
            return false;
        }
        Optional<Schedule> scheduleToUpdateOpt = schedules.stream()
                .filter(s -> scheduleData.getId().equals(s.getId()))
                .findFirst();
        if (!scheduleToUpdateOpt.isPresent()) {
            System.err.println("[Server.updateSchedule] 更新失敗: ID " + scheduleData.getId() + " のスケジュールが見つかりません。");
            ClientHandler handler = connectedClients.get(updaterUsername.toLowerCase());
            if (handler != null) handler.sendMessage("ERROR", new ErrorResponse("更新しようとした予定が見つかりませんでした。"));
            return false;
        }
        Schedule existingSchedule = scheduleToUpdateOpt.get();
        // TODO: 権限チェックは今回不要
        existingSchedule.setTitle(scheduleData.getTitle());
        existingSchedule.setDescription(scheduleData.getDescription());
        existingSchedule.setStartTime(scheduleData.getStartTime());
        existingSchedule.setEndTime(scheduleData.getEndTime());
        existingSchedule.setAllDay(scheduleData.isAllDay());
        existingSchedule.setPrivate(scheduleData.isPrivate());
        System.out.println("[Server.updateSchedule] スケジュールID " + existingSchedule.getId() + " が更新されました。");
        saveData();
        notifyUserDataUpdateToRelevantUsers(existingSchedule);
        return true;
    }

    public synchronized boolean deleteSchedule(String deleterUsername, String scheduleId) {
        if (scheduleId == null) {
            System.err.println("[Server.deleteSchedule] 削除失敗: スケジュールIDがnullです。");
            return false;
        }

        Optional<Schedule> scheduleToDeleteOpt = schedules.stream()
                .filter(s -> scheduleId.equals(s.getId()))
                .findFirst();
        
        if (!scheduleToDeleteOpt.isPresent()) {
            System.err.println("[Server.deleteSchedule] 削除失敗: ID " + scheduleId + " のスケジュールが見つかりません。");
            ClientHandler handler = connectedClients.get(deleterUsername.toLowerCase());
            if (handler != null) handler.sendMessage("ERROR", new ErrorResponse("削除しようとした予定が見つかりませんでした。"));
            return false;
        }
        
        Schedule scheduleToDelete = scheduleToDeleteOpt.get(); // 削除されるスケジュールオブジェクトを保持

        // TODO: 権限チェックは今回不要

        boolean removed = schedules.removeIf(s -> scheduleId.equals(s.getId()));

        if (removed) {
            System.out.println("[Server.deleteSchedule] スケジュールID " + scheduleId + " ('" + scheduleToDelete.getTitle() + "') が削除されました。");
            saveData();

            // ★★★ ここを修正 ★★★
            // 削除されたスケジュールの情報を元に、関係者全員に更新を通知する
            notifyUserDataUpdateToRelevantUsers(scheduleToDelete);

        } else {
            System.err.println("[Server.deleteSchedule] 削除失敗（リストからの削除に失敗）: " + scheduleId);
        }

        return removed;
    }
    // ★★★ 追加ここまで ★★★

    public synchronized String createGroup(String groupName, String createdByUsername, List<String> memberUsernames) {
        String groupId = "grp_" + UUID.randomUUID().toString().substring(0, 8);
        Set<String> finalMemberSet = new HashSet<>();
        if (memberUsernames != null) {
            memberUsernames.stream().filter(Objects::nonNull).map(String::toLowerCase).forEach(finalMemberSet::add);
        }
        finalMemberSet.add(createdByUsername.toLowerCase());
        List<String> validMembers = finalMemberSet.stream()
                                              .filter(username -> users.containsKey(username))
                                              .collect(Collectors.toList());
        if (validMembers.isEmpty() || !validMembers.contains(createdByUsername.toLowerCase())) {
            ClientHandler handler = connectedClients.get(createdByUsername.toLowerCase());
            if (handler != null) handler.sendMessage("ERROR", new ErrorResponse("グループ作成失敗: 有効なメンバーが見つからないか、作成者がメンバーに含まれていません。"));
            return null;
        }
        Group newGroup = new Group(groupId, groupName, createdByUsername, new ArrayList<>(validMembers));
        groups.put(groupId, newGroup);
        saveData();
        System.out.println("[Server] グループ '" + groupName + "' が作成されました。メンバー: " + validMembers);
        notifyUserDataUpdate(validMembers);
        return groupId;
    }

    public void notifyUserDataUpdate(List<String> usernamesToNotify) {
        if (usernamesToNotify == null) return;
        Set<String> distinctUsernames = new HashSet<>(usernamesToNotify.stream().map(String::toLowerCase).collect(Collectors.toList()));
        for (String username : distinctUsernames) {
            ClientHandler clientHandler = connectedClients.get(username);
            if (clientHandler != null) {
                UserData userData = getUserData(username);
                if (userData != null) {
                    System.out.println("[Server.notifyUserDataUpdate] ユーザー '" + username + "' にUserDataを送信します。");
                    clientHandler.sendMessage("USER_DATA", userData);
                }
            }
        }
    }
    
    private void notifyUserDataUpdateToRelevantUsers(Schedule schedule) {
        Set<String> relevantUsernames = new HashSet<>();
        String ownerUsername = (schedule.getCreatedBy() != null) ? schedule.getCreatedBy().toLowerCase() : null;

        if (ownerUsername == null) {
            System.err.println("[Server.notify] 作成者不明のスケジュールのため、通知をスキップします: " + schedule.getTitle());
            return;
        }

        // --- 通知対象ユーザーの収集ロジック ---

        // 1. スケジュールの直接の参加者（作成者含む）を追加
        if (schedule.getParticipants() != null) {
            schedule.getParticipants().stream().map(String::toLowerCase).forEach(relevantUsernames::add);
        }
        relevantUsernames.add(ownerUsername); // 作成者は必ず含める

        // 2. グループスケジュールの場合、そのグループの全メンバーを追加
        if (schedule.getGroupId() != null && groups.containsKey(schedule.getGroupId())) {
            groups.get(schedule.getGroupId()).getMembers().stream().map(String::toLowerCase).forEach(relevantUsernames::add);
        } 
        // ★★★ ここからが修正の核心 ★★★
        // 3. 個人スケジュールの場合、その作成者が所属する全グループの全メンバーを追加
        else { 
            // `users`マップからUserオブジェクトを取得し、そのユーザーが所属するグループを特定
            // (getUserData内のロジックを参考に)
            groups.values().stream()
                .filter(g -> g.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(ownerUsername)))
                .forEach(g -> {
                    // そのグループの全メンバーを通知対象に追加
                    g.getMembers().stream().map(String::toLowerCase).forEach(relevantUsernames::add);
                });
        }
        
        System.out.println("[Server.notify] スケジュール変更通知。対象者: " + relevantUsernames);
        notifyUserDataUpdate(new ArrayList<>(relevantUsernames));
    }

    private void broadcastToUsers(List<String> usernames, String messageType, Object data) {
        if (usernames == null) return;
        Set<String> distinctUsernames = new HashSet<>(usernames.stream().map(String::toLowerCase).collect(Collectors.toList()));
        for (String username : distinctUsernames) {
            ClientHandler clientHandler = connectedClients.get(username);
            if (clientHandler != null) {
                clientHandler.sendMessage(messageType, data);
            }
        }
    }

    public static void main(String[] args) {
        Server server = new Server();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("シャットダウンフック: サーバーを安全に停止します...");
            server.stop();
        }));
        server.start();
    }
}