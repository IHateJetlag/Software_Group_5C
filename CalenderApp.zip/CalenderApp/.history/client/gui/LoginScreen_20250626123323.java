package client.gui;

import javax.swing.*;
import java.awt.*;
// import java.awt.event.ActionEvent; // AbstractActionを使っていなければ不要

import client.Connector;
import share.LoginRequest;
import share.ServerMessage;
import share.User;
import share.UserData;
import share.ClientMessage;
import share.LoginResponse;
import share.ErrorResponse;
import share.RegisterRequest; // 新規登録ダイアログで使用

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import share.LocalDateTimeAdapter;
import share.RegisterResponse;

public class LoginScreen implements Connector.MessageListener {

    private static Connector connector;
    private static JFrame loginFrameInstance;
    private static JTextField usernameField;
    private static JPasswordField passwordField;
    private static JButton loginButton;
    private static JButton signupButton;
    private static JLabel statusLabel; // 処理中メッセージ表示用

    private static final Gson gson = new GsonBuilder()
            .registerTypeAdapter(java.time.LocalDateTime.class, new LocalDateTimeAdapter())
            .create();

    // App.javaから呼び出される
    public static void createAndShowLoginGUI(Connector conn) {
        connector = conn;
        LoginScreen instance = new LoginScreen(); // MessageListenerのためにインスタンス生成
        if (connector != null) {
            connector.setMessageListener(instance);
        } else {
            // Connectorがnullの場合のフォールバック処理（エラー表示など）
            // ここではとりあえずコンソールに出力
            System.err.println("FATAL: Connector is null in LoginScreen.createAndShowLoginGUI");
            JOptionPane.showMessageDialog(null, "アプリケーションの初期化に失敗しました。", "致命的なエラー", JOptionPane.ERROR_MESSAGE);
            return;
        }


        loginFrameInstance = new JFrame("ログイン");
        loginFrameInstance.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrameInstance.setSize(400, 280); // 少し高さを増やす for statusLabel

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("ユーザーID:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.gridwidth = 2;
        usernameField = new JTextField(20);
        panel.add(usernameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        panel.add(new JLabel("パスワード:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.gridwidth = 2;
        passwordField = new JPasswordField(20);
        panel.add(passwordField, gbc);

        // ステータス表示用ラベル
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3;
        statusLabel = new JLabel(" ", SwingConstants.CENTER); // 初期は空白
        statusLabel.setForeground(Color.BLUE);
        panel.add(statusLabel, gbc);


        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        loginButton = new JButton("ログイン");
        signupButton = new JButton("新規作成");
        buttonPanel.add(loginButton);
        buttonPanel.add(signupButton);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 3; // gbc.gridy を変更
        gbc.anchor = GridBagConstraints.CENTER;
        // gbc.insets = new Insets(15, 5, 5, 5); // statusLabelがあるので少し調整
        panel.add(buttonPanel, gbc);

        loginButton.addActionListener(e -> handleLoginAttempt());
        passwordField.addActionListener(e -> handleLoginAttempt());

        signupButton.addActionListener(e -> createAndShowSignUpDialog(loginFrameInstance));

        loginFrameInstance.add(panel);
        loginFrameInstance.setLocationRelativeTo(null);
        loginFrameInstance.setVisible(true);
    }

    private static void handleLoginAttempt() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(loginFrameInstance, "ユーザーIDとパスワードを入力してください。", "入力エラー", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (connector == null) {
            JOptionPane.showMessageDialog(loginFrameInstance, "内部エラー: Connectorが未接続です。", "エラー", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // UIを無効化し、ステータスメッセージ表示
        setUIEnabled(false, "サーバーに接続中...");

        // 接続処理を別スレッドで行う (connectがブロッキングする可能性があるため)
        new Thread(() -> {
            if (!connector.isConnected()) {
                if (!connector.connect()) {
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(loginFrameInstance, "サーバーに接続できませんでした。", "接続エラー", JOptionPane.ERROR_MESSAGE);
                        setUIEnabled(true, " "); // UIを有効化、ステータスをクリア
                    });
                    return; // 接続失敗ならここで終了
                }
            }
            // 接続成功、または既に接続済みの場合
            SwingUtilities.invokeLater(() -> setUIEnabled(false, "ログイン処理中..."));

            LoginRequest loginReq = new LoginRequest(username, password);
            ServerMessage serverMsg = new ServerMessage("LOGIN", gson.toJsonTree(loginReq));

            boolean sent = connector.sendMessage(serverMsg);
            if (!sent) {
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(loginFrameInstance, "ログインリクエストの送信に失敗しました。", "送信エラー", JOptionPane.ERROR_MESSAGE);
                    setUIEnabled(true, " ");
                });
            } else {
                System.out.println("ログインリクエストを送信しました。サーバーからの応答待ち...");
                // レスポンスはMessageListenerで非同期に処理される
                // setUIEnabled(false, "サーバー応答待ち..."); // 既に処理中表示
            }
        }).start();
    }

    private static void setUIEnabled(boolean enabled, String statusText) {
        usernameField.setEnabled(enabled);
        passwordField.setEnabled(enabled);
        loginButton.setEnabled(enabled);
        signupButton.setEnabled(enabled);
        statusLabel.setText(statusText != null ? statusText : " ");
    }

    // --- Connector.MessageListener の実装メソッド群 ---
    @Override
    public void onMessageReceived(ClientMessage message) {
        SwingUtilities.invokeLater(() -> { // GUI更新はEDTで！
            setUIEnabled(true, " "); // 何か応答があったらUIを一旦有効化（エラー表示後など）

            System.out.println("[LoginScreen] リスナー受信: Type=" + message.getType());
            if (message.getData() == null && !"SERVER_SHUTDOWN".equals(message.getType())) { // SERVER_SHUTDOWNはdataがnullでもOK
                System.err.println("[LoginScreen] 受信データがnullです: " + message.getType());
                JOptionPane.showMessageDialog(loginFrameInstance, "サーバーから無効な応答を受信しました。", "受信エラー", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                switch (message.getType()) {
                    case "LOGIN_FAILED":
                        LoginResponse loginRes = gson.fromJson(message.getData(), LoginResponse.class);
                        JOptionPane.showMessageDialog(loginFrameInstance, loginRes.getMessage(), "ログイン失敗", JOptionPane.ERROR_MESSAGE);
                        break;
                    case "USER_DATA": // LOGIN_SUCCESS後にこれが送られてくる
                        UserData userData = gson.fromJson(message.getData(), UserData.class);
                        if (userData != null && userData.getUser() != null) {
                            System.out.println("ログイン成功 & UserData受信: " + userData.getUser().getUsername());
                            switchToCalendarScreen(userData.getUser(), userData);
                        } else {
                            JOptionPane.showMessageDialog(loginFrameInstance, "ユーザーデータの取得に失敗しました。", "エラー", JOptionPane.ERROR_MESSAGE);
                        }
                        break;
                    case "REGISTER_SUCCESS": // 新規登録成功
                        RegisterResponse regSuccessRes = gson.fromJson(message.getData(), RegisterResponse.class);
                        JOptionPane.showMessageDialog(loginFrameInstance, regSuccessRes.getMessage() + "\nログインしてください。", "登録成功", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case "REGISTER_FAILED": // 新規登録失敗
                        RegisterResponse regFailRes = gson.fromJson(message.getData(), RegisterResponse.class);
                        JOptionPane.showMessageDialog(loginFrameInstance, regFailRes.getMessage(), "登録失敗", JOptionPane.ERROR_MESSAGE);
                        break;
                    case "ERROR":
                        ErrorResponse errRes = gson.fromJson(message.getData(), ErrorResponse.class);
                        JOptionPane.showMessageDialog(loginFrameInstance, "サーバーエラー: " + errRes.getMessage(), "エラー", JOptionPane.ERROR_MESSAGE);
                        break;
                    case "SERVER_SHUTDOWN":
                        JOptionPane.showMessageDialog(loginFrameInstance, "サーバーがシャットダウンしました。アプリケーションを終了します。", "サーバー停止", JOptionPane.WARNING_MESSAGE);
                        System.exit(0); // アプリケーション終了
                        break;
                    default:
                        System.out.println("[LoginScreen] ログイン画面では未処理のメッセージタイプ: " + message.getType());
                        break;
                }
            } catch (JsonSyntaxException e) {
                System.err.println("[LoginScreen] 受信メッセージのJSONパースエラー: " + e.getMessage());
                JOptionPane.showMessageDialog(loginFrameInstance, "サーバーから不正な形式のデータを受信しました。", "受信エラー", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) { // その他の予期せぬエラー
                System.err.println("[LoginScreen] メッセージ処理中に予期せぬエラー: " + e.getMessage());
                e.printStackTrace();
                JOptionPane.showMessageDialog(loginFrameInstance, "メッセージ処理中に予期せぬエラーが発生しました。", "エラー", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    @Override
    public void onError(String errorMessage) {
        SwingUtilities.invokeLater(() -> {
            setUIEnabled(true, " ");
            JOptionPane.showMessageDialog(loginFrameInstance, errorMessage, "通信エラー", JOptionPane.ERROR_MESSAGE);
        });
    }

    @Override
    public void onDisconnected() {
        SwingUtilities.invokeLater(() -> {
            setUIEnabled(true, " ");
            loginFrameInstance.setTitle("ログイン (サーバー切断)");
            JOptionPane.showMessageDialog(loginFrameInstance, "サーバーから切断されました。再度接続してください。", "接続エラー", JOptionPane.WARNING_MESSAGE);
        });
    }

    private static void switchToCalendarScreen(User loggedInUser, UserData initialUserData) {
        if (loginFrameInstance != null) {
            loginFrameInstance.dispose();
        }
        // Calender画面にMessageListenerを再設定するか、Calender専用のリスナーを作るか検討
        // ここでは、Calenderが自身でサーバーとやり取りすると想定し、LoginScreenのリスナーは解除しないでおく
        // (Calender画面クローズ時にコネクタもクローズするなら、その時点でリスナーも無意味になる)
        Calender mainApp = new Calender(loggedInUser, connector, initialUserData);
        mainApp.createAndShowGUI();
    }

    private static void createAndShowSignUpDialog(JFrame owner) {
        JDialog dialog = new JDialog(owner, "アカウント新規作成", true);
        dialog.setSize(450, 250); // Email削除したので少し小さく
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JTextField usernameFieldDialog = new JTextField(20);
        JPasswordField passwordFieldDialog = new JPasswordField(20);
        JPasswordField confirmPasswordFieldDialog = new JPasswordField(20);

        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(new JLabel("希望ユーザーID:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; inputPanel.add(usernameFieldDialog, gbc);
        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(new JLabel("パスワード:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; inputPanel.add(passwordFieldDialog, gbc);
        gbc.gridx = 0; gbc.gridy = 2; inputPanel.add(new JLabel("パスワード(確認):"), gbc);
        gbc.gridx = 1; gbc.gridy = 2; inputPanel.add(confirmPasswordFieldDialog, gbc);

        JButton registerButton = new JButton("登録");
        JButton cancelButton = new JButton("キャンセル");

        registerButton.addActionListener(e -> {
            String regUsername = usernameFieldDialog.getText().trim();
            String regPassword = new String(passwordFieldDialog.getPassword());
            String regConfirmPassword = new String(confirmPasswordFieldDialog.getPassword());

            if(regUsername.isEmpty() || regPassword.isEmpty()){
                JOptionPane.showMessageDialog(dialog, "ユーザーIDとパスワードを入力してください。", "入力エラー", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if(!regPassword.equals(regConfirmPassword)){
                JOptionPane.showMessageDialog(dialog, "パスワードが一致しません。", "入力エラー", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (connector == null || !connector.isConnected()) {
                 if (connector == null || !connector.connect()){ // 接続試行
                    JOptionPane.showMessageDialog(dialog, "サーバーに接続できませんでした。", "接続エラー", JOptionPane.ERROR_MESSAGE);
                    return;
                 }
            }

            setUIEnabled(false, "登録処理中..."); // メイン画面のUIを無効化
            dialog.setEnabled(false); // ダイアログも一時的に無効化

            RegisterRequest req = new RegisterRequest(regUsername, regPassword);
            ServerMessage msg = new ServerMessage("REGISTER", gson.toJsonTree(req));

            new Thread(() -> {
                boolean sent = connector.sendMessage(msg);
                SwingUtilities.invokeLater(()-> { // UI操作はEDTで
                    if (!sent) {
                        JOptionPane.showMessageDialog(dialog, "登録リクエストの送信に失敗しました。", "送信エラー", JOptionPane.ERROR_MESSAGE);
                    } else {
                        System.out.println("登録リクエストを送信しました。");
                        // 登録成功/失敗のレスポンスは LoginScreen の onMessageReceived で処理される。
                        // ダイアログを閉じて、メインのログイン画面で結果を待つ。
                    }
                    dialog.setEnabled(true);
                    dialog.dispose(); // 応答を待たずにダイアログは閉じる（サーバーからの応答はメイン画面で受ける）
                    setUIEnabled(true, " "); // メイン画面のUIを有効化
                });
            }).start();
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        JPanel buttonPanelDialog = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanelDialog.setBorder(new EmptyBorder(0,10,10,10));
        buttonPanelDialog.add(registerButton);
        buttonPanelDialog.add(cancelButton);

        dialog.add(inputPanel, BorderLayout.CENTER);
        dialog.add(buttonPanelDialog, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
    }
}