// CalenderAppProject/client/gui/LoginScreen.java (修正案)
package client.gui;

import javax.swing.*;
import java.awt.*;
// import java.util.HashMap; // ローカル認証用のMapは不要になる
// import java.util.Map;   // 同上
// import java.util.Random; // 新規登録でランダム色を使っていたが、これもサーバー次第

import client.Connector;      // Connectorクラス
import client.gui.Calender;
import share.LoginRequest;    // shareパッケージのクラス
import share.ServerMessage;
import share.User;            // ログイン成功時に受け取るUser型
import share.UserData;
// import share.RegisterRequest; // 新規登録もサーバー経由にするなら必要

import com.google.gson.Gson; // ServerMessageのdata部を作成するために一時的に使用 (将来的にはConnectorに隠蔽)
import com.google.gson.GsonBuilder;
import share.LocalDateTimeAdapter;


public class LoginScreen {

    // private static final Map<String, String> userCredentials = new HashMap<>(); // ← 削除
    // private static final Map<String, User> userInfo = new HashMap<>();         // ← 削除
    // static { ... } // ← ローカルユーザー情報の初期化ブロックも削除

    private static Connector connector; // Appから渡されるConnectorインスタンスを保持 (static)
    private static JFrame loginFrameInstance; // disposeするために保持

    // Gsonインスタンス (ServerMessageのdata部をJsonElementにするために必要)
    // 本来はConnectorクラスが完全に隠蔽すべきだが、ここでは簡略化のためLoginScreenも一時的に持つ
    private static Gson gson = new GsonBuilder()
            .registerTypeAdapter(java.time.LocalDateTime.class, new LocalDateTimeAdapter())
            .create();


    // App.javaから呼び出されるように引数を追加
    public static void createAndShowLoginGUI(Connector conn) {
        connector = conn; // 渡されたConnectorインスタンスを保持

        loginFrameInstance = new JFrame("ログイン");
        loginFrameInstance.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrameInstance.setSize(400, 250);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("ユーザーID:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.gridwidth = 2;
        JTextField usernameField = new JTextField(20);
        panel.add(usernameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        panel.add(new JLabel("パスワード:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.gridwidth = 2;
        JPasswordField passwordField = new JPasswordField(20);
        panel.add(passwordField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        JButton loginButton = new JButton("ログイン");
        JButton signupButton = new JButton("新規作成"); // 新規登録機能も後でサーバー連携
        buttonPanel.add(loginButton);
        buttonPanel.add(signupButton);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(15, 5, 5, 5);
        panel.add(buttonPanel, gbc);

        loginButton.addActionListener(e -> handleLogin(usernameField.getText(), new String(passwordField.getPassword())));
        passwordField.addActionListener(e -> handleLogin(usernameField.getText(), new String(passwordField.getPassword())));

        signupButton.addActionListener(e -> createAndShowSignUpDialog(loginFrameInstance)); // 引数をインスタンスに

        loginFrameInstance.add(panel);
        loginFrameInstance.setLocationRelativeTo(null);
        loginFrameInstance.setVisible(true);

        // --- MessageListener の設定 (次の段階で実装) ---
        // connector.setMessageListener(new Connector.MessageListener() {
        //     @Override
        //     public void onMessageReceived(share.ClientMessage message) {
        //         // SwingUtilities.invokeLater(() -> { // GUI更新はEDTで
        //             if ("LOGIN_SUCCESS".equals(message.getType())) {
        //                 // share.LoginResponse res = gson.fromJson(message.getData(), share.LoginResponse.class); // (実際はUserデータが必要)
        //                 // ★★★実際にはLOGIN_SUCCESS時にサーバーからUSER_DATAが送られてくるはずなので、それを処理する
        //                 // User loggedInUser = ... ; // USER_DATAからUserオブジェクトを取得
        //                 // switchToCalendarScreen(loggedInUser);
        //                 System.out.println("ログイン成功メッセージ受信 (仮)");
        //             } else if ("LOGIN_FAILED".equals(message.getType())) {
        //                 share.LoginResponse res = gson.fromJson(message.getData(), share.LoginResponse.class);
        //                 JOptionPane.showMessageDialog(loginFrameInstance, res.getMessage(), "ログイン失敗", JOptionPane.ERROR_MESSAGE);
        //             } else if ("USER_DATA".equals(message.getType())) { // LOGIN_SUCCESS後にこれが送られてくる想定
        //                  // ログイン成功時の処理はこちらで行う
        //                  share.UserData userData = gson.fromJson(message.getData(), share.UserData.class);
        //                  if (userData != null && userData.getUser() != null) {
        //                      System.out.println("ユーザーデータ受信: " + userData.getUser().getUsername());
        //                      switchToCalendarScreen(userData.getUser(), userData); // UserData全体も渡す
        //                  } else {
        //                      JOptionPane.showMessageDialog(loginFrameInstance, "ユーザーデータの取得に失敗しました。", "エラー", JOptionPane.ERROR_MESSAGE);
        //                  }
        //             }
        //         // });
        //     }
        //     @Override
        //     public void onError(String errorMessage) {
        //         // SwingUtilities.invokeLater(() -> {
        //             JOptionPane.showMessageDialog(loginFrameInstance, errorMessage, "通信エラー", JOptionPane.ERROR_MESSAGE);
        //         // });
        //     }
        //     @Override
        //     public void onDisconnected() {
        //         // SwingUtilities.invokeLater(() -> {
        //             JOptionPane.showMessageDialog(loginFrameInstance, "サーバーから切断されました。", "接続エラー", JOptionPane.WARNING_MESSAGE);
        //         // });
        //     }
        // });
    }

    private static void handleLogin(String username, String password) {
        if (connector == null) {
            JOptionPane.showMessageDialog(loginFrameInstance, "内部エラー: Connectorが初期化されていません。", "エラー", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!connector.isConnected()) {
            System.out.println("サーバーに接続試行（ログイン時）...");
            if (!connector.connect()) {
                JOptionPane.showMessageDialog(loginFrameInstance, "サーバーに接続できませんでした。", "接続エラー", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        System.out.println("ログインリクエスト送信: " + username);
        LoginRequest loginReq = new LoginRequest(username, password);
        // ServerMessageのdataはJsonElementなので、gsonで変換
        ServerMessage serverMsg = new ServerMessage("LOGIN", gson.toJsonTree(loginReq));
        
        boolean sent = connector.sendMessage(serverMsg);
        if (!sent) {
            JOptionPane.showMessageDialog(loginFrameInstance, "ログインリクエストの送信に失敗しました。", "送信エラー", JOptionPane.ERROR_MESSAGE);
        } else {
            // レスポンスは非同期にMessageListenerで処理されるのを待つ
            System.out.println("ログインリクエストを送信しました。サーバーからの応答待ち...");
            // ここでローディング表示などを出すと良い
        }
    }

    // Calender画面へ遷移するメソッド (MessageListenerから呼ばれる想定)
    private static void switchToCalendarScreen(User loggedInUser, UserData allUserData) {
        if (loginFrameInstance != null) {
            loginFrameInstance.dispose();
        }
        // CalenderのコンストラクタもConnectorとUserDataを受け取るように変更する必要がある
        Calender mainApp = new Calender(loggedInUser, connector, allUserData); // 仮。allUserDataはサーバーから取得した全ユーザー情報ではない点に注意。
                                                                        // Calenderクラスがサーバーから別途ユーザーリスト等を取得する必要がある。
                                                                        // UserData は「ログインユーザーに関連する全データ」
        mainApp.createAndShowGUI();
    }
    
    // 新規登録ダイアログ (これも後でサーバー連携に改修)
    private static void createAndShowSignUpDialog(JFrame owner) {
        // ... (既存のSignUpDialogのコード、ただしユーザー登録処理はサーバーへのREGISTERリクエスト送信に変更する) ...
        // 例:
        // RegisterRequest req = new RegisterRequest(username, password); // emailなし
        // ServerMessage msg = new ServerMessage("REGISTER", gson.toJsonTree(req));
        // connector.sendMessage(msg);
        // 成功/失敗のレスポンスはMessageListenerで処理
        JOptionPane.showMessageDialog(owner, "新規登録機能は現在開発中です。\nサーバー連携が必要です。", "未実装", JOptionPane.INFORMATION_MESSAGE);
    }
}