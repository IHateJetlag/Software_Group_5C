package client.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalDateTime; // ChatMessageで使う
import java.time.YearMonth;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
// import java.util.Scanner; // コンソールリスナーは廃止したので不要
import java.util.stream.Collectors;

// shareパッケージのクラスをインポート
import share.User;
import share.Group;
import share.Schedule;
import share.ChatMessage; // GUIのChatMessageとは別物になる
import share.UserData;
// import share.LocalDateTimeAdapter; // このクラスでは直接使わない

import client.Connector; // Connectorクラス

public class Calender {
    private static final int CALENDAR_ROWS = 6;
    private static final int CALENDAR_COLS = 7;
    private static final String MY_PAGE_ID = "MY_PAGE"; // マイページを示すID

    private JFrame frame;
    private final List<JPanel> datePanels = new ArrayList<>();
    private JPanel monthDisplayPanel;
    private JPanel centerCardPanel;
    private CardLayout centerCardLayout;
    private JPanel sidebarPanel;

    // データ関連のフィールド (shareパッケージの型を使用)
    private share.User myUser;
    private Connector connector;
    private share.UserData currentUserData; // サーバーから取得した初期データ

    private final Map<LocalDate, List<share.Schedule>> schedules = new HashMap<>(); // 日付ごとのスケジュールリスト
    private final List<share.Group> currentGroups = new ArrayList<>(); // ログインユーザーが所属するグループリスト
    private share.Group currentSelectedGroup; // 現在選択されているグループ (マイページの場合はnull)

    private LocalDate currentDate; // カレンダーが表示している月の日付

    // ★★★ コンストラクタを修正 ★★★
    public Calender(share.User loggedInUser, Connector connector, share.UserData initialUserData) {
        this.myUser = loggedInUser;
        this.connector = connector;
        this.currentUserData = initialUserData;

        // currentUserData から必要な情報を展開して、currentGroups や schedules を初期化
        if (this.currentUserData != null) {
            if (this.currentUserData.getGroups() != null) {
                this.currentGroups.addAll(this.currentUserData.getGroups());
            }
            if (this.currentUserData.getSchedules() != null) {
                for (share.Schedule schedule : this.currentUserData.getSchedules()) {
                    if (schedule.getStartTime() != null) { // ScheduleのstartTimeからLocalDateを取得
                        LocalDate date = schedule.getStartTime().toLocalDate();
                        this.schedules.computeIfAbsent(date, k -> new ArrayList<>()).add(schedule);
                    }
                }
            }
        }
        // ChatMessageの初期ロードもここで行うか、グループ選択時に行うか検討
    }

    public void createAndShowGUI() {
        currentDate = LocalDate.now();
        // initializeData(); // ← サーバーからデータをロードするので、このメソッドの役割は変わるか不要になる

        frame = new JFrame("Group-based Application - ログインユーザー: " + (myUser != null ? myUser.getUsername() : "不明"));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 700);

        JPanel mainPanel = createMainLayout();
        frame.add(mainPanel);

        updateHeader();
        updateCalendar(); // 初期表示

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // startConsoleListener(); // ← コンソールリスナーは廃止
    }

    // initializeDataメソッドはサーバーからデータを取得するようになったため、
    // ダミーデータ作成のロジックは不要。
    // サーバーからのデータロードはコンストラクタで行うか、専用メソッドで行う。
    // private void initializeData() { ... } // ← 内容を大幅に変更または削除

    // User名でUserオブジェクトを探す (allUsers は currentUserData.get...() などから取得するか、別途管理)
    // このメソッドはサーバー側のUserリストを元に動作する必要があるため、一旦コメントアウト。
    // 必要であれば、currentUserData内の情報や、サーバーへの問い合わせで実現する。
    // private share.User findUserByName(String name) {
    //     // return allUsers.values().stream()
    //     //         .filter(u -> u.getName().equals(name)) // share.UserにはgetName()がない。getUsername()を使う
    //     //         .findFirst().orElse(null);
    //     return null; // 仮
    // }

    private JPanel createMainLayout() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        sidebarPanel = createSidebarPanel(); // グループアイコンの表示
        centerCardLayout = new CardLayout();
        centerCardPanel = new JPanel(centerCardLayout);

        centerCardPanel.add(createMyPagePanel(), MY_PAGE_ID); // マイページパネル
        for (share.Group group : currentGroups) { // share.Group を使用
            centerCardPanel.add(createChatPanel(group), group.getId()); // グループチャットパネル
        }

        JPanel calenderPanel = createCalendarView(); // カレンダー表示部

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        gbc.gridx = 0; gbc.weightx = 1.0; mainPanel.add(sidebarPanel, gbc);
        gbc.gridx = 1; gbc.weightx = 8.0; mainPanel.add(centerCardPanel, gbc);
        gbc.gridx = 2; gbc.weightx = 11.0; mainPanel.add(calenderPanel, gbc);

        centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
        currentSelectedGroup = null; // 初期はマイページ表示
        return mainPanel;
    }

    private JPanel createSidebarPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Groups"));
        panel.setBackground(new Color(240, 240, 240));

        // マイページアイコン (myUser.getUsername() を使用)
        panel.add(createGroupIcon(MY_PAGE_ID, "マイページ", (myUser != null && myUser.getUsername() != null && !myUser.getUsername().isEmpty()) ? myUser.getUsername().charAt(0) : 'M'));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        for (share.Group group : currentGroups) { // share.Group を使用
            // グループアイコン (group.getName() と、アイコン文字はgroup.getName()の先頭文字など)
            panel.add(createGroupIcon(group.getId(), group.getName(), (!group.getName().isEmpty() ? group.getName().charAt(0) : 'G')));
        }
        panel.add(Box.createVerticalGlue()); // アイコンを上寄せにする
        return panel;
    }

    private Component createGroupIcon(String id, String tooltip, char iconChar) {
        JLabel iconLabel = new JLabel(String.valueOf(iconChar), SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // 選択状態の判定 (currentSelectedGroup を使用)
                boolean isSelected = id.equals(MY_PAGE_ID) ? currentSelectedGroup == null : (currentSelectedGroup != null && id.equals(currentSelectedGroup.getId()));
                if (isSelected) g2.setColor(new Color(66, 133, 244)); // 選択色
                else g2.setColor(Color.LIGHT_GRAY); // 非選択色
                g2.fillOval(5, 5, getWidth() - 10, getHeight() - 10);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        // ... (アイコンの見た目設定は既存のものを流用)
        Dimension iconSize = new Dimension(50, 50);
        iconLabel.setPreferredSize(iconSize);
        iconLabel.setMaximumSize(new Dimension(Short.MAX_VALUE, iconSize.height));
        iconLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        iconLabel.setForeground(Color.WHITE);
        iconLabel.setToolTipText(tooltip);
        iconLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        iconLabel.setBorder(new EmptyBorder(5, 0, 5, 0));

        iconLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (id.equals(MY_PAGE_ID)) {
                    currentSelectedGroup = null; // マイページ選択
                    centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
                } else {
                    currentSelectedGroup = findGroupById(id); // IDでグループを検索
                    if (currentSelectedGroup != null) {
                        centerCardLayout.show(centerCardPanel, id);
                        // チャット履歴のロードなどもここで行う
                        loadChatHistoryForGroup(currentSelectedGroup);
                    }
                }
                sidebarPanel.repaint(); // 選択状態の再描画
                updateCalendar(); // カレンダー表示も更新
            }
        });
        return iconLabel;
    }

    private JPanel createMyPagePanel() {
        JPanel myPagePanel = new JPanel(new BorderLayout());
        myPagePanel.setBackground(Color.WHITE);
        myPagePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);

        // myUser.getUsername() を使用
        JLabel nameLabel = new JLabel((myUser != null ? myUser.getUsername() : "ユーザー名不明"));
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // emailはUserモデルから削除したので、表示しないか別の情報を表示
        // JLabel emailLabel = new JLabel((myUser != null ? myUser.getEmail() : ""));
        // emailLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        // emailLabel.setForeground(Color.GRAY);
        // emailLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        infoPanel.add(nameLabel);
        // infoPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        // infoPanel.add(emailLabel);
        
        myPagePanel.add(infoPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);
        JButton createGroupButton = new JButton("新しいグループを作成");
        createGroupButton.addActionListener(e -> showCreateGroupDialog()); // これはサーバー連携が必要
        buttonPanel.add(createGroupButton);
        // グループ脱退ボタンはここに配置する案もあったが、確定方針ではマイページ全体で所属グループ一覧を出す形
        myPagePanel.add(buttonPanel, BorderLayout.CENTER);

        return myPagePanel;
    }

    private void showCreateGroupDialog() {
        // このメソッドはサーバーに "CREATE_GROUP_WITH_MEMBERS" リクエストを送るように大幅改修が必要 (ステップ2-2)
        // 現状はダミーまたは未実装メッセージ
        JOptionPane.showMessageDialog(frame, "グループ作成機能 (サーバー連携 未実装)", "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createChatPanel(share.Group group) { // 引数を share.Group に
        JPanel chatPanel = new JPanel(new BorderLayout(0, 5));
        chatPanel.setBorder(new EmptyBorder(5,5,5,5)); // TitledBorderの代わりにシンプルな枠線

        // ヘッダーパネル（グループ名とメンバーボタン）
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel(group.getName(), SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        JButton membersButton = new JButton("メンバー");
        membersButton.addActionListener(e -> showGroupMembersDialog(group)); // サーバー連携必要
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.add(membersButton, BorderLayout.EAST);
        chatPanel.add(headerPanel, BorderLayout.NORTH);

        // チャットメッセージ表示エリア
        JPanel messageDisplayArea = new JPanel(); // このJPanelをGroupオブジェクトに保持させるのは避ける
        messageDisplayArea.setLayout(new BoxLayout(messageDisplayArea, BoxLayout.Y_AXIS));
        messageDisplayArea.setBackground(Color.WHITE);
        // group.setMessageArea(messageDisplayArea); // ← Connector経由で更新するので直接Panelを渡さない

        // 初期チャット履歴のロード (グループ選択時 or UserDataに含まれるものを使用)
        // このJPanelは、loadChatHistoryForGroupメソッド内でメッセージが追加される
        
        JScrollPane scrollPane = new JScrollPane(messageDisplayArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        chatPanel.add(scrollPane, BorderLayout.CENTER);

        // チャット入力エリア
        JPanel inputPanel = new JPanel(new BorderLayout(5,5));
        JTextField inputField = new JTextField();
        JButton sendButton = new JButton("送信");

        Action sendMessageAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = inputField.getText().trim();
                if (!text.isEmpty() && connector != null && myUser != null) {
                    // share.ChatRequest を作成してサーバーに送信 (ステップ3-1)
                    // connector.sendMessage(new share.ServerMessage("SEND_CHAT", gson.toJsonTree(new share.ChatRequest(group.getId(), text))));
                    System.out.println("チャット送信(未実装): " + group.getName() + "宛「" + text + "」"); // 仮
                    inputField.setText("");
                    // サーバーからの応答(ブロードキャスト)を待ってUI更新
                }
            }
        };
        inputField.addActionListener(sendMessageAction);
        sendButton.addActionListener(sendMessageAction);
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        chatPanel.add(inputPanel, BorderLayout.SOUTH);

        // ★★★ チャットパネルに名前を付けて、後でメッセージエリアを取得できるようにする
        chatPanel.setName("CHAT_PANEL_" + group.getId());

        return chatPanel;
    }

    // 特定グループのチャット履歴をサーバーから取得して表示 (または currentUserData から)
    private void loadChatHistoryForGroup(share.Group group) {
        // currentUserData.getChats() から該当グループのものをフィルタリングして表示する
        // または、サーバーに "GET_CHAT_HISTORY" リクエストを送る (ステップ3-1)
        System.out.println("[Calender] チャット履歴ロード (未実装): " + group.getName());

        // 対応するチャットパネルのメッセージ表示エリアを取得
        JPanel messageDisplayArea = findMessageDisplayAreaForGroup(group.getId());
        if (messageDisplayArea == null) return;
        messageDisplayArea.removeAll(); // 一旦クリア

        if (currentUserData != null && currentUserData.getChats() != null) {
            currentUserData.getChats().stream()
                .filter(cm -> group.getId().equals(cm.getGroupId()))
                .sorted(Comparator.comparing(share.ChatMessage::getTimestamp)) // 時系列順
                .forEach(chatMessage -> addChatMessageToUI(chatMessage, messageDisplayArea));
        }
        messageDisplayArea.revalidate();
        messageDisplayArea.repaint();
    }

    // チャットパネルIDからメッセージ表示エリアを見つけるヘルパー
    private JPanel findMessageDisplayAreaForGroup(String groupId) {
        String panelName = "CHAT_PANEL_" + groupId;
        for (Component comp : centerCardPanel.getComponents()) {
            if (panelName.equals(comp.getName()) && comp instanceof JPanel) {
                // BorderLayoutの中のJScrollPaneの中のJPanel(messageDisplayArea)を探す
                JPanel chatPanel = (JPanel) comp;
                for(Component chatPanelComp : chatPanel.getComponents()){
                    if(chatPanelComp instanceof JScrollPane){
                        JScrollPane scrollPane = (JScrollPane) chatPanelComp;
                        Component view = scrollPane.getViewport().getView();
                        if(view instanceof JPanel){
                            return (JPanel) view;
                        }
                    }
                }
            }
        }
        return null;
    }


    // チャットメッセージをUIに追加するメソッド (引数に表示先のPanelを取るように変更)
    private void addChatMessageToUI(share.ChatMessage message, JPanel messageDisplayArea) { // share.ChatMessage
        if (messageDisplayArea == null) return;

        JPanel messageBubble = createMessageBubble(message); // share.ChatMessage を渡す
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBorder(new EmptyBorder(2, 5, 2, 5));

        // 送信者が自分かどうか (myUser.getUsername() と message.getSender() を比較)
        if (myUser != null && myUser.getUsername().equals(message.getSender())) {
            wrapper.add(messageBubble, BorderLayout.EAST);
        } else {
            wrapper.add(messageBubble, BorderLayout.WEST);
        }
        messageDisplayArea.add(wrapper);
        messageDisplayArea.revalidate();
        messageDisplayArea.repaint();

        // 自動スクロール (JScrollPaneを親から辿る必要がある)
        // JScrollPane scrollPane = (JScrollPane) SwingUtilities.getAncestorOfClass(JScrollPane.class, messageDisplayArea);
        // if (scrollPane != null) {
        //     JScrollBar verticalScrollBar = scrollPane.getVerticalScrollBar();
        //     SwingUtilities.invokeLater(() -> verticalScrollBar.setValue(verticalScrollBar.getMaximum()));
        // }
    }

    private JPanel createMessageBubble(share.ChatMessage message) { // share.ChatMessage
        JPanel bubble = new JPanel(new BorderLayout(5, 2));
        bubble.setBorder(new EmptyBorder(5, 10, 5, 10));
        
        // 送信者ラベル（自分以外のメッセージの場合）
        if (myUser == null || !myUser.getUsername().equals(message.getSender())) {
            JLabel senderLabel = new JLabel(message.getSender()); // UserオブジェクトではなくString (username)
            senderLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
            senderLabel.setForeground(Color.DARK_GRAY);
            bubble.add(senderLabel, BorderLayout.NORTH);
        }

        JTextArea messageText = new JTextArea(message.getMessage());
        messageText.setEditable(false);
        messageText.setLineWrap(true);
        messageText.setWrapStyleWord(true);
        messageText.setFont(new Font("SansSerif", Font.PLAIN, 14));
        messageText.setOpaque(false); // 背景色はbubble側で設定

        bubble.add(messageText, BorderLayout.CENTER);

        // 背景色 (GUIのUser.colorは廃止したので、固定色ルールで)
        if (myUser != null && myUser.getUsername().equals(message.getSender())) {
            bubble.setBackground(new Color(200, 220, 255)); // 自分のメッセージ色 (例: 薄い青)
        } else {
            bubble.setBackground(new Color(230, 230, 230)); // 他人のメッセージ色 (例: 薄いグレー)
        }
        
        JPanel wrapper = new JPanel(); // サイズ調整用
        wrapper.add(bubble);
        wrapper.setOpaque(false);
        wrapper.setMaximumSize(new Dimension(350, Short.MAX_VALUE)); // 横幅制限
        return wrapper;
    }

    // グループIDでグループオブジェクトを検索 (currentGroupsから)
    private share.Group findGroupById(String id) {
        return currentGroups.stream().filter(g -> g.getId().equals(id)).findFirst().orElse(null);
    }

    private void showGroupMembersDialog(share.Group group) {
        // このメソッドはサーバーに "GET_GROUP_MEMBERS" リクエストを送り、
        // その後 "ADD_GROUP_MEMBER" リクエストを送るように大幅改修が必要 (ステップ2-2)
        JOptionPane.showMessageDialog(frame, "グループメンバー管理 (サーバー連携 未実装)\nグループ: " + group.getName(), "TODO", JOptionPane.INFORMATION_MESSAGE);
    }


    // --- カレンダー関連メソッド ---
    private JPanel createCalendarView() {
        JPanel calendarContainer = new JPanel(new BorderLayout(0, 10));
        calendarContainer.setBorder(new EmptyBorder(5, 5, 5, 5));
        calendarContainer.add(createHeaderPanel(), BorderLayout.NORTH); // 月移動ヘッダー
        calendarContainer.add(createCalendarGridPanel(), BorderLayout.CENTER); // 日付グリッド
        calendarContainer.add(createFooterPanel(), BorderLayout.SOUTH); // 簡易予定追加フッター (これもサーバー連携)
        return calendarContainer;
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(5, 5, 5, 5));
        JButton prevButton = new JButton("<");
        prevButton.addActionListener(e -> {
            currentDate = currentDate.minusMonths(1);
            updateHeader();
            updateCalendar();
        });
        JButton nextButton = new JButton(">");
        nextButton.addActionListener(e -> {
            currentDate = currentDate.plusMonths(1);
            updateHeader();
            updateCalendar();
        });
        monthDisplayPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0)); // 中央に年月表示
        panel.add(prevButton, BorderLayout.WEST);
        panel.add(monthDisplayPanel, BorderLayout.CENTER);
        panel.add(nextButton, BorderLayout.EAST);
        return panel;
    }

    private void updateHeader() {
        monthDisplayPanel.removeAll();
        int year = currentDate.getYear();
        int month = currentDate.getMonthValue();
        JLabel label = new JLabel(String.format("%d年 %d月", year, month));
        label.setFont(new Font("SansSerif", Font.BOLD, 16));
        monthDisplayPanel.add(label);
        monthDisplayPanel.revalidate();
        monthDisplayPanel.repaint();
    }

    private Component createCalendarGridPanel() {
        JPanel gridContainer = new JPanel(new BorderLayout());
        // 曜日表示パネル
        JPanel dayOfWeekPanel = new JPanel(new GridLayout(1, CALENDAR_COLS));
        String[] days = {"日", "月", "火", "水", "木", "金", "土"};
        for (String day : days) {
            JLabel dayLabel = new JLabel(day, JLabel.CENTER);
            if (day.equals("日")) dayLabel.setForeground(Color.RED);
            if (day.equals("土")) dayLabel.setForeground(Color.BLUE);
            dayOfWeekPanel.add(dayLabel);
        }
        // 日付表示グリッドパネル
        JPanel dateGridPanel = new JPanel(new GridLayout(CALENDAR_ROWS, CALENDAR_COLS, 2, 2));
        datePanels.clear(); // 古いパネルをクリア
        for (int i = 0; i < CALENDAR_ROWS * CALENDAR_COLS; i++) {
            JPanel dateCell = new JPanel(new BorderLayout()); // 各日付セル
            dateCell.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            dateGridPanel.add(dateCell);
            datePanels.add(dateCell); // 後でアクセスするためにリストに保持
        }
        gridContainer.add(dayOfWeekPanel, BorderLayout.NORTH);
        gridContainer.add(dateGridPanel, BorderLayout.CENTER);
        return gridContainer;
    }

    private JPanel createFooterPanel() {
        // このフッターからの予定追加もサーバー連携が必要 (ステップ2-1)
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        footerPanel.add(new JLabel("月:"));
        JTextField monthField = new JTextField(String.valueOf(currentDate.getMonthValue()), 2); // 初期値を表示月にする
        footerPanel.add(monthField);
        footerPanel.add(new JLabel("日:"));
        JTextField dayField = new JTextField(2);
        footerPanel.add(dayField);
        footerPanel.add(new JLabel("タイトル:"));
        JTextField titleField = new JTextField(15);
        footerPanel.add(titleField);
        JButton addButton = new JButton("追加");
        addButton.addActionListener(e -> handleAddAppointmentFromFooter(monthField, dayField, titleField));
        footerPanel.add(addButton);
        return footerPanel;
    }

    private void updateCalendar() {
        YearMonth yearMonth = YearMonth.from(currentDate);
        int daysInMonth = yearMonth.lengthOfMonth();
        LocalDate firstOfMonth = currentDate.withDayOfMonth(1);
        // 日曜始まり ( getValue() % 7 だと月曜=1...日曜=0 になる)
        // 日本式の日曜始まりに合わせる場合、(firstOfMonth.getDayOfWeek().getValue() % 7)
        // または、DayOfWeek の getValue() は 月曜=1 ... 日曜=7 なので、そのまま使うか調整
        int startDayOfWeek = firstOfMonth.getDayOfWeek().getValue(); // MONDAY is 1 and SUNDAY is 7
        if (startDayOfWeek == 7) startDayOfWeek = 0; // 日曜を0番目とするため

        for (int i = 0; i < datePanels.size(); i++) {
            JPanel dateCell = datePanels.get(i);
            dateCell.removeAll(); // セルの内容をクリア
            dateCell.setBackground(Color.WHITE);
            dateCell.setName(null); // 日付情報をリセット

            int dayOfMonth = i - startDayOfWeek + 1;

            if (dayOfMonth > 0 && dayOfMonth <= daysInMonth) {
                LocalDate cellDate = LocalDate.of(currentDate.getYear(), currentDate.getMonthValue(), dayOfMonth);
                buildDateCellUI(dateCell, cellDate); // UI構築とデータ表示を分離
                if (cellDate.equals(LocalDate.now())) {
                    dateCell.setBackground(new Color(220, 240, 255)); // 今日の日付を強調
                }
                // 予定の表示は buildDateCellUI 内の updateDateCellView で行う
            }
            dateCell.revalidate();
            dateCell.repaint();
        }
    }

    // 日付セルのUI要素を構築する
    private void buildDateCellUI(JPanel dateCell, LocalDate cellDate) {
        dateCell.setName(cellDate.toString()); // セルに日付情報をセット

        // 日付ラベル
        JLabel dateLabel = new JLabel(String.valueOf(cellDate.getDayOfMonth()), SwingConstants.RIGHT);
        dateLabel.setBorder(new EmptyBorder(2, 0, 0, 4));
        dateCell.add(dateLabel, BorderLayout.NORTH);

        // 予定表示コンテナ
        JPanel appointmentContainer = new JPanel();
        appointmentContainer.setName("appointmentContainer_" + cellDate.toString()); // 一意な名前
        appointmentContainer.setLayout(new BoxLayout(appointmentContainer, BoxLayout.Y_AXIS));
        appointmentContainer.setOpaque(false);
        dateCell.add(new JScrollPane(appointmentContainer), BorderLayout.CENTER); // スクロール可能に

        // 新規追加ボタン
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttonPanel.setOpaque(false);
        JButton addButton = new JButton("+");
        // ... (ボタンのスタイル設定は既存のものを流用)
        addButton.setMargin(new Insets(0, 0, 0, 0));
        addButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        addButton.setFocusable(false);
        SwingUtilities.invokeLater(() -> { // サイズ確定後にボタンサイズ調整
            int height = addButton.getPreferredSize().height;
            if (height > 0) addButton.setPreferredSize(new Dimension(height, height));
            buttonPanel.revalidate();
        });

        addButton.addActionListener(e -> {
            // 新規予定作成ダイアログ表示 (ステップ2-1でサーバー連携)
            // owner は現在のコンテキスト (マイページ or グループ)
            Object ownerContext = (currentSelectedGroup != null) ? (Object) currentSelectedGroup : (Object) myUser;
            showAppointmentDialog(cellDate, null, ownerContext, true); // isEditable = true
        });
        buttonPanel.add(addButton);
        dateCell.add(buttonPanel, BorderLayout.SOUTH);

        // この日付の予定を表示
        updateDateCellView(cellDate);
    }
    
    // 特定の日付セルの予定表示を更新する
    private void updateDateCellView(LocalDate date) {
        JPanel targetCell = null;
        JPanel appointmentContainer = null;

        // まず該当する日付セルと予定コンテナを探す
        for(JPanel panel : datePanels) {
            if (date.toString().equals(panel.getName())) {
                targetCell = panel;
                // "appointmentContainer_YYYY-MM-DD" という名前のコンポーネントを探す
                for (Component comp : ((JScrollPane)targetCell.getComponent(1)).getViewport().getComponents()) { // JScrollPaneの中のJPanel
                     if (comp instanceof JPanel && ("appointmentContainer_" + date.toString()).equals(comp.getName())) {
                        appointmentContainer = (JPanel) comp;
                        break;
                    }
                }
                break;
            }
        }
        if (targetCell == null || appointmentContainer == null) {
             System.err.println("Error: Could not find date cell or appointment container for " + date);
             return;
        }

        appointmentContainer.removeAll(); // 既存の予定表示をクリア

        List<share.Schedule> daySchedules = schedules.getOrDefault(date, new ArrayList<>());

        for (share.Schedule schedule : daySchedules) {
            Object owner = schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername()) ? myUser : findGroupById(schedule.getGroupId());
            if (owner == null && !schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) { // 他人の個人予定の場合
                owner = findUserByUsernameInCurrentData(schedule.getCreatedBy());
            }


            boolean shouldDisplay = false;
            // 表示判定ロジック (No.3で確定したものを元に)
            if (currentSelectedGroup == null) { // マイページ表示時
                if (schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) { // 自分の個人予定
                    shouldDisplay = true;
                } else if (schedule.getGroupId() != null) { // グループ予定
                    share.Group g = findGroupById(schedule.getGroupId());
                    if (g != null && g.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(myUser.getUsername()))) {
                        shouldDisplay = true;
                    }
                }
            } else { // グループページ表示時
                if (schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) { // 自分の個人予定
                    shouldDisplay = true;
                } else if (schedule.getGroupId() != null && schedule.getGroupId().equals(currentSelectedGroup.getId())) { // 現在選択中グループの共有予定
                    shouldDisplay = true;
                } else if (schedule.getGroupId() == null || schedule.getGroupId().isEmpty()) { // 他人の個人予定
                    // このグループのメンバーの個人予定か？
                    if (currentSelectedGroup.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(schedule.getCreatedBy()))) {
                         shouldDisplay = true;
                    }
                }
            }


            if (shouldDisplay) {
                String displayTitle = schedule.getTitle();
                boolean isPrivateView = !schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername()) && schedule.isPrivate() && currentSelectedGroup != null;

                if (isPrivateView) {
                    displayTitle = "（非公開の予定）";
                }

                JButton appButton = new JButton("<html>" + displayTitle + "</html>");
                appButton.setOpaque(true); // 背景色を有効にするため

                // 背景色設定 (No.8で確定したルール)
                if (schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) { // 自分の個人予定
                    appButton.setBackground(new Color(135, 206, 250)); // 青色系
                } else if (schedule.getGroupId() != null && !schedule.getGroupId().isEmpty()) { // グループ共有予定
                    appButton.setBackground(new Color(144, 238, 144)); // 緑色系
                } else { // 他人の個人予定（公開）
                    appButton.setBackground(new Color(220, 220, 220)); // 灰色系
                }
                
                // クリックアクション (No.3, No.4で確定した権限制御)
                boolean isEditable = schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername()) || (schedule.getGroupId() != null && !schedule.getGroupId().isEmpty());

                if (isPrivateView) { // 他人の非公開予定はクリック不可
                    appButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                } else {
                    appButton.addActionListener(e -> showAppointmentDialog(date, schedule, owner, isEditable));
                    appButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                }
                appointmentContainer.add(appButton);
            }
        }
        appointmentContainer.revalidate();
        appointmentContainer.repaint();
    }
    
    // UserDataからユーザー名でUserオブジェクトを探すヘルパー（主に他人の予定のowner特定用）
    private share.User findUserByUsernameInCurrentData(String username) {
        if (currentUserData == null || currentUserData.getSchedules() == null) return null; // UserDataに全ユーザーリストはない
        // このメソッドは、サーバーから全ユーザーリストを取得する仕組みがないと完全には機能しない
        // 現状は、もし自分のデータならmyUserを返す程度
        if (myUser != null && myUser.getUsername().equalsIgnoreCase(username)) return myUser;
        
        // ダミーのUserを返すか、nullを返すか。
        // 本来はサーバーに問い合わせるか、初期データで全ユーザー情報を持つ必要がある。
        // ここでは、見つからなければnullを返す。
        return null;
    }


    private void handleAddAppointmentFromFooter(JTextField monthField, JTextField dayField, JTextField titleField) {
        // このメソッドはサーバーに "ADD_SCHEDULE" リクエストを送るように大幅改修が必要 (ステップ2-1)
        try {
            int month = Integer.parseInt(monthField.getText());
            int day = Integer.parseInt(dayField.getText());
            String title = titleField.getText().trim();
            if (title.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "タイトルを入力してください。", "入力エラー", JOptionPane.WARNING_MESSAGE);
                return;
            }
            // ... (日付のバリデーション) ...
            LocalDate targetDate = LocalDate.of(currentDate.getYear(), month, day);

            Object ownerContext = (currentSelectedGroup != null) ? (Object) currentSelectedGroup : (Object) myUser;
            
            // share.Schedule を作成
            share.Schedule newSchedule = new share.Schedule();
            newSchedule.setTitle(title);
            newSchedule.setDescription(""); // 詳細なし
            newSchedule.setCreatedBy(myUser.getUsername());
            newSchedule.setAllDay(true); // フッターからは終日予定として作成
            newSchedule.setPrivate(false); // デフォルトは公開
            newSchedule.setStartTime(targetDate.atStartOfDay());
            newSchedule.setEndTime(targetDate.atTime(23,59,59));

            if (ownerContext instanceof share.Group) {
                newSchedule.setGroupId(((share.Group) ownerContext).getId());
            }
            
            // connector.sendMessage(new share.ServerMessage("ADD_SCHEDULE", gson.toJsonTree(newSchedule)));
            System.out.println("フッターから予定追加(未実装): " + title); // 仮
            
            monthField.setText(String.valueOf(currentDate.getMonthValue()));
            dayField.setText("");
            titleField.setText("");
            // サーバーからの応答を待ってカレンダー更新
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "入力が正しくありません。", "エラー", JOptionPane.ERROR_MESSAGE);
        }
    }

    // 予定の追加/更新 (サーバー連携後は、サーバーからの応答でUIを更新する形になる)
    // public void addOrUpdateAppointment(LocalDate date, share.Schedule schedule) { ... } // 削除または大幅変更

    // 予定の削除 (サーバー連携後は、サーバーからの応答でUIを更新する形になる)
    // public void removeAppointment(LocalDate date, share.Schedule schedule) { ... } // 削除または大幅変更


    // ★★★ showAppointmentDialog の引数と内部処理を share.Schedule ベースに修正 ★★★
    private void showAppointmentDialog(LocalDate date, share.Schedule schedule, Object ownerContext, boolean isEditable) {
        boolean isNew = (schedule == null); // 新規作成かどうか
        share.Schedule targetSchedule;

        if (isNew) {
            targetSchedule = new share.Schedule(); // 新しいScheduleオブジェクト
            targetSchedule.setCreatedBy(myUser.getUsername());
            targetSchedule.setAllDay(true); // 新規作成時はデフォルトで終日
            targetSchedule.setPrivate(false); // デフォルトは公開
            targetSchedule.setStartTime(date.atStartOfDay()); // とりあえず日付だけセット
            targetSchedule.setEndTime(date.atTime(23,59,59));
            if (ownerContext instanceof share.Group) {
                targetSchedule.setGroupId(((share.Group) ownerContext).getId());
            }
        } else {
            targetSchedule = schedule; // 既存のScheduleオブジェクト
        }
        
        // AppointmentDialogのコンストラクタもshare.Scheduleを受け取るように変更が必要
        AppointmentDialog dialog = new AppointmentDialog(frame, targetSchedule, isNew, isEditable, (ownerContext instanceof share.User));
        dialog.setVisible(true);

        int result = dialog.getResult();
        if (result == AppointmentDialog.OPTION_SAVE) {
            share.Schedule savedSchedule = dialog.getSchedule(); // ダイアログからshare.Scheduleを取得
            if (isNew) {
                // connector.sendMessage(new share.ServerMessage("ADD_SCHEDULE", gson.toJsonTree(savedSchedule)));
                System.out.println("新規予定保存(未実装): " + savedSchedule.getTitle());
            } else {
                // connector.sendMessage(new share.ServerMessage("UPDATE_SCHEDULE", gson.toJsonTree(savedSchedule))); // UPDATE APIが必要
                System.out.println("予定更新(未実装): " + savedSchedule.getTitle());
            }
            // サーバーからの応答を待ってカレンダー更新 (UserData再取得など)
        } else if (result == AppointmentDialog.OPTION_DELETE && !isNew) {
            // connector.sendMessage(new share.ServerMessage("DELETE_SCHEDULE", gson.toJsonTree(targetSchedule))); // IDだけでも良い
            System.out.println("予定削除(未実装): " + targetSchedule.getTitle());
            // サーバーからの応答を待ってカレンダー更新
        }
    }


    // startConsoleListener は廃止
    // handleChatCommand, handleAppointmentCommand もコンソールリスナーと共に廃止
    // findUserInCurrentGroup も、サーバー連携後は役割が変わるか不要になる

    // =================================================================
    // 内部クラス定義 (shareパッケージのものを使うため、ここは大幅に変わる)
    // =================================================================

    // AppointmentDialog は share.Schedule を扱うように大幅な改修が必要
    // ひとまずコンパイルエラーを避けるために、フィールドやメソッドの型を合わせる
    static class AppointmentDialog extends JDialog {
        public static final int OPTION_SAVE = 1, OPTION_DELETE = 2, OPTION_CANCEL = 0;
        private int result = OPTION_CANCEL;
        private JTextField titleField;
        private JTextArea detailsArea;
        private JCheckBox privateCheckBox;
        private JCheckBox allDayCheckBox; // 時間指定/終日チェックボックス
        private JSpinner startTimeSpinner; // 開始時間スピナー
        private JSpinner endTimeSpinner;   // 終了時間スピナー
        private JLabel timeLabel;

        private share.Schedule currentSchedule; // 編集対象のSchedule
        private boolean isOwnerUser; // この予定のownerがUserかGroupか

        public AppointmentDialog(Frame ownerFrame, share.Schedule schedule, boolean isNew, boolean isEditable, boolean isOwnerUser) {
            super(ownerFrame, true);
            this.currentSchedule = schedule; // 渡されたScheduleを保持
            this.isOwnerUser = isOwnerUser;

            String dialogTitle = isNew ? "予定の新規作成" : (isEditable ? "予定の編集/削除" : "予定の詳細");
            setTitle(dialogTitle);

            // --- UIコンポーネントの初期化 ---
            titleField = new JTextField(schedule.getTitle(), 20);
            detailsArea = new JTextArea(schedule.getDescription(), 5, 20); // getDescription()
            detailsArea.setLineWrap(true);
            detailsArea.setWrapStyleWord(true);

            privateCheckBox = new JCheckBox("非公開の予定にする");
            privateCheckBox.setSelected(schedule.isPrivate());
            privateCheckBox.setVisible(isOwnerUser); // 個人の予定の場合のみ表示 (ownerがUserの場合)

            allDayCheckBox = new JCheckBox("終日の予定");
            allDayCheckBox.setSelected(schedule.isAllDay());

            // 時刻入力用スピナー (SpinnerDateModelを使用)
            // 初期値はScheduleのstartTime/endTimeから。nullの場合は現在時刻など。
            SpinnerDateModel startModel = new SpinnerDateModel();
            startModel.setValue(schedule.getStartTime() != null ? java.sql.Timestamp.valueOf(schedule.getStartTime()) : new java.util.Date());
            startTimeSpinner = new JSpinner(startModel);
            JSpinner.DateEditor startTimeEditor = new JSpinner.DateEditor(startTimeSpinner, "HH:mm");
            startTimeSpinner.setEditor(startTimeEditor);

            SpinnerDateModel endModel = new SpinnerDateModel();
            endModel.setValue(schedule.getEndTime() != null ? java.sql.Timestamp.valueOf(schedule.getEndTime()) : new java.util.Date());
            endTimeSpinner = new JSpinner(endModel);
            JSpinner.DateEditor endTimeEditor = new JSpinner.DateEditor(endTimeSpinner, "HH:mm");
            endTimeSpinner.setEditor(endTimeEditor);
            
            timeLabel = new JLabel("時間:");


            // 終日チェックボックスのアクションリスナー
            allDayCheckBox.addActionListener(e -> {
                boolean isAllDay = allDayCheckBox.isSelected();
                startTimeSpinner.setVisible(!isAllDay);
                endTimeSpinner.setVisible(!isAllDay);
                timeLabel.setVisible(!isAllDay);

            });
            // 初期状態の反映
            startTimeSpinner.setVisible(!schedule.isAllDay());
            endTimeSpinner.setVisible(!schedule.isAllDay());
            timeLabel.setVisible(!schedule.isAllDay());


            JLabel ownerDisplayLabel = new JLabel(); // 所有者表示ラベル (UserかGroupか)
            ownerDisplayLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            ownerDisplayLabel.setForeground(Color.GRAY);
            if (schedule.getGroupId() != null && !schedule.getGroupId().isEmpty()) {
                // グループ名を取得する必要がある。CalenderクラスのfindGroupByIdなどを呼び出すか、
                // Groupオブジェクトを直接渡せるようにするか検討が必要。
                // ここでは仮にgroupIdを表示。
                ownerDisplayLabel.setText("共有グループ: " + schedule.getGroupId());
            } else {
                ownerDisplayLabel.setText("所有者: " + schedule.getCreatedBy() + " (個人)");
            }

            // --- ボタン ---
            JPanel buttonPanelContainer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            if (isEditable) {
                JButton saveButton = new JButton("保存");
                saveButton.addActionListener(e -> { result = OPTION_SAVE; dispose(); });
                buttonPanelContainer.add(saveButton);

                if (!isNew) {
                    JButton deleteButton = new JButton("削除");
                    deleteButton.addActionListener(e -> {
                        if (JOptionPane.showConfirmDialog(this, "この予定を削除しますか？", "確認", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                            result = OPTION_DELETE;
                            dispose();
                        }
                    });
                    buttonPanelContainer.add(deleteButton);
                }
                JButton cancelButton = new JButton("キャンセル");
                cancelButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(cancelButton);
            } else { // 閲覧モード
                JButton closeButton = new JButton("閉じる");
                closeButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(closeButton);
                // 閲覧モードでは編集不可に
                titleField.setEditable(false);
                detailsArea.setEditable(false);
                privateCheckBox.setEnabled(false);
                allDayCheckBox.setEnabled(false);
                startTimeSpinner.setEnabled(false);
                endTimeSpinner.setEnabled(false);
                titleField.setFocusable(false); // カーソル非表示
                detailsArea.setFocusable(false);
            }

            // --- レイアウト ---
            JPanel fieldsPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST; gbc.insets = new Insets(2,2,2,2);
            fieldsPanel.add(new JLabel("タイトル:"), gbc);
            gbc.gridx = 1; gbc.gridy = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(titleField, gbc);

            gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
            fieldsPanel.add(new JLabel("詳細:"), gbc);
            gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
            fieldsPanel.add(new JScrollPane(detailsArea), gbc);
            
            gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weighty = 0;
            fieldsPanel.add(allDayCheckBox, gbc);

            JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5,0));
            timePanel.add(timeLabel);
            timePanel.add(startTimeSpinner);
            timePanel.add(new JLabel("～"));
            timePanel.add(endTimeSpinner);
            gbc.gridx = 1; gbc.gridy = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
            fieldsPanel.add(timePanel, gbc);


            if (isOwnerUser) { // 個人の予定の場合のみ非公開チェックボックスを表示
                 gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
                 fieldsPanel.add(privateCheckBox, gbc);
            }


            JPanel mainContentPanel = new JPanel(new BorderLayout(5,5));
            mainContentPanel.setBorder(new EmptyBorder(10,10,10,10));
            mainContentPanel.add(fieldsPanel, BorderLayout.CENTER);

            JPanel southPanel = new JPanel(new BorderLayout());
            southPanel.add(ownerDisplayLabel, BorderLayout.WEST);
            southPanel.add(buttonPanelContainer, BorderLayout.EAST);

            getContentPane().add(mainContentPanel, BorderLayout.CENTER);
            getContentPane().add(southPanel, BorderLayout.SOUTH);
            pack();
            setLocationRelativeTo(ownerFrame);
        }

        public int getResult() { return result; }

        public share.Schedule getSchedule() {
            // ダイアログの入力内容から share.Schedule オブジェクトを生成して返す
            currentSchedule.setTitle(titleField.getText());
            currentSchedule.setDescription(detailsArea.getText());
            currentSchedule.setPrivate(isOwnerUser && privateCheckBox.isSelected());
            currentSchedule.setAllDay(allDayCheckBox.isSelected());

            if (!currentSchedule.isAllDay()) {
                // JSpinnerからLocalDateTimeを取得
                Date startTimeDate = (Date) startTimeSpinner.getValue();
                Date endTimeDate = (Date) endTimeSpinner.getValue();
                // LocalDate部分は元のスケジュールの日付部分を維持する
                LocalDate scheduleDate = currentSchedule.getStartTime().toLocalDate();

                currentSchedule.setStartTime(LocalDateTime.of(scheduleDate,
                        LocalDateTime.ofInstant(startTimeDate.toInstant(), ZoneId.systemDefault()).toLocalTime()));
                currentSchedule.setEndTime(LocalDateTime.of(scheduleDate,
                        LocalDateTime.ofInstant(endTimeDate.toInstant(), ZoneId.systemDefault()).toLocalTime()));
            } else {
                // 終日の場合は、日付部分の00:00と23:59:59を設定
                 LocalDate scheduleDate = currentSchedule.getStartTime().toLocalDate();
                 currentSchedule.setStartTime(scheduleDate.atStartOfDay());
                 currentSchedule.setEndTime(scheduleDate.atTime(23,59,59));
            }
            return currentSchedule;
        }
    }
}