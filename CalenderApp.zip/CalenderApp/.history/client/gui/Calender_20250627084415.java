package client.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import java.util.Set;
import java.util.Comparator;
import java.util.Date;
import java.util.Calendar; // JSpinnerのDateModelで使用
import java.util.stream.Collectors;
import java.time.LocalTime;

// shareパッケージのクラスをインポート
import share.User;
import share.Group;
import share.Schedule;
import share.ChatMessage;
import share.UserData;
import share.ServerMessage;
import share.ClientMessage;
import share.ErrorResponse;
import client.Connector;

public class Calender implements Connector.MessageListener {
    private static final int CALENDAR_ROWS = 6;
    private static final int CALENDAR_COLS = 7;
    private static final String MY_PAGE_ID = "MY_PAGE_VIEW";

    private JFrame frame;
    private final List<JPanel> datePanels = new ArrayList<>();
    private JPanel monthDisplayPanel;
    private JPanel centerCardPanel;
    private CardLayout centerCardLayout;
    private JPanel sidebarPanel;
    private static final Gson gson = new GsonBuilder()
            .registerTypeAdapter(java.time.LocalDateTime.class, new share.LocalDateTimeAdapter())
            .create();

    private share.User myUser;
    private Connector connector;
    private share.UserData currentUserData;

    private final Map<LocalDate, List<share.Schedule>> displayedSchedules = new HashMap<>();
    private final List<share.Group> myGroups = new ArrayList<>();
    private share.Group currentSelectedGroup;

    private LocalDate currentDateForCalendar;
    private DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    private DateTimeFormatter chatTimestampFormatter = DateTimeFormatter.ofPattern("MM/dd HH:mm");

    public Calender(share.User loggedInUser, Connector connector, share.UserData initialUserData) {
        this.myUser = loggedInUser;
        this.connector = connector;
        this.currentUserData = initialUserData;

        // ★★★ ConnectorのリスナーをこのCalenderインスタンスに設定 ★★★
        if (this.connector != null) {
            this.connector.setMessageListener(this);
        }

        // 初期データの展開
        updateLocalDataFromUserData();
    }

    private void updateLocalDataFromUserData() {
        this.myGroups.clear();
        if (this.currentUserData != null && this.currentUserData.getGroups() != null) {
            this.myGroups.addAll(this.currentUserData.getGroups());
            System.out.println("[Calender] Local data updated. Group count: " + this.myGroups.size());
        }
    }

   public void createAndShowGUI() {
        currentDateForCalendar = LocalDate.now();
        frame = new JFrame("カレンダー共有アプリ - " + (myUser != null ? myUser.getUsername() : "ゲスト"));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // ウィンドウを閉じる時に切断処理を行う
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                if (connector != null && connector.isConnected()) {
                    System.out.println("ウィンドウを閉じるため、サーバーから切断します。");
                    connector.disconnect();
                }
            }
        });
        frame.setSize(1200, 800);
        JPanel mainPanel = createMainLayout();
        frame.add(mainPanel);
        updateHeaderDateDisplay();
        updateCalendarView();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createMainLayout() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        sidebarPanel = new JPanel(); // まず空のパネルとして初期化
        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS)); // レイアウトを設定
        updateSidebar(); // myGroupsを元に中身を構築

        centerCardPanel = new JPanel(new CardLayout());
        updateCenterPanels(MY_PAGE_ID); // myGroupsを元にチャットパネルなどを構築

        JPanel calendarDisplayPanel = createCalendarDisplayPanel();

        gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.15; gbc.gridheight = 2; mainPanel.add(sidebarPanel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.35; gbc.gridheight = 1; mainPanel.add(centerCardPanel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 0.35; gbc.weighty = 0.05; gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(createFooterActionPanel(), gbc);
        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0.5; gbc.gridheight = 2; gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
        mainPanel.add(calendarDisplayPanel, gbc);

        centerCardLayout = (CardLayout) centerCardPanel.getLayout();
        centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
        currentSelectedGroup = null;
        return mainPanel;
    }

    private void updateSidebar() {
        sidebarPanel.removeAll(); // 中身をクリア
        sidebarPanel.setBorder(BorderFactory.createTitledBorder("ナビゲーション"));
        sidebarPanel.setBackground(new Color(230, 240, 255));

        String myUsername = (myUser != null && myUser.getUsername() != null) ? myUser.getUsername() : "User";
        char myInitial = myUsername.isEmpty() ? 'U' : myUsername.charAt(0);
        sidebarPanel.add(createGroupIcon(MY_PAGE_ID, "マイページ (" + myUsername + ")", myInitial, true));
        sidebarPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        sidebarPanel.add(new JSeparator());
        sidebarPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel groupListLabel = new JLabel("所属グループ");
        groupListLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        groupListLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebarPanel.add(groupListLabel);
        sidebarPanel.add(Box.createRigidArea(new Dimension(0,5)));

        if (myGroups.isEmpty()) {
            JLabel noGroupLabel = new JLabel(" (なし) ");
            noGroupLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            noGroupLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebarPanel.add(noGroupLabel);
        } else {
            for (share.Group group : myGroups) {
                char groupInitial = group.getName().isEmpty() ? 'G' : group.getName().charAt(0);
                sidebarPanel.add(createGroupIcon(group.getId(), group.getName(), groupInitial, false));
            }
        }
        sidebarPanel.add(Box.createVerticalGlue());
        sidebarPanel.revalidate();
        sidebarPanel.repaint();
    }

    // ★★★ 中央パネルの中身を更新するメソッド ★★★
    private void updateCenterPanels(String cardIdToShowAfterUpdate) {
    System.out.println("  [updateCenterPanels] 開始。再表示するカードID: " + cardIdToShowAfterUpdate); // ★デバッグログ
    centerCardPanel.removeAll(); // 中身をクリア

    // マイページと各グループのパネルを再追加
    JPanel myPagePanel = createMyPagePanel();
    myPagePanel.setName(MY_PAGE_ID); // ★★★ 明示的に名前を設定 ★★★
    centerCardPanel.add(myPagePanel, MY_PAGE_ID);
    System.out.println("    - マイページパネルを追加: " + MY_PAGE_ID);

    for (share.Group group : myGroups) {
        if (group != null && group.getId() != null) {
            JPanel chatPanel = createChatPanel(group);
            // chatPanel.setName(group.getId()); // createChatPanel内で設定済みのはずだが念のため
            centerCardPanel.add(chatPanel, group.getId());
            System.out.println("    - チャットパネルを追加: " + group.getId() + " (" + group.getName() + ")");
        }
    }
    
    CardLayout cl = (CardLayout) centerCardPanel.getLayout();

    // ★★★ 実際にCardLayoutに追加されたコンポーネントの名前を確認するログ ★★★
    System.out.println("    - 再構築後のCardPanel内のコンポーネント:");
    for (Component comp : centerCardPanel.getComponents()) {
        System.out.println("      - Name: " + comp.getName() + ", Class: " + comp.getClass().getSimpleName());
    }
    
    // 指定されたカードが存在するか確認
    boolean cardFound = false;
    for (int i = 0; i < centerCardPanel.getComponentCount(); i++) {
        // CardLayoutでは、コンポーネント追加時の制約文字列(ID)は、直接comp.getName()で取れない場合がある。
        // より確実な方法は、CardLayoutの内部データ構造を調べるか、
        // あるいは、追加時にJPanelにsetName()で名前を付けておくこと。
        // 上記で setName() をしたので、comp.getName() で比較する。
        Component comp = centerCardPanel.getComponent(i);
        if (cardIdToShowAfterUpdate.equals(comp.getName())) {
            cardFound = true;
            break;
        }
    }

    if (cardFound) {
        cl.show(centerCardPanel, cardIdToShowAfterUpdate);
        System.out.println("  -> UI更新後、カード '" + cardIdToShowAfterUpdate + "' を再表示しました。");
    } else {
        System.out.println("  -> UI更新後、カード '" + cardIdToShowAfterUpdate + "' が見つからないため、マイページにフォールバックします。");
        cl.show(centerCardPanel, MY_PAGE_ID);
        // ★★★ ここで currentSelectedGroup が null になってしまうのを防ぐ ★★★
        // もし、更新の結果 myGroups から currentSelectedGroup が削除されていたら null にするのは正しい。
        if (currentSelectedGroup != null && !myGroups.contains(currentSelectedGroup)) {
            System.out.println("      -> 選択されていたグループが更新後のリストに存在しないため、選択を解除します。");
            this.currentSelectedGroup = null;
        }
    }

    centerCardPanel.revalidate();
    centerCardPanel.repaint();
}

    private Component createGroupIcon(String id, String tooltip, char iconChar, boolean isMyPageIcon) {
        JButton iconButton = new JButton(String.valueOf(iconChar));
        iconButton.setToolTipText(tooltip);
        Dimension iconSize = new Dimension(60, 60);
        iconButton.setPreferredSize(iconSize);
        iconButton.setMinimumSize(iconSize);
        iconButton.setMaximumSize(new Dimension(Short.MAX_VALUE, iconSize.height));
        iconButton.setFont(new Font("SansSerif", Font.BOLD, 28));
        iconButton.setForeground(Color.WHITE);
        iconButton.setFocusPainted(false);
        iconButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        iconButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        iconButton.setContentAreaFilled(false);
        iconButton.setBorderPainted(false);
        iconButton.setName("ICON_BTN_" + id);

        iconButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String previousSelectedGroupId = (currentSelectedGroup != null) ? currentSelectedGroup.getId() : MY_PAGE_ID;
                if (id.equals(MY_PAGE_ID)) {
                    currentSelectedGroup = null;
                    centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
                } else {
                    currentSelectedGroup = findGroupByIdFromLocalList(id);
                    if (currentSelectedGroup != null) {
                        centerCardLayout.show(centerCardPanel, id);
                        loadChatHistoryForGroup(currentSelectedGroup);
                    } else {
                        System.err.println("Error: Group with ID " + id + " not found in local list for icon click.");
                        currentSelectedGroup = null;
                        centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
                    }
                }
                if (!Objects.equals(id, previousSelectedGroupId)) {
                    updateSidebarSelectionHighlight();
                }
                updateCalendarView();
            }
        });
        JPanel iconWrapper = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean isSelected = id.equals(MY_PAGE_ID) ? currentSelectedGroup == null : (currentSelectedGroup != null && id.equals(currentSelectedGroup.getId()));
                Color baseColor = isMyPageIcon ? new Color(70, 130, 180) : new Color(60, 179, 113);
                g2.setColor(isSelected ? baseColor.darker().darker() : baseColor);
                g2.fillOval(5, 5, getWidth() - 10, getHeight() - 10);
                if (isSelected) {
                    g2.setColor(Color.ORANGE.darker());
                    g2.setStroke(new BasicStroke(3));
                    g2.drawOval(3, 3, getWidth() - 7, getHeight() - 7);
                }
                g2.dispose();
            }
        };
        iconWrapper.add(iconButton, BorderLayout.CENTER);
        iconWrapper.setOpaque(false);
        iconWrapper.setBorder(new EmptyBorder(5,10,5,10));
        iconWrapper.setMaximumSize(new Dimension(Short.MAX_VALUE, iconSize.height + 10));
        return iconWrapper;
    }
    
    private void updateSidebarSelectionHighlight() {
        sidebarPanel.repaint();
    }

    private JPanel createMyPagePanel() {
        JPanel myPagePanel = new JPanel(new BorderLayout(10,10));
        myPagePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        myPagePanel.setBackground(Color.WHITE);
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);
        JLabel nameLabel = new JLabel("ようこそ、" + (myUser != null ? myUser.getUsername() : "ゲスト") + " さん");
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        infoPanel.add(nameLabel);
        myPagePanel.add(infoPanel, BorderLayout.NORTH);
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        actionPanel.setOpaque(false);
        JButton createGroupButton = new JButton("新しいグループを作成");
        createGroupButton.addActionListener(e -> showCreateGroupDialog());
        actionPanel.add(createGroupButton);
        myPagePanel.add(actionPanel, BorderLayout.CENTER);
        return myPagePanel;
    }

    private void showCreateGroupDialog() {
        if (connector == null || !connector.isConnected()) {
            JOptionPane.showMessageDialog(frame, "サーバーに接続されていません。", "エラー", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // --- ローディング表示 ---
        JDialog loadingDialog = new JDialog(frame, "処理中...", true);
        loadingDialog.setSize(250, 100);
        loadingDialog.setLocationRelativeTo(frame);
        loadingDialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE); // ×で閉じられないように
        loadingDialog.add(new JLabel("全ユーザー情報を取得しています...", SwingConstants.CENTER));
        
        // --- 一時的なリスナーを設定して、"ALL_USERS_LIST" の応答を待つ ---
        Connector.MessageListener originalListener = connector.getMessageListener(); // 現在のリスナー(Calender自身)を退避
        
        Connector.MessageListener tempListener = new Connector.MessageListener() {
            @Override
            public void onMessageReceived(ClientMessage message) {
                SwingUtilities.invokeLater(() -> {
                    if (message == null || message.getType() == null) {
                        System.err.println("[Calender Listener] Invalid message received.");
                        return;
                    }
                    
                    System.out.println("[Calender Listener] メインリスナーがメッセージ受信: " + message.getType());
                    
                    try {
                        switch (message.getType()) {
                            case "USER_DATA":
                                System.out.println("[Calender Listener] 新しいUserDataを受信。UIを更新します。");
                                UserData newUserData = gson.fromJson(message.getData(), UserData.class);
                                if (newUserData != null) {
                                    
                                    // 1. 更新前の選択グループIDを記憶
                                    String selectedGroupIdBeforeUpdate = (currentSelectedGroup != null) ? currentSelectedGroup.getId() : null;
                                    System.out.println("  -> UI更新前の選択グループID: " + selectedGroupIdBeforeUpdate);
                                    
                                    // 2. 内部データを更新
                                    this.currentUserData = newUserData;
                                    updateLocalDataFromUserData(); // myGroups などを更新
                                    
                                    // 3. 記憶したIDを元に、新しいmyGroupsリストからcurrentSelectedGroupを再設定
                                    if (selectedGroupIdBeforeUpdate != null) {
                                        this.currentSelectedGroup = findGroupByIdFromLocalList(selectedGroupIdBeforeUpdate);
                                    } else {
                                        this.currentSelectedGroup = null;
                                    }
                                    System.out.println("  -> UI更新後の選択グループ: " + (this.currentSelectedGroup != null ? this.currentSelectedGroup.getName() : "なし(マイページ)"));

                                    // 4. UIコンポーネントを再描画・再構築
                                    String cardIdToShow = (this.currentSelectedGroup != null) ? this.currentSelectedGroup.getId() : MY_PAGE_ID;

                                    updateSidebar();       
                                    updateCenterPanels(cardIdToShow);
                                    updateCalendarView();  
                                    
                                    // もしチャット画面を表示していたら、そのチャット履歴も更新
                                    if (this.currentSelectedGroup != null) {
                                        loadChatHistoryForGroup(this.currentSelectedGroup);
                                    }
                                }
                                break;
                                
                            case "CHAT_MESSAGE":
                                System.out.println("[Calender Listener] 新しいチャットメッセージを受信。");
                                ChatMessage newChatMessage = gson.fromJson(message.getData(), ChatMessage.class);
                                if (newChatMessage != null) {
                                    if(this.currentUserData != null && this.currentUserData.getChats() != null) {
                                        this.currentUserData.getChats().add(newChatMessage);
                                    }
                                    appendChatMessageToUI(newChatMessage, newChatMessage.getGroupId());
                                }
                                break;
                            
                            case "ERROR":
                                ErrorResponse errRes = gson.fromJson(message.getData(), ErrorResponse.class);
                                JOptionPane.showMessageDialog(frame, "サーバーからのエラー: " + errRes.getMessage(), "サーバーエラー", JOptionPane.ERROR_MESSAGE);
                                break;

                            case "SERVER_SHUTDOWN":
                                JOptionPane.showMessageDialog(frame, "サーバーがシャットダウンしました。アプリケーションを終了します。", "サーバー停止", JOptionPane.WARNING_MESSAGE);
                                if (connector != null) connector.disconnect();
                                System.exit(0);
                                break;
                            
                            default:
                                // "LOGIN_SUCCESS" など、Calender画面では処理不要なメッセージ
                                System.out.println("[Calender Listener] Calender画面では未処理のメッセージタイプ: " + message.getType());
                                break;
                        }
                    } catch (JsonSyntaxException e) {
                        System.err.println("[Calender Listener] 受信メッセージのJSONパースエラー: " + e.getMessage());
                        JOptionPane.showMessageDialog(frame, "サーバーから不正な形式のデータを受信しました。", "受信エラー", JOptionPane.ERROR_MESSAGE);
                    } catch (Exception e) {
                        System.err.println("[Calender Listener] メッセージ処理中に予期せぬエラー: " + e.getMessage());
                        e.printStackTrace();
                        JOptionPane.showMessageDialog(frame, "メッセージ処理中に予期せぬエラーが発生しました。", "エラー", JOptionPane.ERROR_MESSAGE);
                    }
                });
            }

            @Override
            public void onError(String errorMessage) {
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(frame, errorMessage, "通信エラー", JOptionPane.ERROR_MESSAGE);
                });
            }

            @Override
            public void onDisconnected() {
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(frame, "サーバーから切断されました。アプリケーションを再起動してください。", "接続エラー", JOptionPane.ERROR_MESSAGE);
                    frame.setTitle(frame.getTitle() + " (サーバー切断)");
                    // 全てのUIを操作不能にするなどの処理も検討
                });
            }

        };
        connector.setMessageListener(tempListener);

        // --- サーバーにリクエストを送信 ---
        connector.sendMessage(new ServerMessage("GET_ALL_USERS", null));
        
        // --- ローディングダイアログを表示 ---
        // これにより、応答があるまでユーザー操作はブロックされる
        loadingDialog.setVisible(true);
    }
    /**
 * ユーザーリストを受け取り、実際のグループ作成ダイアログを開いて処理する。
 * @param allUsers サーバーから取得した全ユーザーのリスト（パスワードは含まない）
 */
    private void openCreateGroupDialogWithUserList(List<share.User> allUsers) {
        // ダイアログのコンポーネントを作成
        JDialog dialog = new JDialog(frame, "新規グループ作成", true);
        dialog.setSize(400, 450);
        dialog.setLayout(new BorderLayout(10, 10));

        // --- 上部パネル（グループ名入力） ---
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        topPanel.add(new JLabel("グループ名:"), BorderLayout.WEST);
        JTextField groupNameField = new JTextField();
        topPanel.add(groupNameField, BorderLayout.CENTER);

        // --- 中央パネル（メンバー選択） ---
        // 自分以外のユーザーリストを作成
        List<share.User> allOtherUsers = allUsers.stream()
                .filter(u -> u != null && u.getUsername() != null && !u.getUsername().equalsIgnoreCase(myUser.getUsername()))
                .collect(Collectors.toList());

        JPanel membersPanel = new JPanel();
        membersPanel.setLayout(new BoxLayout(membersPanel, BoxLayout.Y_AXIS));
        Map<String, JCheckBox> checkBoxMap = new HashMap<>(); // username -> JCheckBox
        
        if (allOtherUsers.isEmpty()) {
            membersPanel.add(new JLabel("招待可能な他のユーザーがいません。"));
        } else {
            for (share.User user : allOtherUsers) {
                // Userオブジェクトにemailがないので、表示はユーザー名のみ
                JCheckBox checkBox = new JCheckBox(user.getUsername());
                checkBoxMap.put(user.getUsername(), checkBox);
                membersPanel.add(checkBox);
            }
        }
        
        JScrollPane scrollPane = new JScrollPane(membersPanel);
        scrollPane.setBorder(BorderFactory.createTitledBorder("初期メンバーを選択"));
        scrollPane.setPreferredSize(new Dimension(380, 250));

        // --- 下部パネル（ボタン） ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton createButton = new JButton("作成");
        JButton cancelButton = new JButton("キャンセル");
        buttonPanel.add(createButton);
        buttonPanel.add(cancelButton);

        cancelButton.addActionListener(e -> dialog.dispose());

        createButton.addActionListener(e -> {
            String groupName = groupNameField.getText().trim();
            if (groupName.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "グループ名を入力してください。", "エラー", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 選択されたメンバーのユーザー名リストを作成
            List<String> selectedMembers = checkBoxMap.entrySet().stream()
                    .filter(entry -> entry.getValue().isSelected())
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toList());
            
            // 作成者自身もメンバーリストに含める (サーバー側でも処理するが、リクエストに含めるのが明確)
            selectedMembers.add(myUser.getUsername());

            System.out.println("[Calender] グループ作成リクエスト送信: " + groupName + ", Members: " + selectedMembers);

            // サーバーにリクエストを送信
            // share.CreateGroupRequest を使用
            share.CreateGroupRequest createReq = new share.CreateGroupRequest(groupName, selectedMembers);
            share.ServerMessage serverMsg = new share.ServerMessage("CREATE_GROUP", gson.toJsonTree(createReq));
            
            if (connector != null && connector.isConnected()) {
                connector.sendMessage(serverMsg);
                dialog.dispose(); // リクエストを送信したらダイアログを閉じる
                // UIの更新は、サーバーからのUSER_DATAプッシュ通知を待って onMessageReceived で行われる
            } else {
                JOptionPane.showMessageDialog(dialog, "サーバーに接続されていません。", "エラー", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(frame);
        dialog.setVisible(true);
    }

    

    private JPanel createChatPanel(share.Group group) {
        JPanel chatPanel = new JPanel(new BorderLayout(0, 10));
        chatPanel.setBorder(new EmptyBorder(10,10,10,10));
        chatPanel.setName("CHAT_PANEL_" + group.getId());
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel groupTitleLabel = new JLabel(group.getName(), SwingConstants.CENTER);
        groupTitleLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        JButton membersButton = new JButton("メンバー (" + (group.getMembers() != null ? group.getMembers().size() : 0) + ")");
        membersButton.addActionListener(e -> showGroupMembersDialog(group));
        headerPanel.add(groupTitleLabel, BorderLayout.CENTER);
        headerPanel.add(membersButton, BorderLayout.EAST);
        chatPanel.add(headerPanel, BorderLayout.NORTH);
        JTextArea messageDisplayArea = new JTextArea();
        messageDisplayArea.setEditable(false);
        messageDisplayArea.setLineWrap(true);
        messageDisplayArea.setWrapStyleWord(true); // ここを修正
        messageDisplayArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        messageDisplayArea.setName("ChatDisplayArea_" + group.getId());
        JScrollPane scrollPane = new JScrollPane(messageDisplayArea);
        chatPanel.add(scrollPane, BorderLayout.CENTER);
        JPanel inputSouthPanel = new JPanel(new BorderLayout(5,5));
        JTextField messageInputField = new JTextField();
        JButton sendMessageButton = new JButton("送信");
        sendMessageButton.addActionListener(e -> {
            String messageText = messageInputField.getText().trim();
            if (!messageText.isEmpty() && connector != null && myUser != null && currentSelectedGroup != null) {
                System.out.println("[Chat] 送信試行: GroupID=" + currentSelectedGroup.getId() + ", User=" + myUser.getUsername() + ", Msg=" + messageText);
                // TODO: connector.sendMessage(new share.ServerMessage("SEND_CHAT", ...));
                messageInputField.setText("");
            }
        });
        messageInputField.addActionListener(sendMessageButton.getActionListeners()[0]);
        inputSouthPanel.add(messageInputField, BorderLayout.CENTER);
        inputSouthPanel.add(sendMessageButton, BorderLayout.EAST);
        chatPanel.add(inputSouthPanel, BorderLayout.SOUTH);
        return chatPanel;
    }
    
    private void loadChatHistoryForGroup(share.Group group) {
        JTextArea displayArea = findChatDisplayAreaForGroup(group.getId());
        if (displayArea == null) {
            System.err.println("[Calender] チャット表示エリアが見つかりません for group: " + (group != null ? group.getName() : "null group"));
            return;
        }
        displayArea.setText("");
        if (currentUserData != null && currentUserData.getChats() != null && group != null) { // groupのnullチェック追加
            currentUserData.getChats().stream()
                .filter(cm -> group.getId().equals(cm.getGroupId()))
                .sorted(Comparator.comparing(share.ChatMessage::getTimestamp))
                .forEach(chatMessage -> appendChatMessageToUI(chatMessage, displayArea));
        }
        SwingUtilities.invokeLater(() -> displayArea.setCaretPosition(displayArea.getDocument().getLength()));
    }
    
    public void appendChatMessageToUI(share.ChatMessage message, String groupId) {
        if (currentSelectedGroup != null && currentSelectedGroup.getId().equals(groupId) && message != null) { // messageのnullチェック追加
            JTextArea displayArea = findChatDisplayAreaForGroup(groupId);
            if (displayArea != null) {
                appendChatMessageToUI(message, displayArea);
                SwingUtilities.invokeLater(() -> displayArea.setCaretPosition(displayArea.getDocument().getLength()));
            }
        }
    }

    private void appendChatMessageToUI(share.ChatMessage message, JTextArea displayArea) {
        String senderName = message.getSender() != null ? message.getSender() : "不明な送信者";
        String prefix = (myUser != null && senderName.equals(myUser.getUsername())) ? "[自分] " : "[" + senderName + "] ";
        String msgText = message.getMessage() != null ? message.getMessage() : "";
        LocalDateTime timestamp = message.getTimestamp();
        displayArea.append(prefix + msgText + "  (" + (timestamp != null ? formatDateTime(timestamp) : "時刻不明") + ")\n");
    }
    
    private String formatDateTime(LocalDateTime ldt){
        if(ldt == null) return "";
        return ldt.format(chatTimestampFormatter);
    }

    private JTextArea findChatDisplayAreaForGroup(String groupId) {
        if (groupId == null) return null; // groupIdのnullチェック
        String panelName = "CHAT_PANEL_" + groupId;
        for (Component comp : centerCardPanel.getComponents()) {
            if (panelName.equals(comp.getName()) && comp instanceof JPanel) {
                JPanel chatPanel = (JPanel) comp;
                for(Component chatPanelComp : chatPanel.getComponents()){
                    if(chatPanelComp instanceof JScrollPane){
                        JScrollPane scrollPane = (JScrollPane) chatPanelComp;
                        Component view = scrollPane.getViewport().getView();
                        if(view instanceof JTextArea && ("ChatDisplayArea_" + groupId).equals(view.getName())){
                            return (JTextArea) view;
                        }
                    }
                }
            }
        }
        return null;
    }

    private void showGroupMembersDialog(share.Group group) {
        JOptionPane.showMessageDialog(frame, "グループメンバー管理 (未実装)\nグループ: " + (group != null ? group.getName() : "不明"), "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createCalendarDisplayPanel() {
        JPanel calendarContainer = new JPanel(new BorderLayout(0, 10));
        calendarContainer.setBorder(new EmptyBorder(10, 10, 10, 10));
        calendarContainer.add(createCalendarHeaderPanel(), BorderLayout.NORTH);
        calendarContainer.add(createDateGridPanel(), BorderLayout.CENTER);
        return calendarContainer;
    }

    private JPanel createCalendarHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JButton prevButton = new JButton("< 前月");
        prevButton.addActionListener(e -> { currentDateForCalendar = currentDateForCalendar.minusMonths(1); updateHeaderDateDisplay(); updateCalendarView(); });
        JButton nextButton = new JButton("次月 >");
        nextButton.addActionListener(e -> { currentDateForCalendar = currentDateForCalendar.plusMonths(1); updateHeaderDateDisplay(); updateCalendarView(); });
        monthDisplayPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        panel.add(prevButton, BorderLayout.WEST); panel.add(monthDisplayPanel, BorderLayout.CENTER); panel.add(nextButton, BorderLayout.EAST);
        return panel;
    }

    private void updateHeaderDateDisplay() {
        if (monthDisplayPanel == null) return; // 初期化前なら何もしない
        monthDisplayPanel.removeAll();
        JLabel label = new JLabel(String.format("%d年 %d月", currentDateForCalendar.getYear(), currentDateForCalendar.getMonthValue()));
        label.setFont(new Font("SansSerif", Font.BOLD, 18));
        monthDisplayPanel.add(label);
        monthDisplayPanel.revalidate(); monthDisplayPanel.repaint();
    }

    private Component createDateGridPanel() {
        JPanel gridOuterContainer = new JPanel(new BorderLayout());
        JPanel dayOfWeekPanel = new JPanel(new GridLayout(1, CALENDAR_COLS, 2, 2));
        String[] days = {"日", "月", "火", "水", "木", "金", "土"};
        for (String day : days) {
            JLabel dayLabel = new JLabel(day, JLabel.CENTER); dayLabel.setOpaque(true); dayLabel.setBackground(new Color(210,210,210)); dayLabel.setBorder(BorderFactory.createEtchedBorder());
            if (day.equals("日")) dayLabel.setForeground(Color.RED); if (day.equals("土")) dayLabel.setForeground(Color.BLUE);
            dayOfWeekPanel.add(dayLabel);
        }
        JPanel dateGridPanel = new JPanel(new GridLayout(CALENDAR_ROWS, CALENDAR_COLS, 2, 2));
        dateGridPanel.setBorder(BorderFactory.createEtchedBorder()); datePanels.clear();
        for (int i = 0; i < CALENDAR_ROWS * CALENDAR_COLS; i++) {
            JPanel dateCell = new JPanel(new BorderLayout(2,2)); dateCell.setBorder(BorderFactory.createEtchedBorder()); dateCell.setBackground(Color.WHITE);
            dateGridPanel.add(dateCell); datePanels.add(dateCell);
        }
        gridOuterContainer.add(dayOfWeekPanel, BorderLayout.NORTH); gridOuterContainer.add(dateGridPanel, BorderLayout.CENTER);
        return gridOuterContainer;
    }
    
    private JPanel createFooterActionPanel() {
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        return footerPanel;
    }

    private void updateCalendarView() {
        if (myUser == null || currentUserData == null) {
            System.err.println("[Calender] updateCalendarView skipped: myUser or currentUserData is null.");
            return;
        }
        String loggedInUsername = myUser.getUsername(); // ログインユーザー名をキャッシュ

        System.out.println("[Calender] カレンダー表示更新開始: " + currentDateForCalendar.toString() +
                           ", LoginUser: " + loggedInUsername +
                           ", SelectedGroup: " + (currentSelectedGroup != null ? currentSelectedGroup.getName() : "MyPage"));

        displayedSchedules.clear();
        if (currentUserData.getSchedules() != null) {
            for (share.Schedule schedule : currentUserData.getSchedules()) {
                if (schedule == null || schedule.getStartTime() == null || schedule.getCreatedBy() == null) {
                    System.out.println("  [Skipping] Incomplete schedule data: " + schedule);
                    continue;
                }

                LocalDate scheduleDate = schedule.getStartTime().toLocalDate();
                boolean shouldDisplayThisSchedule = false;
                String scheduleOwnerUsername = schedule.getCreatedBy();
                boolean isMyOwnSchedule = loggedInUsername.equalsIgnoreCase(scheduleOwnerUsername);
                boolean isGroupSchedule = schedule.getGroupId() != null && !schedule.getGroupId().isEmpty();

                // --- デバッグログ ---
                System.out.println("  [Filtering] Schedule: '" + schedule.getTitle() + "' by " + scheduleOwnerUsername +
                                   ", isMyOwn: " + isMyOwnSchedule +
                                   ", isGroupSched: " + isGroupSchedule +
                                   (isGroupSchedule ? ", schedGroupId: " + schedule.getGroupId() : "") +
                                   ", isPrivate: " + schedule.isPrivate());


                if (currentSelectedGroup == null) { // マイページ表示時
                    if (isMyOwnSchedule) {
                        shouldDisplayThisSchedule = true;
                        System.out.println("    マイページ: 自分の予定 -> 表示");
                    } else if (isGroupSchedule) {
                        // 自分が所属するグループの予定か確認
                        final String currentScheduleGroupId = schedule.getGroupId(); // finalにしてラムダ式で使えるように
                        if (myGroups.stream().anyMatch(g -> g != null && g.getId().equals(currentScheduleGroupId))) {
                            shouldDisplayThisSchedule = true;
                            System.out.println("    マイページ: 所属グループの予定 -> 表示 (Group: " + currentScheduleGroupId + ")");
                        } else {
                            System.out.println("    マイページ: 所属外グループの予定 -> 非表示 (Group: " + currentScheduleGroupId + ")");
                        }
                    } else {
                        System.out.println("    マイページ: 他人の個人予定 -> 非表示");
                    }
                } else { 
                    if (isGroupSchedule) {
                        // 【条件1】グループ予定の場合
                        // まさに今表示しているグループの共有予定か？
                        if (schedule.getGroupId().equals(currentSelectedGroup.getId())) {
                            shouldDisplayThisSchedule = true;
                            System.out.println("    グループ(" + currentSelectedGroup.getName() + "): このグループの共有予定 -> 表示");
                        } else {
                            // 表示しているグループとは別のグループの共有予定 -> 表示しない
                            System.out.println("    グループ(" + currentSelectedGroup.getName() + "): 別のグループの共有予定 -> 非表示");
                        }
                    } else {
                        // 【条件2】個人予定の場合
                        // このグループのメンバーの個人予定か？ (自分自身も含む)
                        if (currentSelectedGroup.getMembers().stream().anyMatch(memberUsername -> memberUsername.equalsIgnoreCase(scheduleOwnerUsername))) {
                            shouldDisplayThisSchedule = true;
                            System.out.println("    グループ(" + currentSelectedGroup.getName() + "): メンバー「" + scheduleOwnerUsername + "」の個人予定 -> 表示");
                        } else {
                            System.out.println("    グループ(" + currentSelectedGroup.getName() + "): 非メンバー「" + scheduleOwnerUsername + "」の個人予定 -> 非表示");
                        }
                    }
                }

                if (shouldDisplayThisSchedule) {
                    System.out.println("      ===> ADDING TO DISPLAY: '" + schedule.getTitle() + "'");
                    displayedSchedules.computeIfAbsent(scheduleDate, k -> new ArrayList<>()).add(schedule);
                }
            }
        }
        System.out.println("[Calender] 表示対象スケジュール数 (フィルタ後): " + displayedSchedules.values().stream().mapToInt(List::size).sum());


        YearMonth yearMonth = YearMonth.from(currentDateForCalendar);
        int daysInMonth = yearMonth.lengthOfMonth();
        LocalDate firstOfMonth = currentDateForCalendar.withDayOfMonth(1);
        int startDayOfWeek = firstOfMonth.getDayOfWeek().getValue();
        if (startDayOfWeek == 7) startDayOfWeek = 0;

        for (int i = 0; i < datePanels.size(); i++) {
            JPanel dateCell = datePanels.get(i);
            dateCell.removeAll();
            dateCell.setBackground(Color.WHITE);
            dateCell.setName(null);
            int dayOfMonth = i - startDayOfWeek + 1;
            if (dayOfMonth > 0 && dayOfMonth <= daysInMonth) {
                LocalDate cellDate = currentDateForCalendar.withDayOfMonth(dayOfMonth);
                buildDateCellUIWithSchedules(dateCell, cellDate);
                if (cellDate.equals(LocalDate.now())) {
                    dateCell.setBackground(new Color(225, 235, 255));
                }
            } else {
                dateCell.setBackground(new Color(245, 245, 245));
            }
            dateCell.revalidate();
            dateCell.repaint();
        }
        System.out.println("[Calender] カレンダー表示更新完了。");
    }

    private void buildDateCellUIWithSchedules(JPanel dateCell, LocalDate cellDate) {
        dateCell.setName(cellDate.toString());
        JLabel dateLabel = new JLabel(String.valueOf(cellDate.getDayOfMonth()), SwingConstants.RIGHT);
        dateLabel.setBorder(new EmptyBorder(2, 0, 2, 4));
        dateCell.add(dateLabel, BorderLayout.NORTH);

        JPanel appointmentContainer = new JPanel();
        appointmentContainer.setLayout(new BoxLayout(appointmentContainer, BoxLayout.Y_AXIS));
        appointmentContainer.setOpaque(false);

        List<share.Schedule> daySchedules = displayedSchedules.getOrDefault(cellDate, new ArrayList<>());
        daySchedules.sort(Comparator.comparing(share.Schedule::isAllDay, Comparator.reverseOrder())
                                    .thenComparing(s -> s.isAllDay() || s.getStartTime() == null ? null : s.getStartTime(), Comparator.nullsLast(Comparator.naturalOrder()))
                                    .thenComparing(share.Schedule::getTitle, Comparator.nullsLast(String::compareToIgnoreCase)));


        for (share.Schedule schedule_loopVar : daySchedules) {
            if (schedule_loopVar == null || schedule_loopVar.getCreatedBy() == null || myUser == null || myUser.getUsername() == null) continue; // 安全のためのnullチェック

            String displayTitle = schedule_loopVar.getTitle() != null ? schedule_loopVar.getTitle() : "(タイトルなし)";
            if (!schedule_loopVar.isAllDay() && schedule_loopVar.getStartTime() != null) {
                 displayTitle = schedule_loopVar.getStartTime().format(timeFormatter) + " " + displayTitle;
            }

            String scheduleCreatedBy_loopVar = schedule_loopVar.getCreatedBy();
            boolean isMyOwnSchedule_loopVar = myUser.getUsername().equalsIgnoreCase(scheduleCreatedBy_loopVar);
            boolean isGroupSchedule_loopVar = schedule_loopVar.getGroupId() != null && !schedule_loopVar.getGroupId().isEmpty();
            boolean isPrivateAndNotMineAndGroupView_loopVar =
                !isMyOwnSchedule_loopVar && !isGroupSchedule_loopVar && schedule_loopVar.isPrivate() && currentSelectedGroup != null;

            if (isPrivateAndNotMineAndGroupView_loopVar) {
                displayTitle = "（非公開の予定）";
            }

            JButton appButton = new JButton("<html><body style='text-align:left; width:80px;'>" + escapeHtml(displayTitle) + "</body></html>");
            appButton.setHorizontalAlignment(SwingConstants.LEFT);
            appButton.setMargin(new Insets(1,3,1,3));
            appButton.setFont(new Font("SansSerif", Font.PLAIN, 10));
            appButton.setOpaque(true);

            if (isGroupSchedule_loopVar) { // 最初にグループ予定かどうかを判定
                appButton.setBackground(new Color(144, 238, 144)); // グループ共有予定: 緑
            } else if (isMyOwnSchedule_loopVar) { // 次に自分の個人予定かどうかを判定
                appButton.setBackground(new Color(135, 206, 250)); // 自分の個人予定: 青
            } else { // 残りは他人の個人予定（公開）
                appButton.setBackground(new Color(220, 220, 220)); // 他人の個人予定: 灰
            }
            
            boolean isEditable_loopVar;
            if(isMyOwnSchedule_loopVar){
                isEditable_loopVar = true;
            } else if (isGroupSchedule_loopVar) {
                // 自分がそのグループのメンバーである場合に編集可能
                final String groupIdToCheck = schedule_loopVar.getGroupId(); // effectively final
                isEditable_loopVar = myGroups.stream().anyMatch(g -> g.getId().equals(groupIdToCheck));
            } else {
                isEditable_loopVar = false;
            }

            if (isPrivateAndNotMineAndGroupView_loopVar) {
                appButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                appButton.setEnabled(false); 
            } else {
                final share.Schedule currentScheduleForListener = schedule_loopVar;
                final Object currentOwnerContextForListener;
                if (isMyOwnSchedule_loopVar) {
                    currentOwnerContextForListener = myUser;
                } else if (isGroupSchedule_loopVar) {
                    currentOwnerContextForListener = findGroupByIdFromLocalList(schedule_loopVar.getGroupId());
                } else { 
                    currentOwnerContextForListener = schedule_loopVar.getCreatedBy();
                }
                final boolean finalIsEditable = isEditable_loopVar;
                final LocalDate finalCellDate = cellDate;

                appButton.addActionListener(e -> showAppointmentDialog(
                    finalCellDate,
                    currentScheduleForListener,
                    currentOwnerContextForListener,
                    finalIsEditable
                ));
                appButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            appointmentContainer.add(appButton);
            appointmentContainer.add(Box.createRigidArea(new Dimension(0,1)));
        }
        JScrollPane appointmentScrollPane = new JScrollPane(appointmentContainer,
                                                            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                                            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        appointmentScrollPane.setBorder(null);
        appointmentScrollPane.setOpaque(false);
        appointmentScrollPane.getViewport().setOpaque(false);
        dateCell.add(appointmentScrollPane, BorderLayout.CENTER);

        JPanel addBtnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0,0));
        addBtnPanel.setOpaque(false);
        JButton addButton = new JButton("+");
        addButton.setMargin(new Insets(0,2,0,2));
        addButton.setFont(new Font("SansSerif", Font.PLAIN, 10));
        addButton.setFocusable(false);
        final LocalDate finalCellDateForAdd = cellDate;
        addButton.addActionListener(e -> {
            Object ownerCtx = (currentSelectedGroup != null) ? (Object)currentSelectedGroup : (Object)myUser;
            showAppointmentDialog(finalCellDateForAdd, null, ownerCtx, true);
        });
        addBtnPanel.add(addButton);
        dateCell.add(addBtnPanel, BorderLayout.SOUTH);
    }
    
    // HTMLエスケープユーティリティ
    // Calender.java 内の escapeHtml メソッド (修正版)
    private String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&").replace("<", "<").replace(">", ">").replace("\"", "&quot;").replace("'", "'"); // ★★★ ここを修正 ★★★
    }

    private share.Group findGroupByIdFromLocalList(String id) {
        if (id == null) return null;
        return myGroups.stream().filter(g -> g!=null && id.equals(g.getId())).findFirst().orElse(null);
    }

    /*
    private void handleAddScheduleFromFooter(JTextField monthField, JTextField dayField, JTextField titleField) {
        JOptionPane.showMessageDialog(frame, "フッターからの簡易予定追加 (未実装)", "TODO", JOptionPane.INFORMATION_MESSAGE);
    }
        */

    private void showAppointmentDialog(LocalDate dateForNew, share.Schedule scheduleToEdit, Object ownerContext, boolean isEditable) {
        boolean isNew = (scheduleToEdit == null);
        share.Schedule targetSchedule;
        boolean isPersonalAppointmentForDialog;

        if (isNew) {
            targetSchedule = new share.Schedule();
            if (myUser != null) targetSchedule.setCreatedBy(myUser.getUsername()); else return;
            targetSchedule.setAllDay(true);
            targetSchedule.setPrivate(false);
            targetSchedule.setStartTime(dateForNew.atStartOfDay());
            targetSchedule.setEndTime(dateForNew.atTime(23,59,59));
            if (ownerContext instanceof share.Group) {
                targetSchedule.setGroupId(((share.Group) ownerContext).getId());
                isPersonalAppointmentForDialog = false;
            } else {
                isPersonalAppointmentForDialog = true;
            }
        } else {
            targetSchedule = scheduleToEdit;
            isPersonalAppointmentForDialog = (targetSchedule.getGroupId() == null || targetSchedule.getGroupId().isEmpty());
        }
        
        AppointmentDialog dialog = new AppointmentDialog(frame, targetSchedule, isNew, isEditable, isPersonalAppointmentForDialog);
        dialog.setVisible(true);
        int result = dialog.getResult();

        if (result == AppointmentDialog.OPTION_SAVE) {
            share.Schedule savedSchedule = dialog.getSchedule();
            
            // ★★★ ここからサーバー連携 ★★★
            if (isNew) {
                System.out.println("[Calender] 新規予定をサーバーに送信: " + savedSchedule.getTitle());
                ServerMessage addRequest = new ServerMessage("ADD_SCHEDULE", gson.toJsonTree(savedSchedule));
                connector.sendMessage(addRequest);
            } else {
                System.out.println("[Calender] 更新予定をサーバーに送信: " + savedSchedule.getTitle());
                ServerMessage updateRequest = new ServerMessage("UPDATE_SCHEDULE", gson.toJsonTree(savedSchedule));
                connector.sendMessage(updateRequest);
            }
            // サーバーからの応答(UserData)を待ってUIが自動更新される
            
        } else if (result == AppointmentDialog.OPTION_DELETE && !isNew) {
            System.out.println("[Calender] 予定削除リクエストをサーバーに送信: " + targetSchedule.getTitle());
            
            JsonObject idObject = new JsonObject();
            idObject.addProperty("id", targetSchedule.getId());

            ServerMessage deleteRequest = new ServerMessage("DELETE_SCHEDULE", idObject);
            connector.sendMessage(deleteRequest);
            // サーバーからの応答(UserData)を待ってUIが自動更新される
        }
    }

    // ★★★ ここからが今回の修正の核心 ★★★
    // --- Connector.MessageListener の実装メソッド群 ---

    @Override
    public void onMessageReceived(ClientMessage message) {
        SwingUtilities.invokeLater(() -> { // GUI更新は必ずEDT(Event Dispatch Thread)で行う
            if (message == null || message.getType() == null) {
                System.err.println("[Calender Listener] Invalid message received.");
                return;
            }
            
            System.out.println("[Calender Listener] メッセージ受信: " + message.getType());
            
            try {
                switch (message.getType()) {
                    case "USER_DATA":
                        System.out.println("[Calender Listener] 新しいUserDataを受信。UIを更新します。");
                        UserData newUserData = gson.fromJson(message.getData(), UserData.class);
                        if (newUserData != null) {
                            // ★★★ 1. 更新前の表示状態を記憶 ★★★
                            String currentVisibleCardId = (currentSelectedGroup != null) ? currentSelectedGroup.getId() : MY_PAGE_ID;
                            System.out.println("  -> UI更新前の表示カードID: " + currentVisibleCardId);
                            
                            // 2. 内部データを更新
                            this.currentUserData = newUserData;
                            updateLocalDataFromUserData(); // myGroups などを更新
                            
                            // 3. UIコンポーネントを再描画・再構築
                            updateSidebar();       
                            updateCenterPanels(currentVisibleCardId);  // ★★★ 記憶したIDを渡す ★★★
                            updateCalendarView();  
                            
                            // もしチャット画面を開いていたら、そのチャット履歴も更新
                            if (currentSelectedGroup != null) {
                                loadChatHistoryForGroup(currentSelectedGroup);
                            }
                        }
                        break;
                        
                    case "CHAT_MESSAGE":
                        System.out.println("[Calender Listener] 新しいチャットメッセージを受信。");
                        ChatMessage newChatMessage = gson.fromJson(message.getData(), ChatMessage.class);
                        if (newChatMessage != null) {
                            // currentUserDataのチャットリストにも追加
                            if(this.currentUserData != null && this.currentUserData.getChats() != null) {
                                this.currentUserData.getChats().add(newChatMessage);
                            }
                            // 表示中のチャット画面にメッセージを追加
                            appendChatMessageToUI(newChatMessage, newChatMessage.getGroupId());
                        }
                        break;
                    
                    case "ERROR":
                         ErrorResponse errRes = gson.fromJson(message.getData(), ErrorResponse.class);
                         JOptionPane.showMessageDialog(frame, "サーバーからのエラー: " + errRes.getMessage(), "サーバーエラー", JOptionPane.ERROR_MESSAGE);
                         break;
                    
                    default:
                        System.out.println("[Calender Listener] Calender画面では未処理のメッセージタイプ: " + message.getType());
                        break;
                }
            } catch (JsonSyntaxException e) {
                System.err.println("[Calender Listener] 受信メッセージのJSONパースエラー: " + e.getMessage());
                JOptionPane.showMessageDialog(frame, "サーバーから不正な形式のデータを受信しました。", "受信エラー", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                 System.err.println("[Calender Listener] メッセージ処理中に予期せぬエラー: " + e.getMessage());
                 e.printStackTrace();
                 JOptionPane.showMessageDialog(frame, "メッセージ処理中に予期せぬエラーが発生しました。", "エラー", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    @Override
    public void onError(String errorMessage) {
        SwingUtilities.invokeLater(() -> {
            JOptionPane.showMessageDialog(frame, errorMessage, "通信エラー", JOptionPane.ERROR_MESSAGE);
        });
    }

    @Override
    public void onDisconnected() {
        SwingUtilities.invokeLater(() -> {
            // TODO: より親切なUI（例：再接続ボタンを表示するパネルに切り替えるなど）
            JOptionPane.showMessageDialog(frame, "サーバーから切断されました。アプリケーションを再起動してください。", "接続エラー", JOptionPane.ERROR_MESSAGE);
            frame.setTitle(frame.getTitle() + " (サーバー切断)");
        });
    }

    static class AppointmentDialog extends JDialog {
        public static final int OPTION_SAVE = 1, OPTION_DELETE = 2, OPTION_CANCEL = 0;
        private int result = OPTION_CANCEL;
        private JTextField titleField;
        private JTextArea detailsArea;
        private JCheckBox privateCheckBox;
        private JCheckBox allDayCheckBox;
        private JSpinner startTimeSpinner;
        private JSpinner endTimeSpinner;
        private JLabel timeLabel;
        private share.Schedule scheduleDataToEdit;
        private boolean isDialogForPersonalSchedule;

        public AppointmentDialog(Frame ownerFrame, share.Schedule originalSchedule, boolean isNew, boolean isEditable, boolean isPersonalScheduleContext) {
            super(ownerFrame, true);
            this.isDialogForPersonalSchedule = isPersonalScheduleContext;
            
            this.scheduleDataToEdit = new share.Schedule(); // 必ず新しいインスタンスで初期化
            if (originalSchedule != null) { // nullチェック
                this.scheduleDataToEdit.setId(originalSchedule.getId());
                this.scheduleDataToEdit.setTitle(originalSchedule.getTitle());
                this.scheduleDataToEdit.setDescription(originalSchedule.getDescription());
                this.scheduleDataToEdit.setStartTime(originalSchedule.getStartTime() != null ? originalSchedule.getStartTime() : LocalDateTime.now().withNano(0)); // nullなら現在時刻
                this.scheduleDataToEdit.setEndTime(originalSchedule.getEndTime() != null ? originalSchedule.getEndTime() : LocalDateTime.now().plusHours(1).withNano(0)); // nullなら1時間後
                this.scheduleDataToEdit.setAllDay(originalSchedule.isAllDay());
                this.scheduleDataToEdit.setGroupId(originalSchedule.getGroupId());
                this.scheduleDataToEdit.setParticipants(originalSchedule.getParticipants() != null ? new ArrayList<>(originalSchedule.getParticipants()) : new ArrayList<>());
                this.scheduleDataToEdit.setCreatedBy(originalSchedule.getCreatedBy());
                this.scheduleDataToEdit.setPrivate(originalSchedule.isPrivate());
            } else if (isNew) { // originalScheduleがnullで新規作成の場合のデフォルト値
                 this.scheduleDataToEdit.setStartTime(LocalDateTime.now().withNano(0));
                 this.scheduleDataToEdit.setEndTime(LocalDateTime.now().plusHours(1).withNano(0));
            }


            String dialogTitle = isNew ? "予定の新規作成" : (isEditable ? "予定の編集/削除" : "予定の詳細");
            setTitle(dialogTitle);

            titleField = new JTextField(this.scheduleDataToEdit.getTitle(), 25);
            detailsArea = new JTextArea(this.scheduleDataToEdit.getDescription(), 5, 25);
            detailsArea.setLineWrap(true);
            detailsArea.setWrapStyleWord(true);

            privateCheckBox = new JCheckBox("非公開の予定にする");
            privateCheckBox.setSelected(this.scheduleDataToEdit.isPrivate());
            privateCheckBox.setEnabled(isEditable && this.isDialogForPersonalSchedule);
            privateCheckBox.setVisible(this.isDialogForPersonalSchedule); 

            allDayCheckBox = new JCheckBox("終日の予定");
            allDayCheckBox.setSelected(this.scheduleDataToEdit.isAllDay());

            Date initStartTime = Date.from(this.scheduleDataToEdit.getStartTime().atZone(ZoneId.systemDefault()).toInstant());
            Date initEndTime = Date.from(this.scheduleDataToEdit.getEndTime().atZone(ZoneId.systemDefault()).toInstant());

            SpinnerDateModel startModel = new SpinnerDateModel(initStartTime, null, null, Calendar.MINUTE);
            startTimeSpinner = new JSpinner(startModel);
            startTimeSpinner.setEditor(new JSpinner.DateEditor(startTimeSpinner, "HH:mm"));
            SpinnerDateModel endModel = new SpinnerDateModel(initEndTime, null, null, Calendar.MINUTE);
            endTimeSpinner = new JSpinner(endModel);
            endTimeSpinner.setEditor(new JSpinner.DateEditor(endTimeSpinner, "HH:mm"));
            timeLabel = new JLabel("時間:");

            allDayCheckBox.addActionListener(e -> updateDateTimeFieldsVisibility());
            updateDateTimeFieldsVisibility();

            JLabel ownerDisplayLabel = new JLabel();
            ownerDisplayLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            ownerDisplayLabel.setForeground(Color.GRAY);
            if (this.scheduleDataToEdit.getGroupId() != null && !this.scheduleDataToEdit.getGroupId().isEmpty()) {
                ownerDisplayLabel.setText("グループ予定 (ID: " + this.scheduleDataToEdit.getGroupId() + ")");
            } else if (this.scheduleDataToEdit.getCreatedBy() != null){
                ownerDisplayLabel.setText("個人予定 (作成者: " + this.scheduleDataToEdit.getCreatedBy() + ")");
            } else {
                ownerDisplayLabel.setText("（新規予定）");
            }


            JPanel buttonPanelContainer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            if (isEditable) {
                JButton saveButton = new JButton("保存");
                saveButton.addActionListener(e -> { result = OPTION_SAVE; dispose(); });
                buttonPanelContainer.add(saveButton);
                if (!isNew) {
                    JButton deleteButton = new JButton("削除");
                    deleteButton.addActionListener(e -> {
                        if (JOptionPane.showConfirmDialog(this, "この予定を削除しますか？", "確認", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                            result = OPTION_DELETE; dispose();
                        }
                    });
                    buttonPanelContainer.add(deleteButton);
                }
                JButton cancelButton = new JButton("キャンセル");
                cancelButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(cancelButton);
            } else {
                JButton closeButton = new JButton("閉じる");
                closeButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(closeButton);
                titleField.setEditable(false); detailsArea.setEditable(false);
                privateCheckBox.setEnabled(false); allDayCheckBox.setEnabled(false);
                startTimeSpinner.setEnabled(false); endTimeSpinner.setEnabled(false);
                titleField.setFocusable(false); detailsArea.setFocusable(false);
            }

            JPanel fieldsPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbcDialog = new GridBagConstraints();
            gbcDialog.insets = new Insets(4,4,4,4); gbcDialog.anchor = GridBagConstraints.WEST;
            gbcDialog.gridx = 0; gbcDialog.gridy = 0; fieldsPanel.add(new JLabel("タイトル:"), gbcDialog);
            gbcDialog.gridx = 1; gbcDialog.gridy = 0; gbcDialog.fill = GridBagConstraints.HORIZONTAL; gbcDialog.weightx = 1.0;
            fieldsPanel.add(titleField, gbcDialog);
            gbcDialog.gridx = 0; gbcDialog.gridy = 1; gbcDialog.fill = GridBagConstraints.NONE; gbcDialog.weightx = 0;
            fieldsPanel.add(new JLabel("詳細:"), gbcDialog);
            gbcDialog.gridx = 1; gbcDialog.gridy = 1; gbcDialog.fill = GridBagConstraints.BOTH; gbcDialog.weighty = 1.0;
            fieldsPanel.add(new JScrollPane(detailsArea), gbcDialog);
            gbcDialog.gridx = 0; gbcDialog.gridy = 2; gbcDialog.gridwidth=2; gbcDialog.fill = GridBagConstraints.NONE; gbcDialog.weighty = 0;
            fieldsPanel.add(allDayCheckBox, gbcDialog);
            JPanel timeInnerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            timeInnerPanel.add(startTimeSpinner); timeInnerPanel.add(Box.createHorizontalStrut(5));
            timeInnerPanel.add(new JLabel("～")); timeInnerPanel.add(Box.createHorizontalStrut(5));
            timeInnerPanel.add(endTimeSpinner);
            gbcDialog.gridx = 0; gbcDialog.gridy = 3; gbcDialog.gridwidth=1; fieldsPanel.add(timeLabel, gbcDialog);
            gbcDialog.gridx = 1; gbcDialog.gridy = 3; gbcDialog.fill = GridBagConstraints.HORIZONTAL; fieldsPanel.add(timeInnerPanel, gbcDialog);
            if (this.isDialogForPersonalSchedule) {
                 gbcDialog.gridx = 0; gbcDialog.gridy = 4; gbcDialog.gridwidth = 2; gbcDialog.fill = GridBagConstraints.NONE;
                 fieldsPanel.add(privateCheckBox, gbcDialog);
            }
            JPanel mainContentPanel = new JPanel(new BorderLayout(5,5));
            mainContentPanel.setBorder(new EmptyBorder(10,10,10,10));
            mainContentPanel.add(fieldsPanel, BorderLayout.CENTER);
            JPanel southPanel = new JPanel(new BorderLayout());
            southPanel.setBorder(new EmptyBorder(5,0,5,0));
            southPanel.add(ownerDisplayLabel, BorderLayout.WEST);
            southPanel.add(buttonPanelContainer, BorderLayout.EAST);
            getContentPane().add(mainContentPanel, BorderLayout.CENTER);
            getContentPane().add(southPanel, BorderLayout.SOUTH);
            pack();
            setMinimumSize(new Dimension(480, getPreferredSize().height + 20));
            setLocationRelativeTo(ownerFrame);
        }

        private void updateDateTimeFieldsVisibility() {
            boolean isAllDay = allDayCheckBox.isSelected();
            startTimeSpinner.setVisible(!isAllDay);
            endTimeSpinner.setVisible(!isAllDay);
            timeLabel.setVisible(!isAllDay);
        }

        public int getResult() { return result; }

        public share.Schedule getSchedule() {
            scheduleDataToEdit.setTitle(titleField.getText());
            scheduleDataToEdit.setDescription(detailsArea.getText());
            if(isDialogForPersonalSchedule) {
                scheduleDataToEdit.setPrivate(privateCheckBox.isSelected());
            } else {
                scheduleDataToEdit.setPrivate(false);
            }
            scheduleDataToEdit.setAllDay(allDayCheckBox.isSelected());
            
            LocalDate scheduleDate = scheduleDataToEdit.getStartTime() != null ? scheduleDataToEdit.getStartTime().toLocalDate() : LocalDate.now(); // nullなら今日の日付

            if (!scheduleDataToEdit.isAllDay()) {
                Date startTimeUtilDate = (Date) startTimeSpinner.getValue();
                Date endTimeUtilDate = (Date) endTimeSpinner.getValue();
                LocalTime localStartTime = LocalDateTime.ofInstant(startTimeUtilDate.toInstant(), ZoneId.systemDefault()).toLocalTime();
                LocalTime localEndTime = LocalDateTime.ofInstant(endTimeUtilDate.toInstant(), ZoneId.systemDefault()).toLocalTime();
                scheduleDataToEdit.setStartTime(LocalDateTime.of(scheduleDate, localStartTime));
                scheduleDataToEdit.setEndTime(LocalDateTime.of(scheduleDate, localEndTime));
            } else {
                 scheduleDataToEdit.setStartTime(scheduleDate.atStartOfDay());
                 scheduleDataToEdit.setEndTime(scheduleDate.atTime(23,59,59));
            }
            return scheduleDataToEdit;
        }
    }
}