package client.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId; // AppointmentDialog で使用
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import java.util.Comparator; // ChatMessageソートで使用
import java.util.Date;       // AppointmentDialogのJSpinnerで使用
import java.util.stream.Collectors;
import java.util.Calendar;

// shareパッケージのクラスをインポート
import share.User;
import share.Group;
import share.Schedule;
import share.ChatMessage;
import share.UserData;

import client.Connector;

public class Calender {
    private static final int CALENDAR_ROWS = 6;
    private static final int CALENDAR_COLS = 7;
    private static final String MY_PAGE_ID = "MY_PAGE";

    private JFrame frame;
    private final List<JPanel> datePanels = new ArrayList<>();
    private JPanel monthDisplayPanel;
    private JPanel centerCardPanel;
    private CardLayout centerCardLayout;
    private JPanel sidebarPanel;

    private share.User myUser;
    private Connector connector;
    private share.UserData currentUserData;

    private final Map<LocalDate, List<share.Schedule>> schedules = new HashMap<>();
    private final List<share.Group> currentGroups = new ArrayList<>();
    private share.Group currentSelectedGroup;

    private LocalDate currentDate;

    public Calender(share.User loggedInUser, Connector connector, share.UserData initialUserData) {
        this.myUser = loggedInUser;
        this.connector = connector;
        this.currentUserData = initialUserData;

        if (this.currentUserData != null) {
            if (this.currentUserData.getGroups() != null) {
                this.currentGroups.addAll(this.currentUserData.getGroups());
            }
            if (this.currentUserData.getSchedules() != null) {
                for (share.Schedule schedule : this.currentUserData.getSchedules()) {
                    if (schedule.getStartTime() != null) {
                        LocalDate date = schedule.getStartTime().toLocalDate();
                        this.schedules.computeIfAbsent(date, k -> new ArrayList<>()).add(schedule);
                    }
                }
            }
        }
    }

    public void createAndShowGUI() {
        currentDate = LocalDate.now();

        frame = new JFrame("Group-based Application - ログインユーザー: " + (myUser != null ? myUser.getUsername() : "不明"));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 700);

        JPanel mainPanel = createMainLayout();
        frame.add(mainPanel);

        updateHeader();
        updateCalendar();

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private JPanel createMainLayout() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        sidebarPanel = createSidebarPanel();
        centerCardLayout = new CardLayout();
        centerCardPanel = new JPanel(centerCardLayout);

        centerCardPanel.add(createMyPagePanel(), MY_PAGE_ID);
        for (share.Group group : currentGroups) {
            centerCardPanel.add(createChatPanel(group), group.getId());
        }

        JPanel calenderPanel = createCalendarView();

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        gbc.gridx = 0; gbc.weightx = 1.0; mainPanel.add(sidebarPanel, gbc);
        gbc.gridx = 1; gbc.weightx = 8.0; mainPanel.add(centerCardPanel, gbc);
        gbc.gridx = 2; gbc.weightx = 11.0; mainPanel.add(calenderPanel, gbc);

        centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
        currentSelectedGroup = null;
        return mainPanel;
    }

    private JPanel createSidebarPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Groups"));
        panel.setBackground(new Color(240, 240, 240));

        panel.add(createGroupIcon(MY_PAGE_ID, "マイページ", (myUser != null && myUser.getUsername() != null && !myUser.getUsername().isEmpty()) ? myUser.getUsername().charAt(0) : 'M'));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        for (share.Group group : currentGroups) {
            panel.add(createGroupIcon(group.getId(), group.getName(), (!group.getName().isEmpty() ? group.getName().charAt(0) : 'G')));
        }
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    private Component createGroupIcon(String id, String tooltip, char iconChar) {
        JLabel iconLabel = new JLabel(String.valueOf(iconChar), SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean isSelected = id.equals(MY_PAGE_ID) ? currentSelectedGroup == null : (currentSelectedGroup != null && id.equals(currentSelectedGroup.getId()));
                if (isSelected) g2.setColor(new Color(66, 133, 244));
                else g2.setColor(Color.LIGHT_GRAY);
                g2.fillOval(5, 5, getWidth() - 10, getHeight() - 10);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        Dimension iconSize = new Dimension(50, 50);
        iconLabel.setPreferredSize(iconSize);
        iconLabel.setMaximumSize(new Dimension(Short.MAX_VALUE, iconSize.height));
        iconLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        iconLabel.setForeground(Color.WHITE);
        iconLabel.setToolTipText(tooltip);
        iconLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        iconLabel.setBorder(new EmptyBorder(5, 0, 5, 0));

        iconLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (id.equals(MY_PAGE_ID)) {
                    currentSelectedGroup = null;
                    centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
                } else {
                    currentSelectedGroup = findGroupById(id);
                    if (currentSelectedGroup != null) {
                        centerCardLayout.show(centerCardPanel, id);
                        loadChatHistoryForGroup(currentSelectedGroup);
                    }
                }
                sidebarPanel.repaint();
                updateCalendar();
            }
        });
        return iconLabel;
    }

    private JPanel createMyPagePanel() {
        JPanel myPagePanel = new JPanel(new BorderLayout());
        myPagePanel.setBackground(Color.WHITE);
        myPagePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);

        JLabel nameLabel = new JLabel((myUser != null ? myUser.getUsername() : "ユーザー名不明"));
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        infoPanel.add(nameLabel);
        myPagePanel.add(infoPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);
        JButton createGroupButton = new JButton("新しいグループを作成");
        createGroupButton.addActionListener(e -> showCreateGroupDialog());
        buttonPanel.add(createGroupButton);
        myPagePanel.add(buttonPanel, BorderLayout.CENTER);

        // マイページに所属グループ一覧と脱退ボタンを追加 (ステップ4で詳細実装)
        // JPanel groupListPanel = new JPanel();
        // groupListPanel.setLayout(new BoxLayout(groupListPanel, BoxLayout.Y_AXIS));
        // ...
        // myPagePanel.add(new JScrollPane(groupListPanel), BorderLayout.SOUTH);


        return myPagePanel;
    }

    private void showCreateGroupDialog() {
        JOptionPane.showMessageDialog(frame, "グループ作成機能 (サーバー連携 未実装)", "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createChatPanel(share.Group group) {
        JPanel chatPanel = new JPanel(new BorderLayout(0, 5));
        chatPanel.setBorder(new EmptyBorder(5,5,5,5));

        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel(group.getName(), SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        JButton membersButton = new JButton("メンバー");
        membersButton.addActionListener(e -> showGroupMembersDialog(group));
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.add(membersButton, BorderLayout.EAST);
        chatPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel messageDisplayArea = new JPanel();
        messageDisplayArea.setLayout(new BoxLayout(messageDisplayArea, BoxLayout.Y_AXIS));
        messageDisplayArea.setBackground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(messageDisplayArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        chatPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new BorderLayout(5,5));
        JTextField inputField = new JTextField();
        JButton sendButton = new JButton("送信");

        Action sendMessageAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = inputField.getText().trim();
                if (!text.isEmpty() && connector != null && myUser != null && currentSelectedGroup != null) {
                     // connector.sendMessage(new share.ServerMessage("SEND_CHAT", gson.toJsonTree(new share.ChatRequest(currentSelectedGroup.getId(), text))));
                    System.out.println("チャット送信(未実装): " + currentSelectedGroup.getName() + "宛「" + text + "」");
                    inputField.setText("");
                }
            }
        };
        inputField.addActionListener(sendMessageAction);
        sendButton.addActionListener(sendMessageAction);
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        chatPanel.add(inputPanel, BorderLayout.SOUTH);
        chatPanel.setName("CHAT_PANEL_" + group.getId());
        return chatPanel;
    }

    private void loadChatHistoryForGroup(share.Group group) {
        System.out.println("[Calender] チャット履歴ロード開始: " + group.getName());
        JPanel messageDisplayArea = findMessageDisplayAreaForGroup(group.getId());
        if (messageDisplayArea == null) {
            System.err.println("[Calender] メッセージ表示エリアが見つかりません: " + group.getId());
            return;
        }
        messageDisplayArea.removeAll();

        if (currentUserData != null && currentUserData.getChats() != null) {
            currentUserData.getChats().stream()
                .filter(cm -> group.getId().equals(cm.getGroupId()))
                .sorted(Comparator.comparing(share.ChatMessage::getTimestamp))
                .forEach(chatMessage -> addChatMessageToUI(chatMessage, messageDisplayArea));
        } else {
            System.out.println("[Calender] 表示するチャット履歴がありません。");
        }
        messageDisplayArea.revalidate();
        messageDisplayArea.repaint();
        // スクロールを一番下に
        if (messageDisplayArea.getParent() instanceof JViewport) {
            JViewport viewport = (JViewport) messageDisplayArea.getParent();
            if (viewport.getParent() instanceof JScrollPane) {
                JScrollPane scrollPane = (JScrollPane) viewport.getParent();
                SwingUtilities.invokeLater(() -> {
                    JScrollBar vertical = scrollPane.getVerticalScrollBar();
                    vertical.setValue(vertical.getMaximum());
                });
            }
        }
    }

    private JPanel findMessageDisplayAreaForGroup(String groupId) {
        String panelName = "CHAT_PANEL_" + groupId;
        for (Component comp : centerCardPanel.getComponents()) {
            if (panelName.equals(comp.getName()) && comp instanceof JPanel) {
                JPanel chatPanel = (JPanel) comp;
                for(Component chatPanelComp : chatPanel.getComponents()){
                    if(chatPanelComp instanceof JScrollPane){
                        JScrollPane scrollPane = (JScrollPane) chatPanelComp;
                        Component view = scrollPane.getViewport().getView();
                        if(view instanceof JPanel){
                            return (JPanel) view;
                        }
                    }
                }
            }
        }
        return null;
    }

    private void addChatMessageToUI(share.ChatMessage message, JPanel messageDisplayArea) {
        if (messageDisplayArea == null) return;
        JPanel messageBubble = createMessageBubble(message);
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBorder(new EmptyBorder(2, 5, 2, 5));
        if (myUser != null && myUser.getUsername().equals(message.getSender())) {
            wrapper.add(messageBubble, BorderLayout.EAST);
        } else {
            wrapper.add(messageBubble, BorderLayout.WEST);
        }
        messageDisplayArea.add(wrapper);
        messageDisplayArea.revalidate();
        messageDisplayArea.repaint();
         // スクロールを一番下に
        if (messageDisplayArea.getParent() instanceof JViewport) {
            JViewport viewport = (JViewport) messageDisplayArea.getParent();
            if (viewport.getParent() instanceof JScrollPane) {
                JScrollPane scrollPane = (JScrollPane) viewport.getParent();
                SwingUtilities.invokeLater(() -> {
                    JScrollBar vertical = scrollPane.getVerticalScrollBar();
                    vertical.setValue(vertical.getMaximum());
                });
            }
        }
    }

    private JPanel createMessageBubble(share.ChatMessage message) {
        JPanel bubble = new JPanel(new BorderLayout(5, 2));
        bubble.setBorder(new EmptyBorder(5, 10, 5, 10));
        if (myUser == null || !myUser.getUsername().equals(message.getSender())) {
            JLabel senderLabel = new JLabel(message.getSender());
            senderLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
            senderLabel.setForeground(Color.DARK_GRAY);
            bubble.add(senderLabel, BorderLayout.NORTH);
        }
        JTextArea messageText = new JTextArea(message.getMessage());
        messageText.setEditable(false);
        messageText.setLineWrap(true);
        messageText.setWrapStyleWord(true);
        messageText.setFont(new Font("SansSerif", Font.PLAIN, 14));
        messageText.setOpaque(false);
        bubble.add(messageText, BorderLayout.CENTER);
        if (myUser != null && myUser.getUsername().equals(message.getSender())) {
            bubble.setBackground(new Color(200, 220, 255));
        } else {
            bubble.setBackground(new Color(230, 230, 230));
        }
        JPanel wrapper = new JPanel();
        wrapper.add(bubble);
        wrapper.setOpaque(false);
        wrapper.setMaximumSize(new Dimension(350, Short.MAX_VALUE));
        return wrapper;
    }

    private share.Group findGroupById(String id) {
        return currentGroups.stream().filter(g -> Objects.equals(g.getId(), id)).findFirst().orElse(null);
    }

    private void showGroupMembersDialog(share.Group group) {
        JOptionPane.showMessageDialog(frame, "グループメンバー管理 (サーバー連携 未実装)\nグループ: " + group.getName(), "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createCalendarView() {
        JPanel calendarContainer = new JPanel(new BorderLayout(0, 10));
        calendarContainer.setBorder(new EmptyBorder(5, 5, 5, 5));
        calendarContainer.add(createHeaderPanel(), BorderLayout.NORTH);
        calendarContainer.add(createCalendarGridPanel(), BorderLayout.CENTER);
        calendarContainer.add(createFooterPanel(), BorderLayout.SOUTH);
        return calendarContainer;
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(5, 5, 5, 5));
        JButton prevButton = new JButton("<");
        prevButton.addActionListener(e -> {
            currentDate = currentDate.minusMonths(1);
            updateHeader();
            updateCalendar();
        });
        JButton nextButton = new JButton(">");
        nextButton.addActionListener(e -> {
            currentDate = currentDate.plusMonths(1);
            updateHeader();
            updateCalendar();
        });
        monthDisplayPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        panel.add(prevButton, BorderLayout.WEST);
        panel.add(monthDisplayPanel, BorderLayout.CENTER);
        panel.add(nextButton, BorderLayout.EAST);
        return panel;
    }

    private void updateHeader() {
        monthDisplayPanel.removeAll();
        int year = currentDate.getYear();
        int month = currentDate.getMonthValue();
        JLabel label = new JLabel(String.format("%d年 %d月", year, month));
        label.setFont(new Font("SansSerif", Font.BOLD, 16));
        monthDisplayPanel.add(label);
        monthDisplayPanel.revalidate();
        monthDisplayPanel.repaint();
    }

    private Component createCalendarGridPanel() {
        JPanel gridContainer = new JPanel(new BorderLayout());
        JPanel dayOfWeekPanel = new JPanel(new GridLayout(1, CALENDAR_COLS));
        String[] days = {"日", "月", "火", "水", "木", "金", "土"};
        for (String day : days) {
            JLabel dayLabel = new JLabel(day, JLabel.CENTER);
            if (day.equals("日")) dayLabel.setForeground(Color.RED);
            if (day.equals("土")) dayLabel.setForeground(Color.BLUE);
            dayOfWeekPanel.add(dayLabel);
        }
        JPanel dateGridPanel = new JPanel(new GridLayout(CALENDAR_ROWS, CALENDAR_COLS, 2, 2));
        datePanels.clear();
        for (int i = 0; i < CALENDAR_ROWS * CALENDAR_COLS; i++) {
            JPanel dateCell = new JPanel(new BorderLayout());
            dateCell.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            dateGridPanel.add(dateCell);
            datePanels.add(dateCell);
        }
        gridContainer.add(dayOfWeekPanel, BorderLayout.NORTH);
        gridContainer.add(dateGridPanel, BorderLayout.CENTER);
        return gridContainer;
    }

    private JPanel createFooterPanel() {
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        footerPanel.add(new JLabel("月:"));
        JTextField monthField = new JTextField(String.valueOf(currentDate.getMonthValue()), 2);
        footerPanel.add(monthField);
        footerPanel.add(new JLabel("日:"));
        JTextField dayField = new JTextField(2);
        footerPanel.add(dayField);
        footerPanel.add(new JLabel("タイトル:"));
        JTextField titleField = new JTextField(15);
        footerPanel.add(titleField);
        JButton addButton = new JButton("追加");
        addButton.addActionListener(e -> handleAddAppointmentFromFooter(monthField, dayField, titleField));
        footerPanel.add(addButton);
        return footerPanel;
    }

    private void updateCalendar() {
        // schedules マップを最新の currentUserData.getSchedules() から再構築
        schedules.clear();
        if (currentUserData != null && currentUserData.getSchedules() != null) {
            for (share.Schedule schedule : currentUserData.getSchedules()) {
                if (schedule.getStartTime() != null) {
                    LocalDate date = schedule.getStartTime().toLocalDate();
                    schedules.computeIfAbsent(date, k -> new ArrayList<>()).add(schedule);
                }
            }
        }

        YearMonth yearMonth = YearMonth.from(currentDate);
        int daysInMonth = yearMonth.lengthOfMonth();
        LocalDate firstOfMonth = currentDate.withDayOfMonth(1);
        int startDayOfWeek = firstOfMonth.getDayOfWeek().getValue();
        if (startDayOfWeek == 7) startDayOfWeek = 0;

        for (int i = 0; i < datePanels.size(); i++) {
            JPanel dateCell = datePanels.get(i);
            dateCell.removeAll();
            dateCell.setBackground(Color.WHITE);
            dateCell.setName(null);
            int dayOfMonth = i - startDayOfWeek + 1;
            if (dayOfMonth > 0 && dayOfMonth <= daysInMonth) {
                LocalDate cellDate = LocalDate.of(currentDate.getYear(), currentDate.getMonthValue(), dayOfMonth);
                buildDateCellUI(dateCell, cellDate); // ここで updateDateCellView も呼ばれる
                if (cellDate.equals(LocalDate.now())) {
                    dateCell.setBackground(new Color(220, 240, 255));
                }
            }
            dateCell.revalidate();
            dateCell.repaint();
        }
    }

    private void buildDateCellUI(JPanel dateCell, LocalDate cellDate) {
        dateCell.setName(cellDate.toString());
        JLabel dateLabel = new JLabel(String.valueOf(cellDate.getDayOfMonth()), SwingConstants.RIGHT);
        dateLabel.setBorder(new EmptyBorder(2, 0, 0, 4));
        dateCell.add(dateLabel, BorderLayout.NORTH);
        JPanel appointmentContainer = new JPanel();
        appointmentContainer.setName("appointmentContainer_" + cellDate.toString());
        appointmentContainer.setLayout(new BoxLayout(appointmentContainer, BoxLayout.Y_AXIS));
        appointmentContainer.setOpaque(false);
        JScrollPane appointmentScrollPane = new JScrollPane(appointmentContainer); // スクロール可能に
        appointmentScrollPane.setBorder(null);
        appointmentScrollPane.setOpaque(false);
        appointmentScrollPane.getViewport().setOpaque(false);
        dateCell.add(appointmentScrollPane, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttonPanel.setOpaque(false);
        JButton addButton = new JButton("+");
        addButton.setMargin(new Insets(0, 0, 0, 0));
        addButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        addButton.setFocusable(false);
        SwingUtilities.invokeLater(() -> {
            int height = addButton.getPreferredSize().height;
            if (height > 0) addButton.setPreferredSize(new Dimension(height, height));
            buttonPanel.revalidate();
        });
        addButton.addActionListener(e -> {
            Object ownerContext = (currentSelectedGroup != null) ? (Object) currentSelectedGroup : (Object) myUser;
            showAppointmentDialog(cellDate, null, ownerContext, true);
        });
        buttonPanel.add(addButton);
        dateCell.add(buttonPanel, BorderLayout.SOUTH);
        updateDateCellView(cellDate);
    }
    
    private void updateDateCellView(LocalDate date) {
        JPanel targetCell = null;
        JPanel appointmentContainer = null;
        for(JPanel panel : datePanels) {
            if (date.toString().equals(panel.getName())) {
                targetCell = panel;
                for (Component comp : targetCell.getComponents()) { // targetCell直下のコンポーネントを検査
                    if (comp instanceof JScrollPane) {
                        JScrollPane scroll = (JScrollPane) comp;
                        Component view = scroll.getViewport().getView();
                        if (view instanceof JPanel && ("appointmentContainer_" + date.toString()).equals(view.getName())) {
                           appointmentContainer = (JPanel) view;
                           break;
                        }
                    }
                }
                if (appointmentContainer != null) break;
            }
        }
        if (targetCell == null || appointmentContainer == null) {
             System.err.println("[Calender.updateDateCellView] Error: Could not find date cell or appointment container for " + date);
             return;
        }
        appointmentContainer.removeAll();
        List<share.Schedule> daySchedules = schedules.getOrDefault(date, new ArrayList<>());

        for (share.Schedule schedule_loopVar : daySchedules) {
            // ownerの特定ロジック (myUserとcurrentGroupsを使って)
            Object owner_loopVar;
            if (schedule_loopVar.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) {
                owner_loopVar = myUser;
            } else if (schedule_loopVar.getGroupId() != null && !schedule_loopVar.getGroupId().isEmpty()) {
                owner_loopVar = findGroupById(schedule_loopVar.getGroupId());
            } else {
                // 他人の個人予定の場合、サーバーから全ユーザー情報を取得するまでは正確なUserオブジェクトは作れない
                // ここではダミーのUserオブジェクト（名前だけ持つなど）か、単にユーザー名文字列で扱うか検討
                // UserDataに全ユーザーリストが含まれないため、この部分は限定的
                owner_loopVar = new share.User(schedule_loopVar.getCreatedBy(), ""); // 仮のUserオブジェクト
            }

            boolean shouldDisplay = false;
            if (currentSelectedGroup == null) { // マイページ
                if (schedule_loopVar.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) shouldDisplay = true;
                else if (schedule_loopVar.getGroupId() != null) {
                    share.Group g = findGroupById(schedule_loopVar.getGroupId());
                    if (g != null && g.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(myUser.getUsername()))) {
                        shouldDisplay = true;
                    }
                }
            } else { // グループページ
                if (schedule_loopVar.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) shouldDisplay = true;
                else if (schedule_loopVar.getGroupId() != null && schedule_loopVar.getGroupId().equals(currentSelectedGroup.getId())) {
                    shouldDisplay = true;
                } else if (schedule_loopVar.getGroupId() == null || schedule_loopVar.getGroupId().isEmpty()) {
                    if (currentSelectedGroup.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(schedule_loopVar.getCreatedBy()))) {
                         shouldDisplay = true;
                    }
                }
            }

            if (shouldDisplay) {
                String displayTitle = schedule_loopVar.getTitle();
                boolean isPrivateView = (owner_loopVar instanceof share.User && !((share.User)owner_loopVar).getUsername().equals(myUser.getUsername()) && schedule_loopVar.isPrivate() && currentSelectedGroup != null);

                if (isPrivateView) {
                    displayTitle = "（非公開の予定）";
                }
                JButton appButton = new JButton("<html>" + displayTitle + "</html>");
                appButton.setOpaque(true);
                if (schedule_loopVar.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) {
                    appButton.setBackground(new Color(135, 206, 250));
                } else if (schedule_loopVar.getGroupId() != null && !schedule_loopVar.getGroupId().isEmpty()) {
                    appButton.setBackground(new Color(144, 238, 144));
                } else {
                    appButton.setBackground(new Color(220, 220, 220));
                }
                
                boolean isEditable_loopVar = (owner_loopVar != null && (owner_loopVar.equals(myUser) || (owner_loopVar instanceof share.Group && ((share.Group)owner_loopVar).getMembers().contains(myUser.getUsername()))));


                if (isPrivateView) {
                    appButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                } else {
                    final share.Schedule currentScheduleForListener = schedule_loopVar;
                    final Object currentOwnerForListener = owner_loopVar; // このowner_loopVarはUserかGroup
                    final boolean currentIsEditableForListener = isEditable_loopVar;
                    final LocalDate currentDateForListener = date;

                    appButton.addActionListener(e -> showAppointmentDialog(
                        currentDateForListener,
                        currentScheduleForListener,
                        currentOwnerForListener, // ここはUserかGroupオブジェクトを渡す想定
                        currentIsEditableForListener
                    ));
                    appButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                }
                appointmentContainer.add(appButton);
            }
        }
        appointmentContainer.revalidate();
        appointmentContainer.repaint();
    }
    
    private share.User findUserByUsernameInCurrentData(String username) {
        // UserDataに全ユーザーリストは含まれないため、このメソッドは現状不完全
        if (myUser != null && myUser.getUsername().equalsIgnoreCase(username)) return myUser;
        return null; // 本来はサーバーに問い合わせるか、初期データで全ユーザー情報を持つ
    }

    private void handleAddAppointmentFromFooter(JTextField monthField, JTextField dayField, JTextField titleField) {
        try {
            int month = Integer.parseInt(monthField.getText());
            int day = Integer.parseInt(dayField.getText());
            String title = titleField.getText().trim();
            if (title.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "タイトルを入力してください。", "入力エラー", JOptionPane.WARNING_MESSAGE); return;
            }
            LocalDate targetDate = LocalDate.of(currentDate.getYear(), month, day);
            Object ownerContext = (currentSelectedGroup != null) ? (Object) currentSelectedGroup : (Object) myUser;
            
            share.Schedule newSchedule = new share.Schedule();
            newSchedule.setTitle(title);
            newSchedule.setDescription("");
            newSchedule.setCreatedBy(myUser.getUsername());
            newSchedule.setAllDay(true);
            newSchedule.setPrivate(false);
            newSchedule.setStartTime(targetDate.atStartOfDay());
            newSchedule.setEndTime(targetDate.atTime(23,59,59));
            if (ownerContext instanceof share.Group) {
                newSchedule.setGroupId(((share.Group) ownerContext).getId());
            }
            // connector.sendMessage(new share.ServerMessage("ADD_SCHEDULE", gson.toJsonTree(newSchedule))); // ステップ2-1で実装
            System.out.println("フッターから予定追加(未実装): " + title);
            monthField.setText(String.valueOf(currentDate.getMonthValue()));
            dayField.setText("");
            titleField.setText("");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "入力が正しくありません。", "エラー", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showAppointmentDialog(LocalDate date, share.Schedule schedule, Object ownerContext, boolean isEditable) {
        boolean isNew = (schedule == null);
        share.Schedule targetSchedule;
        boolean isOwnerUserType = (ownerContext == myUser || (ownerContext instanceof share.User && ((share.User)ownerContext).getUsername().equals(myUser.getUsername())));
        if (schedule == null && ownerContext instanceof share.Group) { // グループの新規予定でownerContextがGroupの場合
             isOwnerUserType = false; // グループ予定なので個人所有ではない
        }


        if (isNew) {
            targetSchedule = new share.Schedule();
            targetSchedule.setCreatedBy(myUser.getUsername());
            targetSchedule.setAllDay(true);
            targetSchedule.setPrivate(false);
            // 予定の開始日時はダイアログを開く日付を基準にする
            targetSchedule.setStartTime(date.atStartOfDay());
            targetSchedule.setEndTime(date.atTime(23,59,59)); // 終日の場合のデフォルト終了時刻
            if (ownerContext instanceof share.Group) {
                targetSchedule.setGroupId(((share.Group) ownerContext).getId());
                isOwnerUserType = false; // 新規グループ予定
            } else {
                 isOwnerUserType = true; // 新規個人予定
            }
        } else {
            targetSchedule = schedule;
            // 既存の予定の場合、ownerContextがUserかGroupかで isOwnerUserType を決定
            if (targetSchedule.getGroupId() != null && !targetSchedule.getGroupId().isEmpty()) {
                isOwnerUserType = false; // グループ予定
            } else {
                isOwnerUserType = targetSchedule.getCreatedBy().equals(myUser.getUsername()); // 自分の個人予定か
            }
        }
        
        AppointmentDialog dialog = new AppointmentDialog(frame, targetSchedule, isNew, isEditable, isOwnerUserType);
        dialog.setVisible(true);
        int result = dialog.getResult();
        if (result == AppointmentDialog.OPTION_SAVE) {
            share.Schedule savedSchedule = dialog.getSchedule();
            // connector.sendMessage(...) // ステップ2-1で実装
            System.out.println((isNew ? "新規" : "更新") + "予定保存(未実装): " + savedSchedule.getTitle());
        } else if (result == AppointmentDialog.OPTION_DELETE && !isNew) {
            // connector.sendMessage(...) // ステップ2-1で実装
            System.out.println("予定削除(未実装): " + targetSchedule.getTitle());
        }
    }

    static class AppointmentDialog extends JDialog {
        public static final int OPTION_SAVE = 1, OPTION_DELETE = 2, OPTION_CANCEL = 0;
        private int result = OPTION_CANCEL;
        private JTextField titleField;
        private JTextArea detailsArea;
        private JCheckBox privateCheckBox;
        private JCheckBox allDayCheckBox;
        private JSpinner startTimeSpinner;
        private JSpinner endTimeSpinner;
        private JLabel timeLabel;
        private share.Schedule currentSchedule;
        private boolean isForPersonalAppointment; // このダイアログが個人予定用か (非公開チェック表示制御)

        public AppointmentDialog(Frame ownerFrame, share.Schedule schedule, boolean isNew, boolean isEditable, boolean isForPersonalAppointment) {
            super(ownerFrame, true);
            this.currentSchedule = new share.Schedule(); // 編集用にディープコピーする方が安全だが、今回は参照をコピー
            this.currentSchedule.setId(schedule.getId()); // IDは維持
            this.currentSchedule.setTitle(schedule.getTitle());
            this.currentSchedule.setDescription(schedule.getDescription());
            this.currentSchedule.setStartTime(schedule.getStartTime());
            this.currentSchedule.setEndTime(schedule.getEndTime());
            this.currentSchedule.setAllDay(schedule.isAllDay());
            this.currentSchedule.setGroupId(schedule.getGroupId());
            this.currentSchedule.setParticipants(schedule.getParticipants() != null ? new ArrayList<>(schedule.getParticipants()) : new ArrayList<>());
            this.currentSchedule.setCreatedBy(schedule.getCreatedBy());
            this.currentSchedule.setPrivate(schedule.isPrivate());
            
            this.isForPersonalAppointment = isForPersonalAppointment;

            String dialogTitle = isNew ? "予定の新規作成" : (isEditable ? "予定の編集/削除" : "予定の詳細");
            setTitle(dialogTitle);

            titleField = new JTextField(this.currentSchedule.getTitle(), 20);
            detailsArea = new JTextArea(this.currentSchedule.getDescription(), 5, 20);
            detailsArea.setLineWrap(true);
            detailsArea.setWrapStyleWord(true);
            privateCheckBox = new JCheckBox("非公開の予定にする");
            privateCheckBox.setSelected(this.currentSchedule.isPrivate());
            privateCheckBox.setVisible(this.isForPersonalAppointment);
            allDayCheckBox = new JCheckBox("終日の予定");
            allDayCheckBox.setSelected(this.currentSchedule.isAllDay());

            Date initStartTime = this.currentSchedule.getStartTime() != null ? Date.from(this.currentSchedule.getStartTime().atZone(ZoneId.systemDefault()).toInstant()) : new Date();
            Date initEndTime = this.currentSchedule.getEndTime() != null ? Date.from(this.currentSchedule.getEndTime().atZone(ZoneId.systemDefault()).toInstant()) : new Date();

            SpinnerDateModel startModel = new SpinnerDateModel(initStartTime, null, null, Calendar.MINUTE);
            startTimeSpinner = new JSpinner(startModel);
            startTimeSpinner.setEditor(new JSpinner.DateEditor(startTimeSpinner, "HH:mm"));
            SpinnerDateModel endModel = new SpinnerDateModel(initEndTime, null, null, Calendar.MINUTE);
            endTimeSpinner = new JSpinner(endModel);
            endTimeSpinner.setEditor(new JSpinner.DateEditor(endTimeSpinner, "HH:mm"));
            timeLabel = new JLabel("時間:");

            allDayCheckBox.addActionListener(e -> {
                boolean isAllDay = allDayCheckBox.isSelected();
                startTimeSpinner.setVisible(!isAllDay);
                endTimeSpinner.setVisible(!isAllDay);
                timeLabel.setVisible(!isAllDay);
            });
            startTimeSpinner.setVisible(!this.currentSchedule.isAllDay());
            endTimeSpinner.setVisible(!this.currentSchedule.isAllDay());
            timeLabel.setVisible(!this.currentSchedule.isAllDay());

            JLabel ownerDisplayLabel = new JLabel();
            ownerDisplayLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            ownerDisplayLabel.setForeground(Color.GRAY);
            if (this.currentSchedule.getGroupId() != null && !this.currentSchedule.getGroupId().isEmpty()) {
                ownerDisplayLabel.setText("共有グループID: " + this.currentSchedule.getGroupId());
            } else {
                ownerDisplayLabel.setText("所有者: " + this.currentSchedule.getCreatedBy() + " (個人)");
            }

            JPanel buttonPanelContainer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            if (isEditable) {
                JButton saveButton = new JButton("保存");
                saveButton.addActionListener(e -> { result = OPTION_SAVE; dispose(); });
                buttonPanelContainer.add(saveButton);
                if (!isNew) {
                    JButton deleteButton = new JButton("削除");
                    deleteButton.addActionListener(e -> {
                        if (JOptionPane.showConfirmDialog(this, "この予定を削除しますか？", "確認", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                            result = OPTION_DELETE; dispose();
                        }
                    });
                    buttonPanelContainer.add(deleteButton);
                }
                JButton cancelButton = new JButton("キャンセル");
                cancelButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(cancelButton);
            } else {
                JButton closeButton = new JButton("閉じる");
                closeButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(closeButton);
                titleField.setEditable(false); detailsArea.setEditable(false);
                privateCheckBox.setEnabled(false); allDayCheckBox.setEnabled(false);
                startTimeSpinner.setEnabled(false); endTimeSpinner.setEnabled(false);
                titleField.setFocusable(false); detailsArea.setFocusable(false);
            }

            JPanel fieldsPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST; gbc.insets = new Insets(2,2,2,2);
            fieldsPanel.add(new JLabel("タイトル:"), gbc);
            gbc.gridx = 1; gbc.gridy = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(titleField, gbc);
            gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
            fieldsPanel.add(new JLabel("詳細:"), gbc);
            gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
            fieldsPanel.add(new JScrollPane(detailsArea), gbc);
            gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weighty = 0;
            fieldsPanel.add(allDayCheckBox, gbc);
            JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5,0));
            timePanel.add(timeLabel); timePanel.add(startTimeSpinner);
            timePanel.add(new JLabel("～")); timePanel.add(endTimeSpinner);
            gbc.gridx = 1; gbc.gridy = 2; gbc.fill = GridBagConstraints.HORIZONTAL;
            fieldsPanel.add(timePanel, gbc);
            if (this.isForPersonalAppointment) {
                 gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
                 fieldsPanel.add(privateCheckBox, gbc);
            }
            JPanel mainContentPanel = new JPanel(new BorderLayout(5,5));
            mainContentPanel.setBorder(new EmptyBorder(10,10,10,10));
            mainContentPanel.add(fieldsPanel, BorderLayout.CENTER);
            JPanel southPanel = new JPanel(new BorderLayout());
            southPanel.add(ownerDisplayLabel, BorderLayout.WEST);
            southPanel.add(buttonPanelContainer, BorderLayout.EAST);
            getContentPane().add(mainContentPanel, BorderLayout.CENTER);
            getContentPane().add(southPanel, BorderLayout.SOUTH);
            pack();
            setLocationRelativeTo(ownerFrame);
        }

        public int getResult() { return result; }

        public share.Schedule getSchedule() {
            currentSchedule.setTitle(titleField.getText());
            currentSchedule.setDescription(detailsArea.getText());
            currentSchedule.setPrivate(isForPersonalAppointment && privateCheckBox.isSelected());
            currentSchedule.setAllDay(allDayCheckBox.isSelected());

            // 日付部分は元のスケジュール or ダイアログを開いた時の日付を維持
            LocalDate scheduleDate = currentSchedule.getStartTime().toLocalDate();

            if (!currentSchedule.isAllDay()) {
                Date startTimeUtilDate = (Date) startTimeSpinner.getValue();
                Date endTimeUtilDate = (Date) endTimeSpinner.getValue();
                LocalDateTime startLDT = LocalDateTime.ofInstant(startTimeUtilDate.toInstant(), ZoneId.systemDefault());
                LocalDateTime endLDT = LocalDateTime.ofInstant(endTimeUtilDate.toInstant(), ZoneId.systemDefault());
                currentSchedule.setStartTime(LocalDateTime.of(scheduleDate, startLDT.toLocalTime()));
                currentSchedule.setEndTime(LocalDateTime.of(scheduleDate, endLDT.toLocalTime()));
            } else {
                 currentSchedule.setStartTime(scheduleDate.atStartOfDay());
                 currentSchedule.setEndTime(scheduleDate.atTime(23,59,59));
            }
            return currentSchedule;
        }
    }
}