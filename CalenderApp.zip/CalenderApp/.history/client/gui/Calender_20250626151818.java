package client.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent; // AbstractActionで使用
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import java.util.Comparator;
import java.util.Date;
import java.util.Calendar; // AppointmentDialogのSpinnerで使用
import java.util.stream.Collectors;
import java.time.LocalTime;

// shareパッケージのクラスをインポート
import share.User;
import share.Group;
import share.Schedule;
import share.ChatMessage;
import share.UserData;

import client.Connector;

public class Calender {
    private static final int CALENDAR_ROWS = 6;
    private static final int CALENDAR_COLS = 7;
    private static final String MY_PAGE_ID = "MY_PAGE_VIEW"; // CardLayoutのキーとして使用

    private JFrame frame;
    private final List<JPanel> datePanels = new ArrayList<>();
    private JPanel monthDisplayPanel;
    private JPanel centerCardPanel; // マイページやチャットパネルを切り替える
    private CardLayout centerCardLayout;
    private JPanel sidebarPanel; // グループアイコンリスト

    // データ関連
    private share.User myUser;         // ログインユーザー情報
    private Connector connector;       // サーバー通信用
    private share.UserData currentUserData; // ログイン時にサーバーから受け取った全関連データ

    // 表示用データキャッシュ (currentUserDataから都度生成またはフィルタリング)
    private final Map<LocalDate, List<share.Schedule>> displayedSchedules = new HashMap<>();
    private final List<share.Group> myGroups = new ArrayList<>(); // 自分が所属するグループ
    private share.Group currentSelectedGroup; // 現在表示しているグループ (nullならマイページ)

    private LocalDate currentDateForCalendar; // カレンダーが表示している月

    public Calender(share.User loggedInUser, Connector connector, share.UserData initialUserData) {
        this.myUser = loggedInUser;
        this.connector = connector;
        this.currentUserData = initialUserData;

        if (this.currentUserData != null && this.currentUserData.getGroups() != null) {
            System.out.println("[Calender Constructor] UserDataからグループをロードします。 Group数: " + this.currentUserData.getGroups().size()); // ★★★ログ追加
            for (share.Group serverGroup : this.currentUserData.getGroups()) {
                System.out.println("  -> 追加試行: " + serverGroup.getName() + " (ID: " + serverGroup.getId() + ")"); // ★★★ログ追加
                this.myGroups.add(serverGroup); // ここで直接追加
            }
            System.out.println("[Calender Constructor] ロード後のmyGroupsサイズ: " + this.myGroups.size()); // ★★★ログ追加
            for(share.Group g : this.myGroups) {
                System.out.println("  - myGroups内容: " + g.getName() + " (ID: " + g.getId() + ")"); // ★★★ログ追加
            }
        } else {
            System.out.println("[Calender Constructor] UserDataまたはGroupsがnullです。"); // ★★★ログ追加
        }
    }

    // client/gui/Calender.java 内に追加または修正
    private share.Group findGroupById(String id) {
        if (id == null) return null;
        return this.myGroups.stream() // 検索対象を this.myGroups (自分が所属するグループリスト) にする
                .filter(g -> id.equals(g.getId()))
                .findFirst()
                .orElse(null);
    }

    public void createAndShowGUI() {
        currentDateForCalendar = LocalDate.now();

        frame = new JFrame("カレンダー共有アプリ - " + (myUser != null ? myUser.getUsername() : "ゲスト"));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 800); // 少し大きめに

        JPanel mainPanel = createMainLayout();
        frame.add(mainPanel);

        updateHeaderDateDisplay(); // ヘッダーの年月表示を更新
        updateCalendarView();    // カレンダーのセルと予定を更新

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // TODO: 必要であれば、サーバーからのプッシュ通知を受け取るリスナーをConnectorに設定
        // (例: 他のユーザーがチャット送信、予定追加など)
    }

    private JPanel createMainLayout() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        sidebarPanel = createSidebarPanel();
        centerCardLayout = new CardLayout();
        centerCardPanel = new JPanel(centerCardLayout);

        centerCardPanel.add(createMyPagePanel(), MY_PAGE_ID);
        for (share.Group group : myGroups) {
            centerCardPanel.add(createChatPanel(group), group.getId()); // group.getId()をキーに
        }

        JPanel calendarDisplayPanel = createCalendarDisplayPanel();

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.15; gbc.gridheight = 2;
        mainPanel.add(sidebarPanel, gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.35; gbc.gridheight = 1;
        mainPanel.add(centerCardPanel, gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 0.35; // gbc.weighty = 0.1; // フッターの高さ調整
        mainPanel.add(createFooterActionPanel(), gbc); // 簡易予定追加フッター

        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0.5; gbc.gridheight = 2;
        mainPanel.add(calendarDisplayPanel, gbc);


        centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
        currentSelectedGroup = null;
        return mainPanel;
    }

    private JPanel createSidebarPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("ナビゲーション"));
        panel.setBackground(new Color(240, 248, 255)); // AliceBlue

        String myUsername = (myUser != null && myUser.getUsername() != null) ? myUser.getUsername() : "M";
        char myInitial = myUsername.isEmpty() ? 'M' : myUsername.charAt(0);
        panel.add(createGroupIcon(MY_PAGE_ID, "マイページ (" + myUsername + ")", myInitial, true)); // isMyPage=true
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(new JSeparator());
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel groupListLabel = new JLabel("所属グループ");
        groupListLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(groupListLabel);
        panel.add(Box.createRigidArea(new Dimension(0,5)));

        for (share.Group group : myGroups) {
            char groupInitial = group.getName().isEmpty() ? 'G' : group.getName().charAt(0);
            panel.add(createGroupIcon(group.getId(), group.getName(), groupInitial, false)); // isMyPage=false
        }
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    private Component createGroupIcon(String id, String tooltip, char iconChar, boolean isMyPageIcon) {
        // ... (前回のcreateGroupIconの実装を流用、選択状態のロジックを currentSelectedGroup と id で判定)
        /* 
        JButton iconButton = new JButton(String.valueOf(iconChar)); // JLabelからJButtonに変更してフォーカス制御しやすくする
        iconButton.setToolTipText(tooltip);
        Dimension iconSize = new Dimension(60, 60); // 少し大きく
        iconButton.setPreferredSize(iconSize);
        iconButton.setMinimumSize(iconSize);
        iconButton.setMaximumSize(new Dimension(Short.MAX_VALUE, iconSize.height));
        iconButton.setFont(new Font("SansSerif", Font.BOLD, 28));
        iconButton.setForeground(Color.WHITE);
        iconButton.setFocusPainted(false);
        iconButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        iconButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        iconButton.setContentAreaFilled(false); // 背景はカスタム描画
        iconButton.setBorderPainted(false);

        // カスタムペイントで円形背景を描画
        iconButton.addMouseListener(new MouseAdapter() {
             @Override
            public void mousePressed(MouseEvent e) {
                // クリック時の見た目のフィードバックなど（任意）
            }
            @Override
            public void mouseClicked(MouseEvent e) {
                if (id.equals(MY_PAGE_ID)) {
                    currentSelectedGroup = null;
                    centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
                } else {
                    currentSelectedGroup = findGroupById(id);
                    if (currentSelectedGroup != null) {
                        centerCardLayout.show(centerCardPanel, id);
                        loadChatHistoryForGroup(currentSelectedGroup); // チャット履歴読み込み
                    }
                }
                updateSidebarSelection(); // サイドバーの選択状態を更新
                updateCalendarView();
            }
        });
        // アイコンボタンのコンテナ (選択状態の枠線などを描画するため)
        JPanel iconWrapper = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean isSelected = id.equals(MY_PAGE_ID) ? currentSelectedGroup == null : (currentSelectedGroup != null && id.equals(currentSelectedGroup.getId()));
                
                Color bgColor = isMyPageIcon ? new Color(100, 150, 255) : new Color(120, 200, 120); // マイページとグループで色分け
                if(isSelected) {
                    bgColor = bgColor.darker();
                }
                g2.setColor(bgColor);
                g2.fillOval(5, 5, getWidth() - 10, getHeight() - 10);

                if (isSelected) {
                    g2.setColor(Color.BLACK); // 選択時の枠線
                    g2.setStroke(new BasicStroke(2));
                    g2.drawOval(3, 3, getWidth() - 7, getHeight() - 7);
                }
                g2.dispose();
            }
        };
        iconButton.setName("ICON_BTN_" + id); // 後で選択状態更新のため
        iconWrapper.add(iconButton, BorderLayout.CENTER);
        iconWrapper.setOpaque(false);
        iconWrapper.setBorder(new EmptyBorder(5,10,5,10));
        iconWrapper.setMaximumSize(new Dimension(Short.MAX_VALUE, iconSize.height + 10));

        return iconWrapper;
        */
        JLabel simpleLabel = new JLabel("ID: " + id + ", Name: " + tooltip);
        simpleLabel.setBorder(BorderFactory.createLineBorder(Color.MAGENTA)); // 見えるように枠線
        simpleLabel.setOpaque(true);
        simpleLabel.setBackground(Color.CYAN);
        simpleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        simpleLabel.setMaximumSize(new Dimension(Short.MAX_VALUE, 30)); // 高さを固定
        System.out.println("[createGroupIcon Test] Creating label for: " + tooltip); // ログ追加
        return simpleLabel;
    }
    
    private void updateSidebarSelection() {
        // 全てのアイコンボタンの見た目をリセットし、選択されたものだけを強調する
        // (実際にはpaintComponent内でisSelectedを見て描画するので、repaintだけで良い場合が多い)
        sidebarPanel.repaint();
    }


    private JPanel createMyPagePanel() {
        JPanel myPagePanel = new JPanel(new BorderLayout(10,10));
        myPagePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        myPagePanel.setBackground(Color.WHITE);

        // ユーザー情報
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);
        JLabel nameLabel = new JLabel("ようこそ、" + (myUser != null ? myUser.getUsername() : "ゲスト") + " さん");
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        infoPanel.add(nameLabel);
        // 他のユーザー情報を表示する場合はここに追加 (例: メールアドレスは削除したので表示なし)
        myPagePanel.add(infoPanel, BorderLayout.NORTH);

        // アクションボタンパネル
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        actionPanel.setOpaque(false);
        JButton createGroupButton = new JButton("新しいグループを作成");
        createGroupButton.addActionListener(e -> showCreateGroupDialog()); // TODO: サーバー連携
        actionPanel.add(createGroupButton);
        myPagePanel.add(actionPanel, BorderLayout.CENTER);
        
        // TODO: マイページに所属グループ一覧と脱退ボタンを実装 (No.4, No.6の確定事項)
        // JPanel myGroupsPanel = new JPanel();
        // ...
        // myPagePanel.add(new JScrollPane(myGroupsPanel), BorderLayout.SOUTH);

        return myPagePanel;
    }

    private void showCreateGroupDialog() {
        // TODO: ステップ2-2: グループ作成ダイアログの実装とサーバー連携
        JOptionPane.showMessageDialog(frame, "グループ作成機能 (未実装)", "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createChatPanel(share.Group group) {
        JPanel chatPanel = new JPanel(new BorderLayout(0, 10));
        chatPanel.setBorder(new EmptyBorder(10,10,10,10));
        chatPanel.setName("CHAT_PANEL_" + group.getId()); // CardLayoutでの識別用

        // ヘッダー: グループ名とメンバー表示ボタン
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel groupTitleLabel = new JLabel(group.getName(), SwingConstants.CENTER);
        groupTitleLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        JButton membersButton = new JButton("メンバー (" + group.getMembers().size() + ")"); //メンバー数を表示
        membersButton.addActionListener(e -> showGroupMembersDialog(group)); // TODO: サーバー連携
        headerPanel.add(groupTitleLabel, BorderLayout.CENTER);
        headerPanel.add(membersButton, BorderLayout.EAST);
        chatPanel.add(headerPanel, BorderLayout.NORTH);

        // チャットメッセージ表示エリア
        JTextArea messageDisplayArea = new JTextArea(); // JTextAreaに変更してテキスト選択などを可能に
        messageDisplayArea.setEditable(false);
        messageDisplayArea.setLineWrap(true);
        messageDisplayArea.setWrapStyleWord(true);
        messageDisplayArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        messageDisplayArea.setName("ChatDisplayArea_" + group.getId()); // 後でメッセージ追加のため

        JScrollPane scrollPane = new JScrollPane(messageDisplayArea);
        chatPanel.add(scrollPane, BorderLayout.CENTER);

        // 入力エリア
        JPanel inputSouthPanel = new JPanel(new BorderLayout(5,5));
        JTextField messageInputField = new JTextField();
        JButton sendMessageButton = new JButton("送信");

        sendMessageButton.addActionListener(e -> {
            String messageText = messageInputField.getText().trim();
            if (!messageText.isEmpty() && connector != null && myUser != null) {
                System.out.println("[Chat] 送信試行: GroupID=" + group.getId() + ", User=" + myUser.getUsername() + ", Msg=" + messageText);
                // TODO: ステップ3-1: サーバーにSEND_CHATリクエストを送信
                // connector.sendMessage(new share.ServerMessage("SEND_CHAT", gson.toJsonTree(new share.ChatRequest(group.getId(), messageText))));
                messageInputField.setText("");
            }
        });
        messageInputField.addActionListener(sendMessageButton.getActionListeners()[0]); // Enterキーでも送信

        inputSouthPanel.add(messageInputField, BorderLayout.CENTER);
        inputSouthPanel.add(sendMessageButton, BorderLayout.EAST);
        chatPanel.add(inputSouthPanel, BorderLayout.SOUTH);

        return chatPanel;
    }
    
    // 特定グループのチャット履歴をサーバーから取得して表示 (または currentUserData から)
    private void loadChatHistoryForGroup(share.Group group) {
        // TODO: ステップ3-1: 必要であればサーバーに "GET_CHAT_HISTORY" リクエストを送信
        // 現在は currentUserData に含まれるチャットで初期表示
        JTextArea displayArea = findChatDisplayAreaForGroup(group.getId());
        if (displayArea == null) return;

        displayArea.setText(""); // クリア
        if (currentUserData != null && currentUserData.getChats() != null) {
            currentUserData.getChats().stream()
                .filter(cm -> group.getId().equals(cm.getGroupId()))
                .sorted(Comparator.comparing(share.ChatMessage::getTimestamp))
                .forEach(chatMessage -> appendChatMessageToUI(chatMessage, displayArea));
        }
        // スクロールを一番下に
        displayArea.setCaretPosition(displayArea.getDocument().getLength());
    }
    
    // チャットメッセージをJTextAreaに追加 (GUIスレッドで呼ばれる想定)
    public void appendChatMessageToUI(share.ChatMessage message, String groupId) {
        if (currentSelectedGroup != null && currentSelectedGroup.getId().equals(groupId)) {
            JTextArea displayArea = findChatDisplayAreaForGroup(groupId);
            if (displayArea != null) {
                appendChatMessageToUI(message, displayArea);
                 displayArea.setCaretPosition(displayArea.getDocument().getLength());
            }
        }
        // TODO: 未読通知などの実装
    }


    private void appendChatMessageToUI(share.ChatMessage message, JTextArea displayArea) {
        // シンプルなテキスト形式で表示
        String prefix = message.getSender().equals(myUser.getUsername()) ? "[自分] " : "[" + message.getSender() + "] ";
        displayArea.append(prefix + message.getMessage() + " (" + formatDateTime(message.getTimestamp()) + ")\n");
    }
    
    private String formatDateTime(LocalDateTime ldt){
        if(ldt == null) return "";
        return ldt.format(java.time.format.DateTimeFormatter.ofPattern("MM/dd HH:mm"));
    }

    private JTextArea findChatDisplayAreaForGroup(String groupId) {
        String panelName = "CHAT_PANEL_" + groupId;
        for (Component comp : centerCardPanel.getComponents()) {
            if (panelName.equals(comp.getName()) && comp instanceof JPanel) {
                JPanel chatPanel = (JPanel) comp;
                for(Component chatPanelComp : chatPanel.getComponents()){ // BorderLayout.CENTER の JScrollPane を探す
                    if(chatPanelComp instanceof JScrollPane){
                        JScrollPane scrollPane = (JScrollPane) chatPanelComp;
                        Component view = scrollPane.getViewport().getView();
                        if(view instanceof JTextArea && ("ChatDisplayArea_" + groupId).equals(view.getName())){
                            return (JTextArea) view;
                        }
                    }
                }
            }
        }
        return null;
    }


    private void showGroupMembersDialog(share.Group group) {
        // TODO: ステップ2-2: サーバーからメンバーリストを取得し表示、招待機能も実装
        JOptionPane.showMessageDialog(frame, "グループメンバー管理 (未実装)\nグループ: " + group.getName(), "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createCalendarDisplayPanel() {
        JPanel calendarContainer = new JPanel(new BorderLayout(0, 10));
        calendarContainer.setBorder(new EmptyBorder(10, 10, 10, 10));
        calendarContainer.add(createCalendarHeaderPanel(), BorderLayout.NORTH);
        calendarContainer.add(createDateGridPanel(), BorderLayout.CENTER);
        // フッターの予定追加はメインレイアウトに移動
        return calendarContainer;
    }

    private JPanel createCalendarHeaderPanel() {
        // ... (updateHeaderDateDisplay に処理を移譲したので、ここはシンプルに)
        JPanel panel = new JPanel(new BorderLayout());
        JButton prevButton = new JButton("< 前月");
        prevButton.addActionListener(e -> {
            currentDateForCalendar = currentDateForCalendar.minusMonths(1);
            updateHeaderDateDisplay();
            updateCalendarView();
        });
        JButton nextButton = new JButton("次月 >");
        nextButton.addActionListener(e -> {
            currentDateForCalendar = currentDateForCalendar.plusMonths(1);
            updateHeaderDateDisplay();
            updateCalendarView();
        });
        monthDisplayPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        panel.add(prevButton, BorderLayout.WEST);
        panel.add(monthDisplayPanel, BorderLayout.CENTER);
        panel.add(nextButton, BorderLayout.EAST);
        return panel;
    }

    private void updateHeaderDateDisplay() {
        monthDisplayPanel.removeAll();
        JLabel label = new JLabel(String.format("%d年 %d月", currentDateForCalendar.getYear(), currentDateForCalendar.getMonthValue()));
        label.setFont(new Font("SansSerif", Font.BOLD, 18));
        monthDisplayPanel.add(label);
        monthDisplayPanel.revalidate();
        monthDisplayPanel.repaint();
    }

    private Component createDateGridPanel() {
        // ... (createCalendarGridPanelから曜日表示と日付グリッド生成部分を分離)
        JPanel gridOuterContainer = new JPanel(new BorderLayout());
        JPanel dayOfWeekPanel = new JPanel(new GridLayout(1, CALENDAR_COLS, 2, 2));
        String[] days = {"日", "月", "火", "水", "木", "金", "土"};
        for (String day : days) {
            JLabel dayLabel = new JLabel(day, JLabel.CENTER);
            dayLabel.setOpaque(true);
            dayLabel.setBackground(Color.LIGHT_GRAY);
            dayLabel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
            if (day.equals("日")) dayLabel.setForeground(Color.RED);
            if (day.equals("土")) dayLabel.setForeground(Color.BLUE);
            dayOfWeekPanel.add(dayLabel);
        }
        JPanel dateGridPanel = new JPanel(new GridLayout(CALENDAR_ROWS, CALENDAR_COLS, 2, 2));
        dateGridPanel.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        datePanels.clear();
        for (int i = 0; i < CALENDAR_ROWS * CALENDAR_COLS; i++) {
            JPanel dateCell = new JPanel(new BorderLayout());
            dateCell.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            dateGridPanel.add(dateCell);
            datePanels.add(dateCell);
        }
        gridOuterContainer.add(dayOfWeekPanel, BorderLayout.NORTH);
        gridOuterContainer.add(dateGridPanel, BorderLayout.CENTER);
        return gridOuterContainer;
    }
    
    private JPanel createFooterActionPanel() {
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        // footerPanel.add(new JLabel("簡易追加:"));
        // JTextField monthField = new JTextField(String.valueOf(currentDateForCalendar.getMonthValue()), 2);
        // footerPanel.add(monthField);
        // footerPanel.add(new JLabel("月"));
        // JTextField dayField = new JTextField(2);
        // footerPanel.add(dayField);
        // footerPanel.add(new JLabel("日"));
        // JTextField titleField = new JTextField("タイトル",15);
        // footerPanel.add(titleField);
        // JButton quickAddButton = new JButton("追加");
        // quickAddButton.addActionListener(e -> handleAddScheduleFromFooter(monthField, dayField, titleField));
        // footerPanel.add(quickAddButton);
        // フッターの簡易追加は一旦コメントアウト（UIが複雑になるため）
        // 必要であれば、より洗練された形で再度検討
        return footerPanel;
    }


    private void updateCalendarView() {
        // 1. 表示用スケジュールマップ (displayedSchedules) を currentUserData から再構築
        displayedSchedules.clear();
        if (currentUserData != null && currentUserData.getSchedules() != null) {
            for (share.Schedule schedule : currentUserData.getSchedules()) {
                if (schedule.getStartTime() != null) {
                    LocalDate date = schedule.getStartTime().toLocalDate();
                    // ここで、currentSelectedGroupに応じて表示するスケジュールをフィルタリングする
                    boolean shouldAdd = false;
                    if (currentSelectedGroup == null) { // マイページ
                        if (schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) { // 自分の予定
                            shouldAdd = true;
                        } else if (schedule.getGroupId() != null) { // グループ予定
                            share.Group g = findGroupById(schedule.getGroupId()); // 所属グループか確認
                            if (g != null) shouldAdd = true;
                        }
                    } else { // グループページ
                        if (schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername())) { // 自分の予定
                            shouldAdd = true;
                        } else if (schedule.getGroupId() != null && schedule.getGroupId().equals(currentSelectedGroup.getId())) { // 表示中グループの予定
                            shouldAdd = true;
                        } else if (schedule.getGroupId() == null || schedule.getGroupId().isEmpty()) { // 他人の個人予定
                            if (currentSelectedGroup.getMembers().stream().anyMatch(m -> m.equalsIgnoreCase(schedule.getCreatedBy()))) {
                                shouldAdd = true; // グループメンバーの個人予定
                            }
                        }
                    }
                    if(shouldAdd) {
                        displayedSchedules.computeIfAbsent(date, k -> new ArrayList<>()).add(schedule);
                    }
                }
            }
        }

        // 2. カレンダーの日付セルを更新
        YearMonth yearMonth = YearMonth.from(currentDateForCalendar);
        int daysInMonth = yearMonth.lengthOfMonth();
        LocalDate firstOfMonth = currentDateForCalendar.withDayOfMonth(1);
        int startDayOfWeek = firstOfMonth.getDayOfWeek().getValue(); // MON=1, SUN=7
        if (startDayOfWeek == 7) startDayOfWeek = 0; // 日曜始まりに調整 (0-6)

        for (int i = 0; i < datePanels.size(); i++) {
            JPanel dateCell = datePanels.get(i);
            dateCell.removeAll();
            dateCell.setBackground(Color.WHITE);
            dateCell.setName(null);
            int dayOfMonth = i - startDayOfWeek + 1;

            if (dayOfMonth > 0 && dayOfMonth <= daysInMonth) {
                LocalDate cellDate = currentDateForCalendar.withDayOfMonth(dayOfMonth);
                buildDateCellUIWithSchedules(dateCell, cellDate); // UI構築と予定表示
                if (cellDate.equals(LocalDate.now())) {
                    dateCell.setBackground(new Color(230, 240, 255)); // 今日の日付を少し強調
                }
            }
            dateCell.revalidate();
            dateCell.repaint();
        }
    }

    private void buildDateCellUIWithSchedules(JPanel dateCell, LocalDate cellDate) {
        dateCell.setName(cellDate.toString());
        // 日付ラベル
        JLabel dateLabel = new JLabel(String.valueOf(cellDate.getDayOfMonth()), SwingConstants.RIGHT);
        dateLabel.setBorder(new EmptyBorder(2, 0, 2, 4));
        dateCell.add(dateLabel, BorderLayout.NORTH);

        // 予定表示コンテナ
        JPanel appointmentContainer = new JPanel();
        appointmentContainer.setLayout(new BoxLayout(appointmentContainer, BoxLayout.Y_AXIS));
        appointmentContainer.setOpaque(false); // セルの背景色が見えるように

        List<share.Schedule> daySchedules = displayedSchedules.getOrDefault(cellDate, new ArrayList<>());
        for (share.Schedule schedule : daySchedules) {
            String displayTitle = schedule.getTitle();
            boolean isOwner = schedule.getCreatedBy().equalsIgnoreCase(myUser.getUsername());
            boolean isGroupSchedule = schedule.getGroupId() != null && !schedule.getGroupId().isEmpty();
            boolean isPrivateView = !isOwner && schedule.isPrivate() && currentSelectedGroup != null;

            if (isPrivateView) {
                displayTitle = "（非公開の予定）";
            }

            JButton appButton = new JButton("<html><body style='text-align:left; width:90px;'>" + displayTitle + "</body></html>"); // 横幅指定で折り返し期待
            appButton.setHorizontalAlignment(SwingConstants.LEFT);
            appButton.setMargin(new Insets(1,3,1,3));
            appButton.setFont(new Font("SansSerif", Font.PLAIN, 10));
            appButton.setOpaque(true);

            if (isOwner) {
                appButton.setBackground(new Color(135, 206, 250)); // 自分の予定: 青
            } else if (isGroupSchedule) {
                appButton.setBackground(new Color(144, 238, 144)); // グループ予定: 緑
            } else {
                appButton.setBackground(new Color(220, 220, 220)); // 他人の個人予定: 灰
            }

            boolean isEditable = isOwner || isGroupSchedule; // 自分かグループの予定なら編集可
            if (isPrivateView) { // 他人の非公開予定はクリックアクションなし
                appButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            } else {
                final share.Schedule currentScheduleForListener = schedule;
                final Object currentOwnerContext = isOwner ? myUser : (isGroupSchedule ? findGroupById(schedule.getGroupId()) : new share.User(schedule.getCreatedBy(), "")); // ダミーUser
                final boolean currentIsEditableForListener = isEditable;
                final LocalDate currentDateForListener = cellDate;
                appButton.addActionListener(e -> showAppointmentDialog(
                    currentDateForListener,
                    currentScheduleForListener,
                    currentOwnerContext,
                    currentIsEditableForListener
                ));
                appButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            appointmentContainer.add(appButton);
            appointmentContainer.add(Box.createRigidArea(new Dimension(0,1))); // ボタン間の隙間
        }
        // スクロールバーは必要な時だけ出るように
        JScrollPane appointmentScrollPane = new JScrollPane(appointmentContainer,
                                                            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                                            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        appointmentScrollPane.setBorder(null);
        appointmentScrollPane.setOpaque(false);
        appointmentScrollPane.getViewport().setOpaque(false);
        dateCell.add(appointmentScrollPane, BorderLayout.CENTER);

        // 新規追加ボタン
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        buttonPanel.setOpaque(false);
        JButton addButton = new JButton("+");
        addButton.setMargin(new Insets(0,2,0,2));
        addButton.setFont(new Font("SansSerif", Font.PLAIN, 10)); // 少し小さく
        addButton.setFocusable(false);
        addButton.addActionListener(e -> {
            Object ownerContext = (currentSelectedGroup != null) ? (Object) currentSelectedGroup : (Object) myUser;
            showAppointmentDialog(cellDate, null, ownerContext, true);
        });
        buttonPanel.add(addButton);
        dateCell.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void handleAddScheduleFromFooter(JTextField monthField, JTextField dayField, JTextField titleField) {
        // TODO: ステップ2-1: フッターからの予定追加もサーバー連携
        JOptionPane.showMessageDialog(frame, "フッターからの簡易予定追加 (未実装)", "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAppointmentDialog(LocalDate dateForNew, share.Schedule scheduleToEdit, Object ownerContext, boolean isEditable) {
        // ... (前回提案の AppointmentDialog 呼び出しロジック、share.Schedule を使用)
        boolean isNew = (scheduleToEdit == null);
        share.Schedule targetSchedule;
        boolean isOwnerUserTypeForDialog; // ダイアログに渡す「個人予定か」フラグ

        if (isNew) {
            targetSchedule = new share.Schedule();
            targetSchedule.setCreatedBy(myUser.getUsername());
            targetSchedule.setAllDay(true);
            targetSchedule.setPrivate(false);
            targetSchedule.setStartTime(dateForNew.atStartOfDay());
            targetSchedule.setEndTime(dateForNew.atTime(23,59,59));
            if (ownerContext instanceof share.Group) {
                targetSchedule.setGroupId(((share.Group) ownerContext).getId());
                isOwnerUserTypeForDialog = false;
            } else { // Userのはず
                isOwnerUserTypeForDialog = true;
            }
        } else {
            targetSchedule = scheduleToEdit;
            if (targetSchedule.getGroupId() != null && !targetSchedule.getGroupId().isEmpty()) {
                isOwnerUserTypeForDialog = false; // グループスケジュール
            } else {
                // 既存の個人スケジュールの場合、その作成者が自分かどうか
                isOwnerUserTypeForDialog = targetSchedule.getCreatedBy().equals(myUser.getUsername());
            }
        }

        AppointmentDialog dialog = new AppointmentDialog(frame, targetSchedule, isNew, isEditable, isOwnerUserTypeForDialog);
        dialog.setVisible(true);
        int result = dialog.getResult();

        if (result == AppointmentDialog.OPTION_SAVE) {
            share.Schedule savedSchedule = dialog.getSchedule(); // ダイアログから更新されたScheduleを取得
            System.out.println("[Calender] 保存ボタンクリック: " + savedSchedule.getTitle());
            // TODO: ステップ2-1: サーバーに ADD_SCHEDULE または UPDATE_SCHEDULE リクエストを送信
            // connector.sendMessage(...);
            // その後、サーバーから新しいUserDataを受信してupdateCalendar()を呼び出すか、
            // ローカルのcurrentUserDataを更新してupdateCalendar()を呼び出す。
        } else if (result == AppointmentDialog.OPTION_DELETE && !isNew) {
            System.out.println("[Calender] 削除ボタンクリック: " + targetSchedule.getTitle());
            // TODO: ステップ2-1: サーバーに DELETE_SCHEDULE リクエストを送信
            // connector.sendMessage(...);
        }
    }

    // AppointmentDialog は Calender クラスのネストクラスとして定義
    static class AppointmentDialog extends JDialog {
        // ... (前回の AppointmentDialog のコードをここにペースト)
        // ただし、いくつかの修正が必要になります。
        // - コンストラクタの引数 isOwnerUser を isForPersonalAppointment にリネームしました（意味が明確になるように）
        // - getSchedule() メソッド内の日付・時刻の扱いを再確認・修正しました。
        public static final int OPTION_SAVE = 1, OPTION_DELETE = 2, OPTION_CANCEL = 0;
        private int result = OPTION_CANCEL;
        private JTextField titleField;
        private JTextArea detailsArea;
        private JCheckBox privateCheckBox;
        private JCheckBox allDayCheckBox;
        private JSpinner startTimeSpinner;
        private JSpinner endTimeSpinner;
        private JLabel timeLabel;
        private share.Schedule currentScheduleData; // ダイアログが編集するScheduleデータ
        private boolean isDialogForPersonalAppointment; // このダイアログが個人予定を扱っているか

        public AppointmentDialog(Frame ownerFrame, share.Schedule scheduleForDialog, boolean isNew, boolean isEditable, boolean isForPersonalAppointment) {
            super(ownerFrame, true);
            // 渡されたscheduleオブジェクトを直接変更せず、コピーして編集する（キャンセル時に元に戻せるように）
            this.currentScheduleData = new share.Schedule(); // 空のオブジェクトを作成
            this.currentScheduleData.setId(scheduleForDialog.getId());
            this.currentScheduleData.setTitle(scheduleForDialog.getTitle());
            this.currentScheduleData.setDescription(scheduleForDialog.getDescription());
            this.currentScheduleData.setStartTime(scheduleForDialog.getStartTime());
            this.currentScheduleData.setEndTime(scheduleForDialog.getEndTime());
            this.currentScheduleData.setAllDay(scheduleForDialog.isAllDay());
            this.currentScheduleData.setGroupId(scheduleForDialog.getGroupId());
            this.currentScheduleData.setParticipants(scheduleForDialog.getParticipants() != null ? new ArrayList<>(scheduleForDialog.getParticipants()) : new ArrayList<>());
            this.currentScheduleData.setCreatedBy(scheduleForDialog.getCreatedBy());
            this.currentScheduleData.setPrivate(scheduleForDialog.isPrivate());
            
            this.isDialogForPersonalAppointment = isForPersonalAppointment;

            String dialogTitle = isNew ? "予定の新規作成" : (isEditable ? "予定の編集/削除" : "予定の詳細");
            setTitle(dialogTitle);

            titleField = new JTextField(this.currentScheduleData.getTitle(), 25);
            detailsArea = new JTextArea(this.currentScheduleData.getDescription(), 5, 25);
            detailsArea.setLineWrap(true);
            detailsArea.setWrapStyleWord(true);

            privateCheckBox = new JCheckBox("非公開の予定にする");
            privateCheckBox.setSelected(this.currentScheduleData.isPrivate());
            privateCheckBox.setVisible(this.isDialogForPersonalAppointment); // 個人予定の場合のみ表示

            allDayCheckBox = new JCheckBox("終日の予定");
            allDayCheckBox.setSelected(this.currentScheduleData.isAllDay());

            Date initStartTime = Date.from(this.currentScheduleData.getStartTime().atZone(ZoneId.systemDefault()).toInstant());
            Date initEndTime = Date.from(this.currentScheduleData.getEndTime().atZone(ZoneId.systemDefault()).toInstant());

            SpinnerDateModel startModel = new SpinnerDateModel(initStartTime, null, null, Calendar.MINUTE);
            startTimeSpinner = new JSpinner(startModel);
            startTimeSpinner.setEditor(new JSpinner.DateEditor(startTimeSpinner, "HH:mm"));

            SpinnerDateModel endModel = new SpinnerDateModel(initEndTime, null, null, Calendar.MINUTE);
            endTimeSpinner = new JSpinner(endModel);
            endTimeSpinner.setEditor(new JSpinner.DateEditor(endTimeSpinner, "HH:mm"));
            
            timeLabel = new JLabel("時間:");

            allDayCheckBox.addActionListener(e -> updateDateTimeFieldsVisibility());
            updateDateTimeFieldsVisibility(); // 初期表示

            JLabel ownerDisplayLabel = new JLabel();
            ownerDisplayLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            ownerDisplayLabel.setForeground(Color.GRAY);
            if (this.currentScheduleData.getGroupId() != null && !this.currentScheduleData.getGroupId().isEmpty()) {
                ownerDisplayLabel.setText("グループ予定 (ID: " + this.currentScheduleData.getGroupId() + ")");
            } else {
                ownerDisplayLabel.setText("個人予定 (作成者: " + this.currentScheduleData.getCreatedBy() + ")");
            }

            JPanel buttonPanelContainer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            if (isEditable) {
                JButton saveButton = new JButton("保存");
                saveButton.addActionListener(e -> { result = OPTION_SAVE; dispose(); });
                buttonPanelContainer.add(saveButton);
                if (!isNew) {
                    JButton deleteButton = new JButton("削除");
                    deleteButton.addActionListener(e -> {
                        if (JOptionPane.showConfirmDialog(this, "この予定を削除しますか？", "確認", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                            result = OPTION_DELETE; dispose();
                        }
                    });
                    buttonPanelContainer.add(deleteButton);
                }
                JButton cancelButton = new JButton("キャンセル");
                cancelButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(cancelButton);
            } else {
                JButton closeButton = new JButton("閉じる");
                closeButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(closeButton);
                // 閲覧モードでは編集不可に
                titleField.setEditable(false); detailsArea.setEditable(false);
                privateCheckBox.setEnabled(false); allDayCheckBox.setEnabled(false);
                startTimeSpinner.setEnabled(false); endTimeSpinner.setEnabled(false);
                titleField.setFocusable(false); detailsArea.setFocusable(false); // カーソル非表示
            }

            // レイアウト (GridBagLayoutを使用)
            JPanel fieldsPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(3,3,3,3); // 少し余白を
            gbc.anchor = GridBagConstraints.WEST;

            gbc.gridx = 0; gbc.gridy = 0; fieldsPanel.add(new JLabel("タイトル:"), gbc);
            gbc.gridx = 1; gbc.gridy = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(titleField, gbc);

            gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
            fieldsPanel.add(new JLabel("詳細:"), gbc);
            gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
            fieldsPanel.add(new JScrollPane(detailsArea), gbc);
            
            gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth=2; gbc.fill = GridBagConstraints.NONE; gbc.weighty = 0;
            fieldsPanel.add(allDayCheckBox, gbc);

            JPanel timeInnerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            timeInnerPanel.add(startTimeSpinner);
            timeInnerPanel.add(Box.createHorizontalStrut(5));
            timeInnerPanel.add(new JLabel("～"));
            timeInnerPanel.add(Box.createHorizontalStrut(5));
            timeInnerPanel.add(endTimeSpinner);

            gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth=1;
            fieldsPanel.add(timeLabel, gbc);
            gbc.gridx = 1; gbc.gridy = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
            fieldsPanel.add(timeInnerPanel, gbc);

            if (this.isDialogForPersonalAppointment) {
                 gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.NONE;
                 fieldsPanel.add(privateCheckBox, gbc);
            }

            JPanel mainContentPanel = new JPanel(new BorderLayout(5,5));
            mainContentPanel.setBorder(new EmptyBorder(10,10,10,10));
            mainContentPanel.add(fieldsPanel, BorderLayout.CENTER);

            JPanel southPanel = new JPanel(new BorderLayout());
            southPanel.setBorder(new EmptyBorder(5,0,0,0));
            southPanel.add(ownerDisplayLabel, BorderLayout.WEST);
            southPanel.add(buttonPanelContainer, BorderLayout.EAST);
            
            getContentPane().add(mainContentPanel, BorderLayout.CENTER);
            getContentPane().add(southPanel, BorderLayout.SOUTH);
            pack(); // pack() を呼ぶことで適切なサイズになる
            setMinimumSize(getPreferredSize()); // 最小サイズを設定
            setLocationRelativeTo(ownerFrame);
        }

        private void updateDateTimeFieldsVisibility() {
            boolean isAllDay = allDayCheckBox.isSelected();
            startTimeSpinner.setVisible(!isAllDay);
            endTimeSpinner.setVisible(!isAllDay);
            timeLabel.setVisible(!isAllDay);
        }

        public int getResult() { return result; }

        public share.Schedule getSchedule() {
            currentScheduleData.setTitle(titleField.getText());
            currentScheduleData.setDescription(detailsArea.getText());
            if(isDialogForPersonalAppointment) { // 個人予定の場合のみ非公開設定を反映
                currentScheduleData.setPrivate(privateCheckBox.isSelected());
            } else {
                currentScheduleData.setPrivate(false); // グループ予定は常に公開
            }
            currentScheduleData.setAllDay(allDayCheckBox.isSelected());

            // 日付部分は元のスケジュールの日付を維持 (JSpinnerは時刻のみ変更)
            LocalDate scheduleDate = currentScheduleData.getStartTime().toLocalDate();

            if (!currentScheduleData.isAllDay()) {
                Date startTimeUtilDate = (Date) startTimeSpinner.getValue();
                Date endTimeUtilDate = (Date) endTimeSpinner.getValue();
                // DateからLocalTimeへ変換
                LocalTime localStartTime = LocalDateTime.ofInstant(startTimeUtilDate.toInstant(), ZoneId.systemDefault()).toLocalTime();
                LocalTime localEndTime = LocalDateTime.ofInstant(endTimeUtilDate.toInstant(), ZoneId.systemDefault()).toLocalTime();
                
                currentScheduleData.setStartTime(LocalDateTime.of(scheduleDate, localStartTime));
                currentScheduleData.setEndTime(LocalDateTime.of(scheduleDate, localEndTime));
            } else {
                 currentScheduleData.setStartTime(scheduleDate.atStartOfDay());
                 currentScheduleData.setEndTime(scheduleDate.atTime(23,59,59)); // 終日の終了時刻
            }
            return currentScheduleData;
        }
    }
}