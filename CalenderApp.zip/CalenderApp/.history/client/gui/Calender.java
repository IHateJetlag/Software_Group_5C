package client.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter; // ChatMessageのタイムスタンプ表示用
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import java.util.Comparator;
import java.util.Date;
import java.util.Calendar;
import java.util.stream.Collectors;
import java.time.LocalTime;

import share.User;
import share.Group;
import share.Schedule;
import share.ChatMessage;
import share.UserData;

import client.Connector;

public class Calender {
    private static final int CALENDAR_ROWS = 6;
    private static final int CALENDAR_COLS = 7;
    private static final String MY_PAGE_ID = "MY_PAGE_VIEW";

    private JFrame frame;
    private final List<JPanel> datePanels = new ArrayList<>();
    private JPanel monthDisplayPanel;
    private JPanel centerCardPanel;
    private CardLayout centerCardLayout;
    private JPanel sidebarPanel;

    private share.User myUser;
    private Connector connector;
    private share.UserData currentUserData; // ログイン時にサーバーから受け取る

    // 表示用データキャッシュ (updateCalendarViewでcurrentUserDataから再構築)
    private final Map<LocalDate, List<share.Schedule>> displayedSchedules = new HashMap<>();
    private final List<share.Group> myGroups = new ArrayList<>();
    private share.Group currentSelectedGroup;

    private LocalDate currentDateForCalendar;
    private DateTimeFormatter chatTimestampFormatter = DateTimeFormatter.ofPattern("MM/dd HH:mm");


    public Calender(share.User loggedInUser, Connector connector, share.UserData initialUserData) {
        this.myUser = loggedInUser;
        this.connector = connector;
        this.currentUserData = initialUserData; // UserDataを保持

        this.myGroups.clear();
        if (this.currentUserData != null && this.currentUserData.getGroups() != null) {
            System.out.println("[Calender Constructor] UserDataからグループをロードします。 Group数: " + this.currentUserData.getGroups().size()); // ★★★ログ追加
            for (share.Group serverGroup : this.currentUserData.getGroups()) {
                System.out.println("  -> 追加試行: " + serverGroup.getName() + " (ID: " + serverGroup.getId() + ")"); // ★★★ログ追加
                this.myGroups.add(serverGroup); // ここで直接追加
            }
            System.out.println("[Calender Constructor] ロード後のmyGroupsサイズ: " + this.myGroups.size()); // ★★★ログ追加
            for(share.Group g : this.myGroups) {
                System.out.println("  - myGroups内容: " + g.getName() + " (ID: " + g.getId() + ")"); // ★★★ログ追加
            }
        } else {
            System.out.println("[Calender Constructor] UserDataまたはGroupsがnullです。"); // ★★★ログ追加
        }
    }

    public void createAndShowGUI() {
        currentDateForCalendar = LocalDate.now();

        frame = new JFrame("カレンダー共有アプリ - " + (myUser != null ? myUser.getUsername() : "ゲスト"));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 800);

        JPanel mainPanel = createMainLayout();
        frame.add(mainPanel);

        updateHeaderDateDisplay();
        updateCalendarView(); // ★★★ 最初にカレンダーを描画

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        // TODO: ConnectorにCalender画面用のMessageListenerを設定し、
        // サーバーからのデータ更新通知 (USER_DATA, CHAT_MESSAGEなど) を受け取って
        // GUIを動的に更新する処理を実装する (フェーズ3以降)
        // connector.setMessageListener(new Connector.MessageListener() { ... Calender用の処理 ... });
    }

    private JPanel createMainLayout() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        sidebarPanel = createSidebarPanel();
        centerCardLayout = new CardLayout();
        centerCardPanel = new JPanel(centerCardLayout);

        centerCardPanel.add(createMyPagePanel(), MY_PAGE_ID);
        for (share.Group group : myGroups) {
            centerCardPanel.add(createChatPanel(group), group.getId());
        }

        JPanel calendarDisplayPanel = createCalendarDisplayPanel();

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.15; gbc.gridheight = 2; mainPanel.add(sidebarPanel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.35; gbc.gridheight = 1; mainPanel.add(centerCardPanel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 0.35; gbc.weighty = 0.05; gbc.fill = GridBagConstraints.HORIZONTAL; // フッターの高さ固定
        mainPanel.add(createFooterActionPanel(), gbc);
        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0.5; gbc.gridheight = 2; gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0; // 元に戻す
        mainPanel.add(calendarDisplayPanel, gbc);

        centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
        currentSelectedGroup = null;
        return mainPanel;
    }

    private JPanel createSidebarPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("ナビゲーション"));
        panel.setBackground(new Color(230, 240, 255)); // 少し薄い青

        String myUsername = (myUser != null && myUser.getUsername() != null) ? myUser.getUsername() : "User";
        char myInitial = myUsername.isEmpty() ? 'U' : myUsername.charAt(0);
        panel.add(createGroupIcon(MY_PAGE_ID, "マイページ (" + myUsername + ")", myInitial, true));
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(new JSeparator());
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel groupListLabel = new JLabel("所属グループ");
        groupListLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        groupListLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(groupListLabel);
        panel.add(Box.createRigidArea(new Dimension(0,5)));

        if (myGroups.isEmpty()) {
            JLabel noGroupLabel = new JLabel(" (なし) ");
            noGroupLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(noGroupLabel);
        } else {
            for (share.Group group : myGroups) {
                char groupInitial = group.getName().isEmpty() ? 'G' : group.getName().charAt(0);
                panel.add(createGroupIcon(group.getId(), group.getName(), groupInitial, false));
            }
        }
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    private Component createGroupIcon(String id, String tooltip, char iconChar, boolean isMyPageIcon) {
        JButton iconButton = new JButton(String.valueOf(iconChar));
        iconButton.setToolTipText(tooltip);
        Dimension iconSize = new Dimension(60, 60);
        iconButton.setPreferredSize(iconSize);
        iconButton.setMinimumSize(iconSize);
        iconButton.setMaximumSize(new Dimension(Short.MAX_VALUE, iconSize.height));
        iconButton.setFont(new Font("SansSerif", Font.BOLD, 28));
        iconButton.setForeground(Color.WHITE);
        iconButton.setFocusPainted(false);
        iconButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        iconButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        iconButton.setContentAreaFilled(false);
        iconButton.setBorderPainted(false);
        iconButton.setName("ICON_BTN_" + id);

        iconButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String previousSelectedGroupId = (currentSelectedGroup != null) ? currentSelectedGroup.getId() : MY_PAGE_ID;
                if (id.equals(MY_PAGE_ID)) {
                    currentSelectedGroup = null;
                    centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
                } else {
                    currentSelectedGroup = findGroupByIdFromLocalList(id); // myGroupsから検索
                    if (currentSelectedGroup != null) {
                        centerCardLayout.show(centerCardPanel, id);
                        loadChatHistoryForGroup(currentSelectedGroup);
                    } else {
                        System.err.println("Error: Group with ID " + id + " not found in local list.");
                        // フォールバックでマイページ表示など
                        currentSelectedGroup = null;
                        centerCardLayout.show(centerCardPanel, MY_PAGE_ID);
                    }
                }
                // サイドバーの選択状態更新
                if (!id.equals(previousSelectedGroupId)) { // 選択が変わった場合のみ更新
                    updateSidebarSelectionHighlight();
                }
                updateCalendarView(); // カレンダーの表示内容を更新
            }
        });

        JPanel iconWrapper = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g); // JPanelのデフォルト描画
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean isSelected = id.equals(MY_PAGE_ID) ? currentSelectedGroup == null : (currentSelectedGroup != null && id.equals(currentSelectedGroup.getId()));
                
                Color baseColor = isMyPageIcon ? new Color(70, 130, 180) : new Color(60, 179, 113); // SteelBlue, MediumSeaGreen
                g2.setColor(isSelected ? baseColor.darker() : baseColor);
                g2.fillOval(5, 5, getWidth() - 10, getHeight() - 10);

                if (isSelected) {
                    g2.setColor(Color.ORANGE); // 選択時のハイライト枠
                    g2.setStroke(new BasicStroke(3));
                    g2.drawOval(3, 3, getWidth() - 7, getHeight() - 7);
                }
                g2.dispose();
            }
        };
        iconWrapper.add(iconButton, BorderLayout.CENTER);
        iconWrapper.setOpaque(false);
        iconWrapper.setBorder(new EmptyBorder(5,10,5,10));
        iconWrapper.setMaximumSize(new Dimension(Short.MAX_VALUE, iconSize.height + 10));
        return iconWrapper;
    }
    
    private void updateSidebarSelectionHighlight() {
        for(Component comp : sidebarPanel.getComponents()){
            if(comp instanceof JPanel && ((JPanel)comp).getComponent(0) instanceof JButton) { // iconWrapperを想定
                JButton btn = (JButton)((JPanel)comp).getComponent(0);
                String btnId = btn.getName().substring("ICON_BTN_".length());
                boolean isSelected = btnId.equals(MY_PAGE_ID) ? currentSelectedGroup == null : (currentSelectedGroup != null && btnId.equals(currentSelectedGroup.getId()));
                 // paintComponent内で選択状態を見てるので、repaintだけでOK
            }
        }
        sidebarPanel.repaint(); // paintComponentを再呼び出し
    }


    private JPanel createMyPagePanel() {
        // ... (前回のコードとほぼ同じ、表示情報をmyUserから取得) ...
        JPanel myPagePanel = new JPanel(new BorderLayout(10,10));
        myPagePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        myPagePanel.setBackground(Color.WHITE);
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);
        JLabel nameLabel = new JLabel("ようこそ、" + (myUser != null ? myUser.getUsername() : "ゲスト") + " さん");
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        infoPanel.add(nameLabel);
        myPagePanel.add(infoPanel, BorderLayout.NORTH);
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        actionPanel.setOpaque(false);
        JButton createGroupButton = new JButton("新しいグループを作成");
        createGroupButton.addActionListener(e -> showCreateGroupDialog());
        actionPanel.add(createGroupButton);
        myPagePanel.add(actionPanel, BorderLayout.CENTER);
        return myPagePanel;
    }

    private void showCreateGroupDialog() {
        // TODO: ステップ2-2: サーバーに "CREATE_GROUP_WITH_MEMBERS" リクエスト
        JOptionPane.showMessageDialog(frame, "グループ作成 (未実装)", "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createChatPanel(share.Group group) {
        // ... (前回のコードとほぼ同じ、引数が share.Group) ...
        JPanel chatPanel = new JPanel(new BorderLayout(0, 10));
        chatPanel.setBorder(new EmptyBorder(10,10,10,10));
        chatPanel.setName("CHAT_PANEL_" + group.getId());
        JPanel headerPanel = new JPanel(new BorderLayout());
        JLabel groupTitleLabel = new JLabel(group.getName(), SwingConstants.CENTER);
        groupTitleLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        JButton membersButton = new JButton("メンバー (" + (group.getMembers() != null ? group.getMembers().size() : 0) + ")");
        membersButton.addActionListener(e -> showGroupMembersDialog(group));
        headerPanel.add(groupTitleLabel, BorderLayout.CENTER);
        headerPanel.add(membersButton, BorderLayout.EAST);
        chatPanel.add(headerPanel, BorderLayout.NORTH);
        JTextArea messageDisplayArea = new JTextArea();
        messageDisplayArea.setEditable(false);
        messageDisplayArea.setLineWrap(true);
        messageDisplayArea.setWrapStyleWord(true);
        messageDisplayArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        messageDisplayArea.setName("ChatDisplayArea_" + group.getId());
        JScrollPane scrollPane = new JScrollPane(messageDisplayArea);
        chatPanel.add(scrollPane, BorderLayout.CENTER);
        JPanel inputSouthPanel = new JPanel(new BorderLayout(5,5));
        JTextField messageInputField = new JTextField();
        JButton sendMessageButton = new JButton("送信");
        sendMessageButton.addActionListener(e -> {
            String messageText = messageInputField.getText().trim();
            if (!messageText.isEmpty() && connector != null && myUser != null && currentSelectedGroup != null) { // currentSelectedGroup を使う
                System.out.println("[Chat] 送信試行: GroupID=" + currentSelectedGroup.getId() + ", User=" + myUser.getUsername() + ", Msg=" + messageText);
                // TODO: ステップ3-1: connector.sendMessage(new share.ServerMessage("SEND_CHAT", ...));
                messageInputField.setText("");
            }
        });
        messageInputField.addActionListener(sendMessageButton.getActionListeners()[0]);
        inputSouthPanel.add(messageInputField, BorderLayout.CENTER);
        inputSouthPanel.add(sendMessageButton, BorderLayout.EAST);
        chatPanel.add(inputSouthPanel, BorderLayout.SOUTH);
        return chatPanel;
    }
    
    private void loadChatHistoryForGroup(share.Group group) {
        JTextArea displayArea = findChatDisplayAreaForGroup(group.getId());
        if (displayArea == null) return;
        displayArea.setText("");
        if (currentUserData != null && currentUserData.getChats() != null) {
            currentUserData.getChats().stream()
                .filter(cm -> group.getId().equals(cm.getGroupId()))
                .sorted(Comparator.comparing(share.ChatMessage::getTimestamp))
                .forEach(chatMessage -> appendChatMessageToUI(chatMessage, displayArea));
        }
        displayArea.setCaretPosition(displayArea.getDocument().getLength());
    }
    
    public void appendChatMessageToUI(share.ChatMessage message, String groupId) { // publicにしてConnectorから呼べるようにする可能性
        if (currentSelectedGroup != null && currentSelectedGroup.getId().equals(groupId)) {
            JTextArea displayArea = findChatDisplayAreaForGroup(groupId);
            if (displayArea != null) {
                appendChatMessageToUI(message, displayArea);
                displayArea.setCaretPosition(displayArea.getDocument().getLength());
            }
        }
        // TODO: 未選択グループへの新着通知処理
    }

    private void appendChatMessageToUI(share.ChatMessage message, JTextArea displayArea) {
        String prefix = (myUser != null && message.getSender().equals(myUser.getUsername())) ? "[自分] " : "[" + message.getSender() + "] ";
        displayArea.append(prefix + message.getMessage() + "  (" + formatDateTime(message.getTimestamp()) + ")\n");
    }
    
    private String formatDateTime(LocalDateTime ldt){
        if(ldt == null) return "";
        return ldt.format(chatTimestampFormatter);
    }

    private JTextArea findChatDisplayAreaForGroup(String groupId) {
        // ... (前回のコードと同じ) ...
        String panelName = "CHAT_PANEL_" + groupId;
        for (Component comp : centerCardPanel.getComponents()) {
            if (panelName.equals(comp.getName()) && comp instanceof JPanel) {
                JPanel chatPanel = (JPanel) comp;
                for(Component chatPanelComp : chatPanel.getComponents()){
                    if(chatPanelComp instanceof JScrollPane){
                        JScrollPane scrollPane = (JScrollPane) chatPanelComp;
                        Component view = scrollPane.getViewport().getView();
                        if(view instanceof JTextArea && ("ChatDisplayArea_" + groupId).equals(view.getName())){
                            return (JTextArea) view;
                        }
                    }
                }
            }
        }
        return null;
    }

    private void showGroupMembersDialog(share.Group group) {
        // TODO: ステップ2-2
        JOptionPane.showMessageDialog(frame, "グループメンバー管理 (未実装)\nグループ: " + group.getName(), "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createCalendarDisplayPanel() {
        JPanel calendarContainer = new JPanel(new BorderLayout(0, 10));
        calendarContainer.setBorder(new EmptyBorder(10, 10, 10, 10));
        calendarContainer.add(createCalendarHeaderPanel(), BorderLayout.NORTH);
        calendarContainer.add(createDateGridPanel(), BorderLayout.CENTER);
        return calendarContainer;
    }

    private JPanel createCalendarHeaderPanel() {
        // ... (前回のコードと同じ) ...
        JPanel panel = new JPanel(new BorderLayout());
        JButton prevButton = new JButton("< 前月");
        prevButton.addActionListener(e -> { currentDateForCalendar = currentDateForCalendar.minusMonths(1); updateHeaderDateDisplay(); updateCalendarView(); });
        JButton nextButton = new JButton("次月 >");
        nextButton.addActionListener(e -> { currentDateForCalendar = currentDateForCalendar.plusMonths(1); updateHeaderDateDisplay(); updateCalendarView(); });
        monthDisplayPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        panel.add(prevButton, BorderLayout.WEST); panel.add(monthDisplayPanel, BorderLayout.CENTER); panel.add(nextButton, BorderLayout.EAST);
        return panel;
    }

    private void updateHeaderDateDisplay() {
        monthDisplayPanel.removeAll();
        JLabel label = new JLabel(String.format("%d年 %d月", currentDateForCalendar.getYear(), currentDateForCalendar.getMonthValue()));
        label.setFont(new Font("SansSerif", Font.BOLD, 18));
        monthDisplayPanel.add(label);
        monthDisplayPanel.revalidate(); monthDisplayPanel.repaint();
    }

    private Component createDateGridPanel() {
        // ... (前回のコードと同じ) ...
        JPanel gridOuterContainer = new JPanel(new BorderLayout());
        JPanel dayOfWeekPanel = new JPanel(new GridLayout(1, CALENDAR_COLS, 2, 2));
        String[] days = {"日", "月", "火", "水", "木", "金", "土"};
        for (String day : days) {
            JLabel dayLabel = new JLabel(day, JLabel.CENTER); dayLabel.setOpaque(true); dayLabel.setBackground(new Color(210,210,210)); dayLabel.setBorder(BorderFactory.createEtchedBorder());
            if (day.equals("日")) dayLabel.setForeground(Color.RED); if (day.equals("土")) dayLabel.setForeground(Color.BLUE);
            dayOfWeekPanel.add(dayLabel);
        }
        JPanel dateGridPanel = new JPanel(new GridLayout(CALENDAR_ROWS, CALENDAR_COLS, 2, 2));
        dateGridPanel.setBorder(BorderFactory.createEtchedBorder()); datePanels.clear();
        for (int i = 0; i < CALENDAR_ROWS * CALENDAR_COLS; i++) {
            JPanel dateCell = new JPanel(new BorderLayout(2,2)); dateCell.setBorder(BorderFactory.createEtchedBorder()); dateCell.setBackground(Color.WHITE);
            dateGridPanel.add(dateCell); datePanels.add(dateCell);
        }
        gridOuterContainer.add(dayOfWeekPanel, BorderLayout.NORTH); gridOuterContainer.add(dateGridPanel, BorderLayout.CENTER);
        return gridOuterContainer;
    }
    
    private JPanel createFooterActionPanel() {
        // 簡易予定追加フッターは、より洗練されたUIを検討するまで一旦コメントアウト
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        // ... (フッター内容は現状空)
        return footerPanel;
    }

    // ★★★ カレンダー表示更新のメインロジック ★★★
    private void updateCalendarView() {
        if (myUser == null || currentUserData == null) { // 必要なデータがなければ何もしない
            System.err.println("[Calender] updateCalendarView skipped: myUser or currentUserData is null.");
            return;
        }
        System.out.println("[Calender] カレンダー表示更新開始: " + currentDateForCalendar.toString());

        // 1. 表示用スケジュールマップ (displayedSchedules) を currentUserData から再構築
        displayedSchedules.clear();
        if (currentUserData.getSchedules() != null) {
            for (share.Schedule schedule : currentUserData.getSchedules()) {
                if (schedule.getStartTime() == null) continue; // 開始時間がないスケジュールはスキップ

                LocalDate scheduleDate = schedule.getStartTime().toLocalDate();
                boolean shouldDisplayThisSchedule = false;

                // 表示フィルタリングロジック (No.3, No.4 の確定事項を反映)
                String scheduleOwnerUsername = schedule.getCreatedBy();
                boolean isMyOwnSchedule = myUser.getUsername().equalsIgnoreCase(scheduleOwnerUsername);
                boolean isGroupSchedule = schedule.getGroupId() != null && !schedule.getGroupId().isEmpty();

                if (currentSelectedGroup == null) { // マイページ表示時
                    if (isMyOwnSchedule) { // 自分の個人予定
                        shouldDisplayThisSchedule = true;
                    } else if (isGroupSchedule) { // グループ予定
                        // 自分が所属するグループの予定か確認
                        if (myGroups.stream().anyMatch(g -> g.getId().equals(schedule.getGroupId()))) {
                            shouldDisplayThisSchedule = true;
                        }
                    }
                } else { // 特定のグループページ表示時
                    if (isMyOwnSchedule) { // 自分の個人予定 (グループページでも表示)
                        shouldDisplayThisSchedule = true;
                    } else if (isGroupSchedule && schedule.getGroupId().equals(currentSelectedGroup.getId())) { // 現在選択中グループの共有予定
                        shouldDisplayThisSchedule = true;
                    } else if (!isGroupSchedule) { // 他人の個人予定
                        // その人が現在選択中グループのメンバーであるか確認
                        if (currentSelectedGroup.getMembers().stream().anyMatch(memberUsername -> memberUsername.equalsIgnoreCase(scheduleOwnerUsername))) {
                            shouldDisplayThisSchedule = true;
                        }
                    }
                }

                if (shouldDisplayThisSchedule) {
                    displayedSchedules.computeIfAbsent(scheduleDate, k -> new ArrayList<>()).add(schedule);
                }
            }
        }
        System.out.println("[Calender] 表示対象スケジュール数 (after filter): " + displayedSchedules.values().stream().mapToInt(List::size).sum());


        // 2. カレンダーの日付セルを更新
        YearMonth yearMonth = YearMonth.from(currentDateForCalendar);
        int daysInMonth = yearMonth.lengthOfMonth();
        LocalDate firstOfMonth = currentDateForCalendar.withDayOfMonth(1);
        int startDayOfWeek = firstOfMonth.getDayOfWeek().getValue(); // MON=1, SUN=7
        if (startDayOfWeek == 7) startDayOfWeek = 0; // 日曜始まりのインデックス (0=Sun, 1=Mon, ...)

        for (int i = 0; i < datePanels.size(); i++) {
            JPanel dateCell = datePanels.get(i);
            dateCell.removeAll(); // 既存の内容をクリア
            dateCell.setBackground(Color.WHITE); // デフォルト背景色
            dateCell.setName(null);
            int dayOfMonth = i - startDayOfWeek + 1;

            if (dayOfMonth > 0 && dayOfMonth <= daysInMonth) {
                LocalDate cellDate = currentDateForCalendar.withDayOfMonth(dayOfMonth);
                buildDateCellUIWithSchedules(dateCell, cellDate); // UI構築と予定描画
                if (cellDate.equals(LocalDate.now())) {
                    dateCell.setBackground(new Color(225, 235, 255)); // 今日の日付を少し強調
                }
            } else {
                // 当月でない日付セルは少し暗くするなど（任意）
                dateCell.setBackground(new Color(245, 245, 245));
            }
            dateCell.revalidate();
            dateCell.repaint();
        }
        System.out.println("[Calender] カレンダー表示更新完了。");
    }

    private void buildDateCellUIWithSchedules(JPanel dateCell, LocalDate cellDate) {
        dateCell.setName(cellDate.toString());
        JLabel dateLabel = new JLabel(String.valueOf(cellDate.getDayOfMonth()), SwingConstants.RIGHT);
        dateLabel.setBorder(new EmptyBorder(2, 0, 2, 4));
        dateCell.add(dateLabel, BorderLayout.NORTH);

        JPanel appointmentContainer = new JPanel();
        appointmentContainer.setLayout(new BoxLayout(appointmentContainer, BoxLayout.Y_AXIS));
        appointmentContainer.setOpaque(false);

        List<share.Schedule> daySchedules = displayedSchedules.getOrDefault(cellDate, new ArrayList<>());
        // 終日の予定を先に、時間指定の予定を後に表示（任意）
        daySchedules.sort(Comparator.comparing(share.Schedule::isAllDay, Comparator.reverseOrder())
                                    .thenComparing(s -> s.isAllDay() ? null : s.getStartTime(), Comparator.nullsLast(Comparator.naturalOrder()))
                                    .thenComparing(share.Schedule::getTitle));


        for (share.Schedule schedule_loopVar : daySchedules) {
            String displayTitle = schedule_loopVar.getTitle();
            if (!schedule_loopVar.isAllDay() && schedule_loopVar.getStartTime() != null) { // 時間指定があり、開始時刻がある場合
                 displayTitle = schedule_loopVar.getStartTime().format(DateTimeFormatter.ofPattern("HH:mm")) + " " + displayTitle;
            }

            boolean isMyOwnSchedule_loopVar = myUser.getUsername().equalsIgnoreCase(schedule_loopVar.getCreatedBy());
            boolean isGroupSchedule_loopVar = schedule_loopVar.getGroupId() != null && !schedule_loopVar.getGroupId().isEmpty();
            boolean isPrivateAndNotMineInGroupView_loopVar = !isMyOwnSchedule_loopVar && !isGroupSchedule_loopVar && schedule_loopVar.isPrivate() && currentSelectedGroup != null;

            if (isPrivateAndNotMineInGroupView_loopVar) {
                displayTitle = "（非公開の予定）";
            }

            JButton appButton = new JButton("<html><body style='text-align:left; width:80px;'>" + displayTitle + "</body></html>");
            appButton.setHorizontalAlignment(SwingConstants.LEFT);
            appButton.setMargin(new Insets(1,3,1,3));
            appButton.setFont(new Font("SansSerif", Font.PLAIN, 10));
            appButton.setOpaque(true);

            if (isMyOwnSchedule_loopVar) {
                appButton.setBackground(new Color(135, 206, 250));
            } else if (isGroupSchedule_loopVar) {
                appButton.setBackground(new Color(144, 238, 144));
            } else {
                appButton.setBackground(new Color(220, 220, 220));
            }
            
            boolean isEditable_loopVar = isMyOwnSchedule_loopVar || isGroupSchedule_loopVar; // 自分かグループの予定なら編集可

            if (isPrivateAndNotMineInGroupView_loopVar) {
                appButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                appButton.setEnabled(false); // クリックできないように
            } else {
                final share.Schedule currentScheduleForListener = schedule_loopVar;
                final Object currentOwnerContextForListener; // ダイアログに渡す所有者情報
                if (isMyOwnSchedule_loopVar) {
                    currentOwnerContextForListener = myUser;
                } else if (isGroupSchedule_loopVar) {
                    currentOwnerContextForListener = findGroupByIdFromLocalList(schedule_loopVar.getGroupId());
                } else {
                    // 他人の個人予定の場合、正確なUserオブジェクトは現状作れない
                    currentOwnerContextForListener = new share.User(schedule_loopVar.getCreatedBy(), ""); // 名前だけのダミー
                }
                final boolean finalIsEditable = isEditable_loopVar; // 事実上のfinal
                final LocalDate finalCellDate = cellDate;

                appButton.addActionListener(e -> showAppointmentDialog(
                    finalCellDate,
                    currentScheduleForListener,
                    currentOwnerContextForListener,
                    finalIsEditable
                ));
                appButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            appointmentContainer.add(appButton);
            appointmentContainer.add(Box.createRigidArea(new Dimension(0,1)));
        }
        JScrollPane appointmentScrollPane = new JScrollPane(appointmentContainer);
        appointmentScrollPane.setBorder(null);
        appointmentScrollPane.setOpaque(false);
        appointmentScrollPane.getViewport().setOpaque(false);
        dateCell.add(appointmentScrollPane, BorderLayout.CENTER);

        JPanel addBtnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0,0));
        addBtnPanel.setOpaque(false);
        JButton addButton = new JButton("+");
        addButton.setMargin(new Insets(0,2,0,2));
        addButton.setFont(new Font("SansSerif", Font.PLAIN, 10));
        addButton.setFocusable(false);
        final LocalDate finalCellDateForAdd = cellDate;
        addButton.addActionListener(e -> {
            Object ownerCtx = (currentSelectedGroup != null) ? (Object)currentSelectedGroup : (Object)myUser;
            showAppointmentDialog(finalCellDateForAdd, null, ownerCtx, true);
        });
        addBtnPanel.add(addButton);
        dateCell.add(addBtnPanel, BorderLayout.SOUTH);
    }
    
    private share.Group findGroupByIdFromLocalList(String id) { // ローカルのmyGroupsから検索
        if (id == null) return null;
        return myGroups.stream().filter(g -> id.equals(g.getId())).findFirst().orElse(null);
    }


    private void handleAddScheduleFromFooter(JTextField monthField, JTextField dayField, JTextField titleField) {
        // TODO: ステップ2-1
        JOptionPane.showMessageDialog(frame, "フッターからの簡易予定追加 (未実装)", "TODO", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAppointmentDialog(LocalDate dateForNew, share.Schedule scheduleToEdit, Object ownerContext, boolean isEditable) {
        boolean isNew = (scheduleToEdit == null);
        share.Schedule targetSchedule;
        boolean isPersonalAppointmentForDialog;

        if (isNew) {
            targetSchedule = new share.Schedule();
            targetSchedule.setCreatedBy(myUser.getUsername()); // 作成者は常にログインユーザー
            targetSchedule.setAllDay(true); // 新規はデフォルト終日
            targetSchedule.setPrivate(false); // デフォルト公開
            targetSchedule.setStartTime(dateForNew.atStartOfDay());
            targetSchedule.setEndTime(dateForNew.atTime(23,59,59));
            if (ownerContext instanceof share.Group) {
                targetSchedule.setGroupId(((share.Group) ownerContext).getId());
                isPersonalAppointmentForDialog = false; // グループの新規予定
            } else { // ownerContext is myUser
                isPersonalAppointmentForDialog = true;  // 個人の新規予定
            }
        } else {
            targetSchedule = scheduleToEdit; // 既存の予定を編集
            // この予定が個人予定かグループ予定かを判断
            if (targetSchedule.getGroupId() != null && !targetSchedule.getGroupId().isEmpty()) {
                isPersonalAppointmentForDialog = false; // グループ予定
            } else {
                // 個人予定の場合、それが自分のものか他人のものかでisEditableが決まるが、
                // isPersonalAppointmentForDialog は「個人予定であるか」だけを示す
                isPersonalAppointmentForDialog = true;
            }
        }
        
        AppointmentDialog dialog = new AppointmentDialog(frame, targetSchedule, isNew, isEditable, isPersonalAppointmentForDialog);
        dialog.setVisible(true);
        int result = dialog.getResult();

        if (result == AppointmentDialog.OPTION_SAVE) {
            share.Schedule savedSchedule = dialog.getSchedule();
            System.out.println("[Calender] " + (isNew ? "新規" : "更新") + "予定保存 (サーバー送信未実装): " + savedSchedule.getTitle());
            // TODO: ステップ2-1: サーバーに ADD_SCHEDULE または UPDATE_SCHEDULE リクエストを送信
            // connector.sendMessage(...);
            // その後、サーバーから新しいUserDataを受信してUIを更新する (例: connector.requestUserData();)
        } else if (result == AppointmentDialog.OPTION_DELETE && !isNew) {
            System.out.println("[Calender] 予定削除 (サーバー送信未実装): " + targetSchedule.getTitle());
            // TODO: ステップ2-1: サーバーに DELETE_SCHEDULE リクエストを送信
            // connector.sendMessage(...);
        }
    }

    // (AppointmentDialogのコードは前回のものをそのままここにペースト)
    static class AppointmentDialog extends JDialog {
        public static final int OPTION_SAVE = 1, OPTION_DELETE = 2, OPTION_CANCEL = 0;
        private int result = OPTION_CANCEL;
        private JTextField titleField;
        private JTextArea detailsArea;
        private JCheckBox privateCheckBox;
        private JCheckBox allDayCheckBox;
        private JSpinner startTimeSpinner;
        private JSpinner endTimeSpinner;
        private JLabel timeLabel;
        private share.Schedule currentScheduleData;
        private boolean isDialogForPersonalAppointment;

        public AppointmentDialog(Frame ownerFrame, share.Schedule scheduleForDialog, boolean isNew, boolean isEditable, boolean isForPersonalAppointment) {
            super(ownerFrame, true);
            this.currentScheduleData = new share.Schedule();
            this.currentScheduleData.setId(scheduleForDialog.getId());
            this.currentScheduleData.setTitle(scheduleForDialog.getTitle());
            this.currentScheduleData.setDescription(scheduleForDialog.getDescription());
            this.currentScheduleData.setStartTime(scheduleForDialog.getStartTime());
            this.currentScheduleData.setEndTime(scheduleForDialog.getEndTime());
            this.currentScheduleData.setAllDay(scheduleForDialog.isAllDay());
            this.currentScheduleData.setGroupId(scheduleForDialog.getGroupId());
            this.currentScheduleData.setParticipants(scheduleForDialog.getParticipants() != null ? new ArrayList<>(scheduleForDialog.getParticipants()) : new ArrayList<>());
            this.currentScheduleData.setCreatedBy(scheduleForDialog.getCreatedBy());
            this.currentScheduleData.setPrivate(scheduleForDialog.isPrivate());
            
            this.isDialogForPersonalAppointment = isForPersonalAppointment;

            String dialogTitle = isNew ? "予定の新規作成" : (isEditable ? "予定の編集/削除" : "予定の詳細");
            setTitle(dialogTitle);

            titleField = new JTextField(this.currentScheduleData.getTitle(), 25);
            detailsArea = new JTextArea(this.currentScheduleData.getDescription(), 5, 25);
            detailsArea.setLineWrap(true);
            detailsArea.setWrapStyleWord(true);
            privateCheckBox = new JCheckBox("非公開の予定にする");
            privateCheckBox.setSelected(this.currentScheduleData.isPrivate());
            privateCheckBox.setVisible(this.isDialogForPersonalAppointment);
            allDayCheckBox = new JCheckBox("終日の予定");
            allDayCheckBox.setSelected(this.currentScheduleData.isAllDay());

            Date initStartTime = Date.from(this.currentScheduleData.getStartTime().atZone(ZoneId.systemDefault()).toInstant());
            Date initEndTime = Date.from(this.currentScheduleData.getEndTime().atZone(ZoneId.systemDefault()).toInstant());

            SpinnerDateModel startModel = new SpinnerDateModel(initStartTime, null, null, Calendar.MINUTE);
            startTimeSpinner = new JSpinner(startModel);
            startTimeSpinner.setEditor(new JSpinner.DateEditor(startTimeSpinner, "HH:mm"));
            SpinnerDateModel endModel = new SpinnerDateModel(initEndTime, null, null, Calendar.MINUTE);
            endTimeSpinner = new JSpinner(endModel);
            endTimeSpinner.setEditor(new JSpinner.DateEditor(endTimeSpinner, "HH:mm"));
            timeLabel = new JLabel("時間:");

            allDayCheckBox.addActionListener(e -> updateDateTimeFieldsVisibility());
            updateDateTimeFieldsVisibility();

            JLabel ownerDisplayLabel = new JLabel();
            ownerDisplayLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            ownerDisplayLabel.setForeground(Color.GRAY);
            if (this.currentScheduleData.getGroupId() != null && !this.currentScheduleData.getGroupId().isEmpty()) {
                ownerDisplayLabel.setText("グループ予定 (ID: " + this.currentScheduleData.getGroupId() + ")");
            } else {
                ownerDisplayLabel.setText("個人予定 (作成者: " + this.currentScheduleData.getCreatedBy() + ")");
            }

            JPanel buttonPanelContainer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            if (isEditable) {
                JButton saveButton = new JButton("保存");
                saveButton.addActionListener(e -> { result = OPTION_SAVE; dispose(); });
                buttonPanelContainer.add(saveButton);
                if (!isNew) {
                    JButton deleteButton = new JButton("削除");
                    deleteButton.addActionListener(e -> {
                        if (JOptionPane.showConfirmDialog(this, "この予定を削除しますか？", "確認", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                            result = OPTION_DELETE; dispose();
                        }
                    });
                    buttonPanelContainer.add(deleteButton);
                }
                JButton cancelButton = new JButton("キャンセル");
                cancelButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(cancelButton);
            } else {
                JButton closeButton = new JButton("閉じる");
                closeButton.addActionListener(e -> { result = OPTION_CANCEL; dispose(); });
                buttonPanelContainer.add(closeButton);
                titleField.setEditable(false); detailsArea.setEditable(false);
                privateCheckBox.setEnabled(false); allDayCheckBox.setEnabled(false);
                startTimeSpinner.setEnabled(false); endTimeSpinner.setEnabled(false);
                titleField.setFocusable(false); detailsArea.setFocusable(false);
            }

            JPanel fieldsPanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(3,3,3,3);
            gbc.anchor = GridBagConstraints.WEST;
            gbc.gridx = 0; gbc.gridy = 0; fieldsPanel.add(new JLabel("タイトル:"), gbc);
            gbc.gridx = 1; gbc.gridy = 0; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
            fieldsPanel.add(titleField, gbc);
            gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
            fieldsPanel.add(new JLabel("詳細:"), gbc);
            gbc.gridx = 1; gbc.gridy = 1; gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
            fieldsPanel.add(new JScrollPane(detailsArea), gbc);
            gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth=2; gbc.fill = GridBagConstraints.NONE; gbc.weighty = 0;
            fieldsPanel.add(allDayCheckBox, gbc);
            JPanel timeInnerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            timeInnerPanel.add(startTimeSpinner); timeInnerPanel.add(Box.createHorizontalStrut(5));
            timeInnerPanel.add(new JLabel("～")); timeInnerPanel.add(Box.createHorizontalStrut(5));
            timeInnerPanel.add(endTimeSpinner);
            gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth=1; fieldsPanel.add(timeLabel, gbc);
            gbc.gridx = 1; gbc.gridy = 3; gbc.fill = GridBagConstraints.HORIZONTAL; fieldsPanel.add(timeInnerPanel, gbc);
            if (this.isDialogForPersonalAppointment) {
                 gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.NONE;
                 fieldsPanel.add(privateCheckBox, gbc);
            }
            JPanel mainContentPanel = new JPanel(new BorderLayout(5,5));
            mainContentPanel.setBorder(new EmptyBorder(10,10,10,10));
            mainContentPanel.add(fieldsPanel, BorderLayout.CENTER);
            JPanel southPanel = new JPanel(new BorderLayout());
            southPanel.setBorder(new EmptyBorder(5,0,0,0));
            southPanel.add(ownerDisplayLabel, BorderLayout.WEST);
            southPanel.add(buttonPanelContainer, BorderLayout.EAST);
            getContentPane().add(mainContentPanel, BorderLayout.CENTER);
            getContentPane().add(southPanel, BorderLayout.SOUTH);
            pack();
            setMinimumSize(new Dimension(450, getPreferredSize().height)); // 横幅を少し広めに
            setLocationRelativeTo(ownerFrame);
        }

        private void updateDateTimeFieldsVisibility() {
            boolean isAllDay = allDayCheckBox.isSelected();
            startTimeSpinner.setVisible(!isAllDay);
            endTimeSpinner.setVisible(!isAllDay);
            timeLabel.setVisible(!isAllDay);
        }

        public int getResult() { return result; }

        public share.Schedule getSchedule() {
            currentScheduleData.setTitle(titleField.getText());
            currentScheduleData.setDescription(detailsArea.getText());
            if(isDialogForPersonalAppointment) {
                currentScheduleData.setPrivate(privateCheckBox.isSelected());
            } else {
                currentScheduleData.setPrivate(false);
            }
            currentScheduleData.setAllDay(allDayCheckBox.isSelected());
            LocalDate scheduleDate = currentScheduleData.getStartTime().toLocalDate();
            if (!currentScheduleData.isAllDay()) {
                Date startTimeUtilDate = (Date) startTimeSpinner.getValue();
                Date endTimeUtilDate = (Date) endTimeSpinner.getValue();
                LocalTime localStartTime = LocalDateTime.ofInstant(startTimeUtilDate.toInstant(), ZoneId.systemDefault()).toLocalTime();
                LocalTime localEndTime = LocalDateTime.ofInstant(endTimeUtilDate.toInstant(), ZoneId.systemDefault()).toLocalTime();
                currentScheduleData.setStartTime(LocalDateTime.of(scheduleDate, localStartTime));
                currentScheduleData.setEndTime(LocalDateTime.of(scheduleDate, localEndTime));
            } else {
                 currentScheduleData.setStartTime(scheduleDate.atStartOfDay());
                 currentScheduleData.setEndTime(scheduleDate.atTime(23,59,59));
            }
            return currentScheduleData;
        }
    }
}