package client.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent; // AbstractActionを使う場合は不要かも

import client.Connector;
import share.LoginRequest;
import share.ServerMessage;
import share.User;
import share.UserData;
import share.ClientMessage; // MessageListener で使用
import share.LoginResponse; // LOGIN_FAILED で使用
import share.ErrorResponse; // ERROR で使用

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException; // Gsonの例外
import share.LocalDateTimeAdapter;

public class LoginScreen implements Connector.MessageListener { // Connector.MessageListener を実装

    private static Connector connector;
    private static JFrame loginFrameInstance;
    private static JTextField usernameField; // handleLogin やリスナーからアクセスするため static or インスタンスフィールドに
    private static JPasswordField passwordField; // 同上
    private static JButton loginButton; // 処理中に無効化するため
    private static JButton signupButton; // 同上

    // GsonはConnectorと重複するが、レスポンスのdata部をパースするために一時的に持つ
    // 本来はConnectorがパース済みのオブジェクトをリスナーに渡す方が良い
    private static final Gson gson = new GsonBuilder()
            .registerTypeAdapter(java.time.LocalDateTime.class, new LocalDateTimeAdapter())
            .create();

    // mainメソッドはApp.javaから呼び出される想定なので削除しても良い
    // public static void main(String[] args) {
    //     // このmainは直接は使われない
    // }

    public static void createAndShowLoginGUI(Connector conn) {
        connector = conn;
        // LoginScreenのインスタンスをリスナーとして登録する
        // ただし、このメソッド自体がstaticなので、LoginScreenのインスタンスを生成して登録するか、
        // LoginScreen全体を非staticにする必要がある。
        // ここでは、LoginScreenのインスタンスを内部で作り、それをリスナー登録する形を試みる。
        // しかし、staticなフィールドへのアクセスと混在するため、設計としてはstaticメソッドで全てを処理するか、
        // LoginScreenクラスをインスタンス化して使うようにApp.javaから変更するのが望ましい。
        // 今回は、リスナー処理をLoginScreenのインスタンスメソッドとして定義し、
        // staticなcreateAndShowLoginGUIからそのインスタンスを生成・利用する形で進める。

        LoginScreen instance = new LoginScreen(); // LoginScreenのインスタンスを生成
        connector.setMessageListener(instance);   // 生成したインスタンスをリスナーとして登録

        loginFrameInstance = new JFrame("ログイン");
        loginFrameInstance.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrameInstance.setSize(400, 250);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("ユーザーID:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.gridwidth = 2;
        usernameField = new JTextField(20); // staticフィールドに代入
        panel.add(usernameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        panel.add(new JLabel("パスワード:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; gbc.gridwidth = 2;
        passwordField = new JPasswordField(20); // staticフィールドに代入
        panel.add(passwordField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        loginButton = new JButton("ログイン"); // staticフィールドに代入
        signupButton = new JButton("新規作成"); // staticフィールドに代入
        buttonPanel.add(loginButton);
        buttonPanel.add(signupButton);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(15, 5, 5, 5);
        panel.add(buttonPanel, gbc);

        loginButton.addActionListener(e -> handleLoginAttempt()); // メソッド名を変更
        passwordField.addActionListener(e -> handleLoginAttempt());

        signupButton.addActionListener(e -> createAndShowSignUpDialog(loginFrameInstance));

        loginFrameInstance.add(panel);
        loginFrameInstance.setLocationRelativeTo(null);
        loginFrameInstance.setVisible(true);
    }

    // handleLoginから名前変更し、UI要素にアクセスしやすいようにする
    private static void handleLoginAttempt() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(loginFrameInstance, "ユーザーIDとパスワードを入力してください。", "入力エラー", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (connector == null) {
            JOptionPane.showMessageDialog(loginFrameInstance, "内部エラー: Connectorが初期化されていません。", "エラー", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!connector.isConnected()) {
            // ログイン試行時に接続も試みる
            setUIEnabled(false, "サーバーに接続中...");
            if (!connector.connect()) {
                JOptionPane.showMessageDialog(loginFrameInstance, "サーバーに接続できませんでした。", "接続エラー", JOptionPane.ERROR_MESSAGE);
                setUIEnabled(true, null);
                return;
            }
            // 接続成功後、少し待ってからログイン試行（サーバーが準備できるまで）
            // 本来はconnectメソッドが同期的に完了するか、コールバックで通知すべき
            // ここでは簡略化のため、そのままログイン処理に進む
             System.out.println("サーバー接続成功。ログイン試行...");
        }

        setUIEnabled(false, "ログイン処理中...");
        LoginRequest loginReq = new LoginRequest(username, password);
        ServerMessage serverMsg = new ServerMessage("LOGIN", gson.toJsonTree(loginReq));

        // 送信処理を別スレッドで行い、UIがフリーズしないようにする (任意だが推奨)
        new Thread(() -> {
            boolean sent = connector.sendMessage(serverMsg);
            if (!sent) {
                SwingUtilities.invokeLater(() -> { // UI更新はEDTで
                    JOptionPane.showMessageDialog(loginFrameInstance, "ログインリクエストの送信に失敗しました。", "送信エラー", JOptionPane.ERROR_MESSAGE);
                    setUIEnabled(true, null);
                });
            } else {
                // レスポンスは非同期にMessageListenerで処理されるのを待つ
                System.out.println("ログインリクエストを送信しました。サーバーからの応答待ち...");
                // setUIEnabled(false, "サーバー応答待ち..."); // 既に処理中表示
            }
        }).start();
    }

    // UIの有効/無効を切り替え、ステータスメッセージを表示するヘルパー
    private static void setUIEnabled(boolean enabled, String statusMessage) {
        usernameField.setEnabled(enabled);
        passwordField.setEnabled(enabled);
        loginButton.setEnabled(enabled);
        signupButton.setEnabled(enabled);
        if (statusMessage != null) {
            // ログインフレームのタイトルなどで一時的にステータスを表示するのも良い
            loginFrameInstance.setTitle("ログイン - " + statusMessage);
        } else {
            loginFrameInstance.setTitle("ログイン");
        }
    }

    // --- Connector.MessageListener の実装メソッド群 ---
    // これらは LoginScreen のインスタンスメソッドとして定義する
    @Override
    public void onMessageReceived(ClientMessage message) {
        // GUI更新はEDTで行うことが重要
        SwingUtilities.invokeLater(() -> {
            setUIEnabled(true, null); // UI操作を再度有効化
            loginFrameInstance.setTitle("ログイン"); // タイトルを元に戻す

            System.out.println("[LoginScreen] 受信メッセージタイプ: " + message.getType());
            if (message.getData() == null) {
                System.err.println("[LoginScreen] 受信データがnullです: " + message.getType());
                JOptionPane.showMessageDialog(loginFrameInstance, "サーバーから無効な応答を受信しました。", "受信エラー", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                switch (message.getType()) {
                    case "LOGIN_FAILED":
                        LoginResponse loginRes = gson.fromJson(message.getData(), LoginResponse.class);
                        JOptionPane.showMessageDialog(loginFrameInstance, loginRes.getMessage(), "ログイン失敗", JOptionPane.ERROR_MESSAGE);
                        break;
                    case "USER_DATA": // LOGIN_SUCCESS の代わりにこれが送られてくる想定
                        UserData userData = gson.fromJson(message.getData(), UserData.class);
                        if (userData != null && userData.getUser() != null) {
                            System.out.println("ログイン成功: " + userData.getUser().getUsername());
                            switchToCalendarScreen(userData.getUser(), userData);
                        } else {
                            JOptionPane.showMessageDialog(loginFrameInstance, "ユーザーデータの取得に失敗しました。", "エラー", JOptionPane.ERROR_MESSAGE);
                        }
                        break;
                    case "ERROR": // 汎用エラー
                        ErrorResponse errRes = gson.fromJson(message.getData(), ErrorResponse.class);
                        JOptionPane.showMessageDialog(loginFrameInstance, "サーバーエラー: " + errRes.getMessage(), "エラー", JOptionPane.ERROR_MESSAGE);
                        break;
                    default:
                        System.out.println("[LoginScreen] 未処理のメッセージタイプ: " + message.getType());
                        // ログイン画面では、上記以外のメッセージは基本的に無視してよい
                        break;
                }
            } catch (JsonSyntaxException e) {
                System.err.println("[LoginScreen] 受信メッセージのJSONパースエラー: " + e.getMessage());
                JOptionPane.showMessageDialog(loginFrameInstance, "サーバーから不正な形式のデータを受信しました。", "受信エラー", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    @Override
    public void onError(String errorMessage) {
        SwingUtilities.invokeLater(() -> {
            setUIEnabled(true, null);
            loginFrameInstance.setTitle("ログイン");
            JOptionPane.showMessageDialog(loginFrameInstance, errorMessage, "通信エラー", JOptionPane.ERROR_MESSAGE);
        });
    }

    @Override
    public void onDisconnected() {
        SwingUtilities.invokeLater(() -> {
            setUIEnabled(true, null); // UIは操作可能に戻すが、接続は切れている
            loginFrameInstance.setTitle("ログイン (切断)");
            JOptionPane.showMessageDialog(loginFrameInstance, "サーバーから切断されました。", "接続エラー", JOptionPane.WARNING_MESSAGE);
        });
    }
    // --- MessageListener 実装ここまで ---


    private static void switchToCalendarScreen(User loggedInUser, UserData initialUserData) {
        if (loginFrameInstance != null) {
            loginFrameInstance.dispose();
        }
        if (connector != null && !connector.isConnected()){
             System.err.println("警告: Calender画面遷移時にサーバー未接続です。");
        }
        // connector.setMessageListener(null); // LoginScreenのリスナーは不要になるので解除 (任意)

        Calender mainApp = new Calender(loggedInUser, connector, initialUserData);
        mainApp.createAndShowGUI();
    }

    private static void createAndShowSignUpDialog(JFrame owner) {
        // TODO: 新規登録処理もサーバー連携 (`REGISTER`メッセージ送信とレスポンス処理) にする
        // 現状はダミー
        JDialog dialog = new JDialog(owner, "アカウント新規作成", true);
        dialog.setSize(450, 350);
        dialog.setLayout(new BorderLayout(10, 10));
        JPanel inputPanel = new JPanel(new GridBagLayout());
        // ... (入力フィールドの作成は省略) ...
        JTextField usernameFieldDialog = new JTextField(20);
        JPasswordField passwordFieldDialog = new JPasswordField(20);
        // emailフィールドは削除

        // ... (レイアウト) ...
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL; gbc.insets = new Insets(5,5,5,5);
        gbc.gridx = 0; gbc.gridy = 0; inputPanel.add(new JLabel("ユーザーID:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; inputPanel.add(usernameFieldDialog, gbc);
        gbc.gridx = 0; gbc.gridy = 1; inputPanel.add(new JLabel("パスワード:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; inputPanel.add(passwordFieldDialog, gbc);
        // ... (確認用パスワードなども追加すると良い)

        JButton registerButton = new JButton("登録");
        registerButton.addActionListener(e -> {
            String regUsername = usernameFieldDialog.getText().trim();
            String regPassword = new String(passwordFieldDialog.getPassword());
            if(regUsername.isEmpty() || regPassword.isEmpty()){
                JOptionPane.showMessageDialog(dialog, "IDとパスワードを入力してください。", "エラー", JOptionPane.WARNING_MESSAGE);
                return;
            }

            setUIEnabled(false, "登録処理中...");
            RegisterRequest req = new RegisterRequest(regUsername, regPassword);
            ServerMessage msg = new ServerMessage("REGISTER", gson.toJsonTree(req));

            new Thread(() -> { // 送信は別スレッドで
                boolean sent = connector.sendMessage(msg);
                if (!sent) {
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(dialog, "登録リクエストの送信に失敗しました。", "送信エラー", JOptionPane.ERROR_MESSAGE);
                        setUIEnabled(true, null);
                    });
                } else {
                    System.out.println("登録リクエストを送信しました。");
                    // 登録成功/失敗のレスポンスは onMessageReceived で処理される (タイプ "REGISTER_SUCCESS", "REGISTER_FAILED")
                    // その処理をここに追加する必要がある。LoginScreenのonMessageReceivedに追加するか、
                    // このダイアログ専用のリスナーを一時的に設定する。
                    // ここでは簡略化のため、ダイアログを閉じるだけ。
                    SwingUtilities.invokeLater(() -> {
                        dialog.dispose(); // 応答を待たずに閉じる (本当は応答後に閉じるべき)
                        setUIEnabled(true, null);
                         JOptionPane.showMessageDialog(owner, "登録リクエストを送信しました。\nサーバーからの応答を確認してください。", "情報", JOptionPane.INFORMATION_MESSAGE);
                    });
                }
            }).start();
        });
        JPanel buttonPanelDialog = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanelDialog.add(registerButton);
        dialog.add(inputPanel, BorderLayout.CENTER);
        dialog.add(buttonPanelDialog, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(owner);
        dialog.setVisible(true);
    }
}