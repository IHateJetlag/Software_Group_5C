package client;

import java.io.*;
import java.net.*;
import javax.swing.SwingUtilities;
import com.google.gson.*;
import share.LocalDateTimeAdapter;
import share.ServerMessage;
import share.ClientMessage;

public class Connector {
    private static final String DEFAULT_SERVER_HOST = "localhost";
    private static final int DEFAULT_SERVER_PORT = 8080;

    private String serverHost;
    private int serverPort;

    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    private Gson gson;

    private volatile boolean isConnected = false;
    private Thread messageReceiverThread;

    public interface MessageListener {
        void onMessageReceived(ClientMessage message);
        void onError(String errorMessage);
        void onDisconnected();
    }
    private MessageListener messageListener;

    public Connector() {
        this(DEFAULT_SERVER_HOST, DEFAULT_SERVER_PORT);
    }

    public Connector(String host, int port) {
        this.serverHost = host;
        this.serverPort = port;
        this.gson = new GsonBuilder()
                .registerTypeAdapter(java.time.LocalDateTime.class, new LocalDateTimeAdapter())
                .create();
    }

    public void setMessageListener(MessageListener listener) {
        this.messageListener = listener;
    }

    public synchronized boolean connect() {
        if (isConnected) {
            System.out.println("[Connector] 既にサーバーに接続済みです。");
            return true;
        }
        try {
            System.out.println("[Connector] サーバーに接続試行中: " + serverHost + ":" + serverPort);
            socket = new Socket();
            socket.connect(new InetSocketAddress(serverHost, serverPort), 5000); // 5秒タイムアウト

            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true);

            isConnected = true;

            messageReceiverThread = new Thread(this::receiveMessagesLoop);
            messageReceiverThread.setDaemon(true);
            messageReceiverThread.start();

            System.out.println("[Connector] サーバーに接続しました。");
            return true;
        } catch (UnknownHostException e) {
            String errorMsg = "接続エラー: ホストが見つかりません - " + serverHost;
            System.err.println("[Connector] " + errorMsg);
            if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
        } catch (SocketTimeoutException e) {
            String errorMsg = "接続エラー: サーバーへの接続がタイムアウトしました。(" + serverHost + ":" + serverPort + ")";
            System.err.println("[Connector] " + errorMsg);
            if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
        }
        catch (IOException e) {
            String errorMsg = "サーバー接続エラー: " + e.getMessage();
            System.err.println("[Connector] " + errorMsg);
            if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
        }
        isConnected = false;
        return false;
    }

    public synchronized void disconnect() {
        if (!isConnected) {
            return;
        }
        System.out.println("[Connector] サーバーから切断処理を開始します...");
        isConnected = false;

        try {
            if (messageReceiverThread != null && messageReceiverThread.isAlive()) {
                messageReceiverThread.interrupt();
            }
            if (reader != null) try { reader.close(); } catch (IOException e) { /* ignore */ }
            if (writer != null) writer.close();
            if (socket != null && !socket.isClosed()) try { socket.close(); } catch (IOException e) { /* ignore */ }

            System.out.println("[Connector] サーバーから切断しました。");
            if (messageListener != null) {
                SwingUtilities.invokeLater(() -> messageListener.onDisconnected());
            }
        } finally {
            socket = null;
            reader = null;
            writer = null;
            messageReceiverThread = null;
        }
    }

    public boolean isConnected() {
        return isConnected && socket != null && !socket.isClosed() && socket.isConnected();
    }

    private void receiveMessagesLoop() {
        System.out.println("[Connector-Receiver] メッセージ受信スレッドを開始しました。");
        try {
            String serverJsonMessage;
            while (isConnected && reader != null && (serverJsonMessage = reader.readLine()) != null) {
                System.out.println("[Connector-Receiver] サーバーから受信: " + serverJsonMessage.substring(0, Math.min(serverJsonMessage.length(), 150)) + (serverJsonMessage.length() > 150 ? "..." : ""));

                final String finalJsonMessage = serverJsonMessage;
                if (messageListener != null) {
                    SwingUtilities.invokeLater(() -> {
                        try {
                            ClientMessage clientMessage = gson.fromJson(finalJsonMessage, ClientMessage.class);
                            if (clientMessage != null && clientMessage.getType() != null) {
                                messageListener.onMessageReceived(clientMessage);
                            } else {
                                String errorMsg = "サーバーからタイプ不明のメッセージを受信: " + finalJsonMessage;
                                System.err.println("[Connector-Receiver] " + errorMsg);
                                messageListener.onError(errorMsg);
                            }
                        } catch (JsonSyntaxException e) {
                            String errorMsg = "サーバーから不正な形式のメッセージを受信 (JSONパースエラー): " + e.getMessage();
                            System.err.println("[Connector-Receiver] " + errorMsg + " (データ: " + finalJsonMessage + ")");
                            messageListener.onError(errorMsg);
                        } catch (Exception e) {
                             String errorMsg = "メッセージ処理中に予期せぬエラー: " + e.getMessage();
                             System.err.println("[Connector-Receiver] " + errorMsg);
                             e.printStackTrace();
                             messageListener.onError(errorMsg);
                        }
                    });
                }
            }
        } catch (SocketException e) {
            if (isConnected) {
                String errorMsg = "ソケットエラー（接続が切断された可能性）: " + e.getMessage();
                System.err.println("[Connector-Receiver] " + errorMsg);
                if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
                handleDisconnection();
            }
        } catch (IOException e) {
            if (isConnected) {
                String errorMsg = "メッセージ受信中にIOエラー: " + e.getMessage();
                System.err.println("[Connector-Receiver] " + errorMsg);
                if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
                handleDisconnection();
            }
        } finally {
            System.out.println("[Connector-Receiver] メッセージ受信スレッドを終了 (isConnected: " + isConnected + ")");
            if (isConnected) {
                handleDisconnection();
            }
        }
    }
    
    private synchronized void handleDisconnection() {
        if (isConnected) {
            System.out.println("[Connector] 接続が失われたため、切断処理を実行します。");
            disconnect(); 
        }
    }

    public synchronized boolean sendMessage(ServerMessage serverMessage) {
        if (!isConnected()) {
            String errorMsg = "メッセージ送信失敗: サーバーに接続されていません。";
            System.err.println("[Connector] " + errorMsg);
            if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
            return false;
        }
        if (writer == null) {
            String errorMsg = "メッセージ送信失敗: PrintWriterが初期化されていません。";
            System.err.println("[Connector] " + errorMsg);
             if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
            return false;
        }
        try {
            String jsonMessage = gson.toJson(serverMessage);
            System.out.println("[Connector] サーバーへ送信: " + jsonMessage.substring(0, Math.min(jsonMessage.length(), 150)) + (jsonMessage.length() > 150 ? "..." : ""));
            writer.println(jsonMessage);
            if (writer.checkError()) {
                System.err.println("[Connector] メッセージ送信後にエラーフラグが検出されました。接続を確認します。");
                handleDisconnection(); // エラーがあれば接続が切れている可能性
                return false;
            }
            return true;
        } catch (Exception e) { // JsonIOExceptionなども含む
            System.err.println("[Connector] メッセージ送信中にエラー: " + e.getMessage());
            handleDisconnection();
            return false;
        }
    }
    // (mainメソッドは省略。前回のままでも良い)
}