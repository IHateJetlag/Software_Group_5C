package client;

import java.io.*;
import java.net.*;
import javax.swing.SwingUtilities; // GUIスレッドでの処理のため
import com.google.gson.*;
import share.LocalDateTimeAdapter;
import share.ServerMessage;
import share.ClientMessage;

public class Connector {
    private static final String DEFAULT_SERVER_HOST = "localhost";
    private static final int DEFAULT_SERVER_PORT = 8080;

    private String serverHost;
    private int serverPort;

    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    private Gson gson;

    private volatile boolean isConnected = false;
    private Thread messageReceiverThread;

    // GUIへサーバーからのメッセージを通知するためのコールバックインターフェース
    public interface MessageListener {
        void onMessageReceived(ClientMessage message); // 受信したメッセージオブジェクトを渡す
        void onError(String errorMessage);             // 通信エラーやサーバーからのエラー通知など
        void onDisconnected();                          // サーバーから切断された、または切断処理完了
    }
    private MessageListener messageListener;

    public Connector() {
        this(DEFAULT_SERVER_HOST, DEFAULT_SERVER_PORT);
    }

    public Connector(String host, int port) {
        this.serverHost = host;
        this.serverPort = port;
        this.gson = new GsonBuilder()
                .registerTypeAdapter(java.time.LocalDateTime.class, new LocalDateTimeAdapter())
                .create();
    }

    public void setMessageListener(MessageListener listener) {
        this.messageListener = listener;
    }

    public synchronized boolean connect() {
        if (isConnected) {
            System.out.println("[Connector] 既にサーバーに接続済みです。");
            return true;
        }
        try {
            System.out.println("[Connector] サーバーに接続試行中: " + serverHost + ":" + serverPort);
            socket = new Socket(); // まずソケットオブジェクトを生成
            // 接続タイムアウトを設定 (例: 5秒)
            socket.connect(new InetSocketAddress(serverHost, serverPort), 5000);
            // 読み取りタイムアウトも設定可能 (socket.setSoTimeout(5000);) だが、
            // receiveMessagesLoopでreadLineがブロックするので、ここでは主に接続タイムアウトが重要

            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true); // autoFlushをtrueに

            isConnected = true;

            messageReceiverThread = new Thread(this::receiveMessagesLoop);
            messageReceiverThread.setDaemon(true);
            messageReceiverThread.start();

            System.out.println("[Connector] サーバーに接続しました。");
            return true;
        } catch (UnknownHostException e) {
            String errorMsg = "接続エラー: ホストが見つかりません - " + serverHost;
            System.err.println("[Connector] " + errorMsg);
            if (messageListener != null) {
                // GUIスレッドでリスナーを呼び出す
                SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
            }
        } catch (SocketTimeoutException e) {
            String errorMsg = "接続エラー: サーバーへの接続がタイムアウトしました。(" + serverHost + ":" + serverPort + ")";
            System.err.println("[Connector] " + errorMsg);
            if (messageListener != null) {
                SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
            }
        }
        catch (IOException e) {
            String errorMsg = "サーバー接続エラー: " + e.getMessage();
            System.err.println("[Connector] " + errorMsg);
            if (messageListener != null) {
                SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
            }
        }
        isConnected = false;
        return false;
    }

    public synchronized void disconnect() {
        if (!isConnected) {
            return;
        }
        System.out.println("[Connector] サーバーから切断処理を開始します...");
        isConnected = false;

        try {
            if (messageReceiverThread != null && messageReceiverThread.isAlive()) {
                messageReceiverThread.interrupt(); // 受信スレッドに割り込み
                // スレッドが終了するのを少し待つ (任意)
                // try { messageReceiverThread.join(1000); } catch (InterruptedException ignored) {}
            }
            // ストリームとソケットのクローズは、スレッドが終了してからの方が安全な場合もある
            // reader/writerがnullでないこと、socketがnullかつ閉じていないことを確認
            if (reader != null) try { reader.close(); } catch (IOException e) { /* ignore */ }
            if (writer != null) writer.close(); // PrintWriterのcloseは例外をスローしない
            if (socket != null && !socket.isClosed()) try { socket.close(); } catch (IOException e) { /* ignore */ }

            System.out.println("[Connector] サーバーから切断しました。");
            if (messageListener != null) {
                // GUIスレッドでリスナーを呼び出す
                SwingUtilities.invokeLater(() -> messageListener.onDisconnected());
            }
        } finally { // catch (IOException e) は不要、各closeで個別対応
            socket = null;
            reader = null;
            writer = null;
            messageReceiverThread = null;
        }
    }

    public boolean isConnected() {
        // isConnectedフラグに加えて、ソケットの状態も確認
        return isConnected && socket != null && !socket.isClosed() && socket.isConnected();
    }

    private void receiveMessagesLoop() {
        System.out.println("[Connector-Receiver] メッセージ受信スレッドを開始しました。");
        try {
            String serverJsonMessage;
            // isConnectedフラグとreaderの状態をチェック
            while (isConnected && reader != null && (serverJsonMessage = reader.readLine()) != null) {
                System.out.println("[Connector-Receiver] サーバーから受信: " + serverJsonMessage.substring(0, Math.min(serverJsonMessage.length(), 150)) + (serverJsonMessage.length() > 150 ? "..." : ""));

                final String finalJsonMessage = serverJsonMessage; // ラムダ式で使うためにfinal
                if (messageListener != null) {
                    SwingUtilities.invokeLater(() -> { // GUIの更新は必ずEDTで行う
                        try {
                            ClientMessage clientMessage = gson.fromJson(finalJsonMessage, ClientMessage.class);
                            if (clientMessage != null && clientMessage.getType() != null) {
                                messageListener.onMessageReceived(clientMessage);
                            } else {
                                System.err.println("[Connector-Receiver] 受信メッセージのタイプがnullです: " + finalJsonMessage);
                                messageListener.onError("サーバーからタイプ不明のメッセージを受信しました。");
                            }
                        } catch (JsonSyntaxException e) {
                            System.err.println("[Connector-Receiver] 受信メッセージのJSONパースエラー: " + e.getMessage() + " (データ: " + finalJsonMessage + ")");
                            messageListener.onError("サーバーから不正な形式のメッセージを受信しました。");
                        } catch (Exception e) { // その他の予期せぬエラー
                             System.err.println("[Connector-Receiver] メッセージ処理中に予期せぬエラー: " + e.getMessage());
                             e.printStackTrace();
                             messageListener.onError("メッセージ処理中にエラーが発生しました。");
                        }
                    });
                }
            }
        } catch (SocketException e) {
            // isConnectedがtrueの場合のみエラーとして扱う（disconnect()による正常終了と区別）
            if (isConnected) {
                String errorMsg = "ソケットエラー（接続が切断された可能性）: " + e.getMessage();
                System.err.println("[Connector-Receiver] " + errorMsg);
                if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
                // 接続が切れたので、クリーンアップ処理を呼び出す
                handleDisconnection();
            }
        } catch (IOException e) {
            if (isConnected) {
                String errorMsg = "メッセージ受信中にIOエラー: " + e.getMessage();
                System.err.println("[Connector-Receiver] " + errorMsg);
                if (messageListener != null) SwingUtilities.invokeLater(() -> messageListener.onError(errorMsg));
                handleDisconnection();
            }
        } finally {
            System.out.println("[Connector-Receiver] メッセージ受信スレッドを終了しました。 (isConnected: " + isConnected + ")");
            // isConnectedがまだtrueなら、予期せぬ終了なのでdisconnectを呼ぶ
            if (isConnected) {
                handleDisconnection();
            }
        }
    }
    
    // 接続が切れた際の共通処理
    private synchronized void handleDisconnection() {
        if (isConnected) { // disconnectがまだ呼ばれていなければ呼ぶ
            System.out.println("[Connector] 接続が失われたため、切断処理を実行します。");
            disconnect(); 
        }
    }


    public synchronized boolean sendMessage(ServerMessage serverMessage) {
        if (!isConnected()) {
            System.err.println("[Connector] メッセージ送信失敗: サーバーに接続されていません。");
            if (messageListener != null) {
                 // GUIスレッドでリスナーを呼び出す
                SwingUtilities.invokeLater(() -> messageListener.onError("サーバーに接続されていません。"));
            }
            return false;
        }
        if (writer == null) {
            System.err.println("[Connector] メッセージ送信失敗: PrintWriterが初期化されていません。");
             if (messageListener != null) {
                SwingUtilities.invokeLater(() -> messageListener.onError("メッセージ送信機能が準備できていません。"));
            }
            return false;
        }
        try {
            String jsonMessage = gson.toJson(serverMessage);
            System.out.println("[Connector] サーバーへ送信: " + jsonMessage.substring(0, Math.min(jsonMessage.length(), 150)) + (jsonMessage.length() > 150 ? "..." : ""));
            writer.println(jsonMessage);
            if (writer.checkError()) { // 送信エラーチェック
                System.err.println("[Connector] メッセージ送信後にエラーフラグが検出されました。");
                // エラーが発生した場合、接続が切れている可能性がある
                handleDisconnection();
                return false;
            }
            return true;
        } catch (Exception e) {
            System.err.println("[Connector] メッセージ送信中にエラー: " + e.getMessage());
            handleDisconnection(); // 送信エラーは致命的な場合が多い
            return false;
        }
    }

    // 簡単な動作テスト用のmainメソッド (任意)
    public static void main(String[] args) {
        Connector connector = new Connector("localhost", 8080);
        // テスト用の簡単なリスナー
        connector.setMessageListener(new MessageListener() {
            @Override
            public void onMessageReceived(ClientMessage message) {
                System.out.println("テストリスナー受信: Type=" + message.getType() + ", Data=" + message.getData());
            }
            @Override
            public void onError(String errorMessage) {
                System.err.println("テストリスナーエラー: " + errorMessage);
            }
            @Override
            public void onDisconnected() {
                System.out.println("テストリスナー: 切断されました。");
            }
        });

        if (connector.connect()) {
            System.out.println("テスト: サーバー接続成功。");
            // ダミーのPINGメッセージ (サーバー側が "PING" を認識しなくても、接続テストにはなる)
            // ServerMessage pingMsg = new ServerMessage("PING_TEST", null);
            // connector.sendMessage(pingMsg);
            try {
                Thread.sleep(2000); // 少し待つ
                // ダミーのログインリクエスト (サーバー側が LOGIN を認識する場合)
                // LoginRequest loginReq = new LoginRequest("testuser", "password");
                // ServerMessage loginMsg = new ServerMessage("LOGIN", new Gson().toJsonTree(loginReq));
                // connector.sendMessage(loginMsg);

                System.out.println("テスト: 10秒後に切断します...");
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            connector.disconnect();
        } else {
            System.out.println("テスト: サーバー接続失敗。");
        }
        System.out.println("テスト: Connectorテスト終了。");
    }
}