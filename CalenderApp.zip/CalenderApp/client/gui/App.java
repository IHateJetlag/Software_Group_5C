// CalenderAppProject/client/gui/App.java (修正案)
package client.gui;

import client.Connector; // Connectorクラスをインポート

public class App {

    public static void main(String[] args) {
        // Connectorインスタンスを生成
        Connector connector = new Connector(); // デフォルトホスト・ポートで接続

        // LoginScreenの表示メソッドにConnectorインスタンスを渡す
        // LoginScreen.main(args); // ← これは呼び出さない
        LoginScreen.createAndShowLoginGUI(connector); // 新しいメソッドをLoginScreenに作るか、
                                                     // LoginScreenのコンストラクタで受け取る形にする
    }
}
